import { Kn as ref, Nt as onDeactivated, Ot as nextTick, U as computed, Ut as provide, Wn as reactive, Yn as shallowRef, _n as watchEffect, gn as watch, kt as onActivated, nr as unref, nt as defineComponent, pt as h, qn as shallowReactive, ut as getCurrentInstance, xt as inject, zt as onUnmounted } from "/node_modules/.vite/deps/vue.runtime.esm-bundler-Bo_ScjpA.js?v=0b5deebc";
//#region node_modules/@vue/devtools-api/lib/esm/env.js
function getDevtoolsGlobalHook() {
	return getTarget().__VUE_DEVTOOLS_GLOBAL_HOOK__;
}
function getTarget() {
	return typeof navigator !== "undefined" && typeof window !== "undefined" ? window : typeof globalThis !== "undefined" ? globalThis : {};
}
var isProxyAvailable = typeof Proxy === "function";
//#endregion
//#region node_modules/@vue/devtools-api/lib/esm/const.js
var HOOK_SETUP = "devtools-plugin:setup";
var HOOK_PLUGIN_SETTINGS_SET = "plugin:settings:set";
//#endregion
//#region node_modules/@vue/devtools-api/lib/esm/time.js
var supported;
var perf;
function isPerformanceSupported() {
	var _a;
	if (supported !== void 0) return supported;
	if (typeof window !== "undefined" && window.performance) {
		supported = true;
		perf = window.performance;
	} else if (typeof globalThis !== "undefined" && ((_a = globalThis.perf_hooks) === null || _a === void 0 ? void 0 : _a.performance)) {
		supported = true;
		perf = globalThis.perf_hooks.performance;
	} else supported = false;
	return supported;
}
function now() {
	return isPerformanceSupported() ? perf.now() : Date.now();
}
//#endregion
//#region node_modules/@vue/devtools-api/lib/esm/proxy.js
var ApiProxy = class {
	constructor(plugin, hook) {
		this.target = null;
		this.targetQueue = [];
		this.onQueue = [];
		this.plugin = plugin;
		this.hook = hook;
		const defaultSettings = {};
		if (plugin.settings) for (const id in plugin.settings) defaultSettings[id] = plugin.settings[id].defaultValue;
		const localSettingsSaveId = `__vue-devtools-plugin-settings__${plugin.id}`;
		let currentSettings = Object.assign({}, defaultSettings);
		try {
			const raw = localStorage.getItem(localSettingsSaveId);
			const data = JSON.parse(raw);
			Object.assign(currentSettings, data);
		} catch (e) {}
		this.fallbacks = {
			getSettings() {
				return currentSettings;
			},
			setSettings(value) {
				try {
					localStorage.setItem(localSettingsSaveId, JSON.stringify(value));
				} catch (e) {}
				currentSettings = value;
			},
			now() {
				return now();
			}
		};
		if (hook) hook.on(HOOK_PLUGIN_SETTINGS_SET, (pluginId, value) => {
			if (pluginId === this.plugin.id) this.fallbacks.setSettings(value);
		});
		this.proxiedOn = new Proxy({}, { get: (_target, prop) => {
			if (this.target) return this.target.on[prop];
			else return (...args) => {
				this.onQueue.push({
					method: prop,
					args
				});
			};
		} });
		this.proxiedTarget = new Proxy({}, { get: (_target, prop) => {
			if (this.target) return this.target[prop];
			else if (prop === "on") return this.proxiedOn;
			else if (Object.keys(this.fallbacks).includes(prop)) return (...args) => {
				this.targetQueue.push({
					method: prop,
					args,
					resolve: () => {}
				});
				return this.fallbacks[prop](...args);
			};
			else return (...args) => {
				return new Promise((resolve) => {
					this.targetQueue.push({
						method: prop,
						args,
						resolve
					});
				});
			};
		} });
	}
	async setRealTarget(target) {
		this.target = target;
		for (const item of this.onQueue) this.target.on[item.method](...item.args);
		for (const item of this.targetQueue) item.resolve(await this.target[item.method](...item.args));
	}
};
//#endregion
//#region node_modules/@vue/devtools-api/lib/esm/index.js
function setupDevtoolsPlugin(pluginDescriptor, setupFn) {
	const descriptor = pluginDescriptor;
	const target = getTarget();
	const hook = getDevtoolsGlobalHook();
	const enableProxy = isProxyAvailable && descriptor.enableEarlyProxy;
	if (hook && (target.__VUE_DEVTOOLS_PLUGIN_API_AVAILABLE__ || !enableProxy)) hook.emit(HOOK_SETUP, pluginDescriptor, setupFn);
	else {
		const proxy = enableProxy ? new ApiProxy(descriptor, hook) : null;
		(target.__VUE_DEVTOOLS_PLUGINS__ = target.__VUE_DEVTOOLS_PLUGINS__ || []).push({
			pluginDescriptor: descriptor,
			setupFn,
			proxy
		});
		if (proxy) setupFn(proxy.proxiedTarget);
	}
}
//#endregion
//#region node_modules/vue-router/dist/devtools-EWN81iOl.mjs
/*!
* vue-router v4.6.4
* (c) 2025 Eduardo San Martin Morote
* @license MIT
*/
var isBrowser = typeof document !== "undefined";
/**
* Allows differentiating lazy components from functional components and vue-class-component
* @internal
*
* @param component
*/
function isRouteComponent(component) {
	return typeof component === "object" || "displayName" in component || "props" in component || "__vccOpts" in component;
}
function isESModule(obj) {
	return obj.__esModule || obj[Symbol.toStringTag] === "Module" || obj.default && isRouteComponent(obj.default);
}
var assign = Object.assign;
function applyToParams(fn, params) {
	const newParams = {};
	for (const key in params) {
		const value = params[key];
		newParams[key] = isArray(value) ? value.map(fn) : fn(value);
	}
	return newParams;
}
var noop = () => {};
/**
* Typesafe alternative to Array.isArray
* https://github.com/microsoft/TypeScript/pull/48228
*
* @internal
*/
var isArray = Array.isArray;
function mergeOptions(defaults, partialOptions) {
	const options = {};
	for (const key in defaults) options[key] = key in partialOptions ? partialOptions[key] : defaults[key];
	return options;
}
function warn$1(msg) {
	const args = Array.from(arguments).slice(1);
	console.warn.apply(console, ["[Vue Router warn]: " + msg].concat(args));
}
/**
* Encoding Rules (␣ = Space)
* - Path: ␣ " < > # ? { }
* - Query: ␣ " < > # & =
* - Hash: ␣ " < > `
*
* On top of that, the RFC3986 (https://tools.ietf.org/html/rfc3986#section-2.2)
* defines some extra characters to be encoded. Most browsers do not encode them
* in encodeURI https://github.com/whatwg/url/issues/369, so it may be safer to
* also encode `!'()*`. Leaving un-encoded only ASCII alphanumeric(`a-zA-Z0-9`)
* plus `-._~`. This extra safety should be applied to query by patching the
* string returned by encodeURIComponent encodeURI also encodes `[\]^`. `\`
* should be encoded to avoid ambiguity. Browsers (IE, FF, C) transform a `\`
* into a `/` if directly typed in. The _backtick_ (`````) should also be
* encoded everywhere because some browsers like FF encode it when directly
* written while others don't. Safari and IE don't encode ``"<>{}``` in hash.
*/
var HASH_RE = /#/g;
var AMPERSAND_RE = /&/g;
var SLASH_RE = /\//g;
var EQUAL_RE = /=/g;
var IM_RE = /\?/g;
var PLUS_RE = /\+/g;
/**
* NOTE: It's not clear to me if we should encode the + symbol in queries, it
* seems to be less flexible than not doing so and I can't find out the legacy
* systems requiring this for regular requests like text/html. In the standard,
* the encoding of the plus character is only mentioned for
* application/x-www-form-urlencoded
* (https://url.spec.whatwg.org/#urlencoded-parsing) and most browsers seems lo
* leave the plus character as is in queries. To be more flexible, we allow the
* plus character on the query, but it can also be manually encoded by the user.
*
* Resources:
* - https://url.spec.whatwg.org/#urlencoded-parsing
* - https://stackoverflow.com/questions/1634271/url-encoding-the-space-character-or-20
*/
var ENC_BRACKET_OPEN_RE = /%5B/g;
var ENC_BRACKET_CLOSE_RE = /%5D/g;
var ENC_CARET_RE = /%5E/g;
var ENC_BACKTICK_RE = /%60/g;
var ENC_CURLY_OPEN_RE = /%7B/g;
var ENC_PIPE_RE = /%7C/g;
var ENC_CURLY_CLOSE_RE = /%7D/g;
var ENC_SPACE_RE = /%20/g;
/**
* Encode characters that need to be encoded on the path, search and hash
* sections of the URL.
*
* @internal
* @param text - string to encode
* @returns encoded string
*/
function commonEncode(text) {
	return text == null ? "" : encodeURI("" + text).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]");
}
/**
* Encode characters that need to be encoded on the hash section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeHash(text) {
	return commonEncode(text).replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Encode characters that need to be encoded query values on the query
* section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeQueryValue(text) {
	return commonEncode(text).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Like `encodeQueryValue` but also encodes the `=` character.
*
* @param text - string to encode
*/
function encodeQueryKey(text) {
	return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
/**
* Encode characters that need to be encoded on the path section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodePath(text) {
	return commonEncode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F");
}
/**
* Encode characters that need to be encoded on the path section of the URL as a
* param. This function encodes everything {@link encodePath} does plus the
* slash (`/`) character. If `text` is `null` or `undefined`, returns an empty
* string instead.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeParam(text) {
	return encodePath(text).replace(SLASH_RE, "%2F");
}
function decode(text) {
	if (text == null) return null;
	try {
		return decodeURIComponent("" + text);
	} catch (err) {
		warn$1(`Error decoding "${text}". Using original value`);
	}
	return "" + text;
}
var TRAILING_SLASH_RE = /\/$/;
var removeTrailingSlash = (path) => path.replace(TRAILING_SLASH_RE, "");
/**
* Transforms a URI into a normalized history location
*
* @param parseQuery
* @param location - URI to normalize
* @param currentLocation - current absolute location. Allows resolving relative
* paths. Must start with `/`. Defaults to `/`
* @returns a normalized history location
*/
function parseURL(parseQuery$1, location, currentLocation = "/") {
	let path, query = {}, searchString = "", hash = "";
	const hashPos = location.indexOf("#");
	let searchPos = location.indexOf("?");
	searchPos = hashPos >= 0 && searchPos > hashPos ? -1 : searchPos;
	if (searchPos >= 0) {
		path = location.slice(0, searchPos);
		searchString = location.slice(searchPos, hashPos > 0 ? hashPos : location.length);
		query = parseQuery$1(searchString.slice(1));
	}
	if (hashPos >= 0) {
		path = path || location.slice(0, hashPos);
		hash = location.slice(hashPos, location.length);
	}
	path = resolveRelativePath(path != null ? path : location, currentLocation);
	return {
		fullPath: path + searchString + hash,
		path,
		query,
		hash: decode(hash)
	};
}
/**
* Stringifies a URL object
*
* @param stringifyQuery
* @param location
*/
function stringifyURL(stringifyQuery$1, location) {
	const query = location.query ? stringifyQuery$1(location.query) : "";
	return location.path + (query && "?") + query + (location.hash || "");
}
/**
* Strips off the base from the beginning of a location.pathname in a non-case-sensitive way.
*
* @param pathname - location.pathname
* @param base - base to strip off
*/
function stripBase(pathname, base) {
	if (!base || !pathname.toLowerCase().startsWith(base.toLowerCase())) return pathname;
	return pathname.slice(base.length) || "/";
}
/**
* Checks if two RouteLocation are equal. This means that both locations are
* pointing towards the same {@link RouteRecord} and that all `params`, `query`
* parameters and `hash` are the same
*
* @param stringifyQuery - A function that takes a query object of type LocationQueryRaw and returns a string representation of it.
* @param a - first {@link RouteLocation}
* @param b - second {@link RouteLocation}
*/
function isSameRouteLocation(stringifyQuery$1, a, b) {
	const aLastIndex = a.matched.length - 1;
	const bLastIndex = b.matched.length - 1;
	return aLastIndex > -1 && aLastIndex === bLastIndex && isSameRouteRecord(a.matched[aLastIndex], b.matched[bLastIndex]) && isSameRouteLocationParams(a.params, b.params) && stringifyQuery$1(a.query) === stringifyQuery$1(b.query) && a.hash === b.hash;
}
/**
* Check if two `RouteRecords` are equal. Takes into account aliases: they are
* considered equal to the `RouteRecord` they are aliasing.
*
* @param a - first {@link RouteRecord}
* @param b - second {@link RouteRecord}
*/
function isSameRouteRecord(a, b) {
	return (a.aliasOf || a) === (b.aliasOf || b);
}
function isSameRouteLocationParams(a, b) {
	if (Object.keys(a).length !== Object.keys(b).length) return false;
	for (var key in a) if (!isSameRouteLocationParamsValue(a[key], b[key])) return false;
	return true;
}
function isSameRouteLocationParamsValue(a, b) {
	return isArray(a) ? isEquivalentArray(a, b) : isArray(b) ? isEquivalentArray(b, a) : a?.valueOf() === b?.valueOf();
}
/**
* Check if two arrays are the same or if an array with one single entry is the
* same as another primitive value. Used to check query and parameters
*
* @param a - array of values
* @param b - array of values or a single value
*/
function isEquivalentArray(a, b) {
	return isArray(b) ? a.length === b.length && a.every((value, i) => value === b[i]) : a.length === 1 && a[0] === b;
}
/**
* Resolves a relative path that starts with `.`.
*
* @param to - path location we are resolving
* @param from - currentLocation.path, should start with `/`
*/
function resolveRelativePath(to, from) {
	if (to.startsWith("/")) return to;
	if (!from.startsWith("/")) {
		warn$1(`Cannot resolve a relative location without an absolute path. Trying to resolve "${to}" from "${from}". It should look like "/${from}".`);
		return to;
	}
	if (!to) return from;
	const fromSegments = from.split("/");
	const toSegments = to.split("/");
	const lastToSegment = toSegments[toSegments.length - 1];
	if (lastToSegment === ".." || lastToSegment === ".") toSegments.push("");
	let position = fromSegments.length - 1;
	let toPosition;
	let segment;
	for (toPosition = 0; toPosition < toSegments.length; toPosition++) {
		segment = toSegments[toPosition];
		if (segment === ".") continue;
		if (segment === "..") {
			if (position > 1) position--;
		} else break;
	}
	return fromSegments.slice(0, position).join("/") + "/" + toSegments.slice(toPosition).join("/");
}
/**
* Initial route location where the router is. Can be used in navigation guards
* to differentiate the initial navigation.
*
* @example
* ```js
* import { START_LOCATION } from 'vue-router'
*
* router.beforeEach((to, from) => {
*   if (from === START_LOCATION) {
*     // initial navigation
*   }
* })
* ```
*/
var START_LOCATION_NORMALIZED = {
	path: "/",
	name: void 0,
	params: {},
	query: {},
	hash: "",
	fullPath: "/",
	matched: [],
	meta: {},
	redirectedFrom: void 0
};
var NavigationType = /* @__PURE__ */ function(NavigationType$1) {
	NavigationType$1["pop"] = "pop";
	NavigationType$1["push"] = "push";
	return NavigationType$1;
}({});
var NavigationDirection = /* @__PURE__ */ function(NavigationDirection$1) {
	NavigationDirection$1["back"] = "back";
	NavigationDirection$1["forward"] = "forward";
	NavigationDirection$1["unknown"] = "";
	return NavigationDirection$1;
}({});
/**
* Normalizes a base by removing any trailing slash and reading the base tag if
* present.
*
* @param base - base to normalize
*/
function normalizeBase(base) {
	if (!base) if (isBrowser) {
		const baseEl = document.querySelector("base");
		base = baseEl && baseEl.getAttribute("href") || "/";
		base = base.replace(/^\w+:\/\/[^\/]+/, "");
	} else base = "/";
	if (base[0] !== "/" && base[0] !== "#") base = "/" + base;
	return removeTrailingSlash(base);
}
var BEFORE_HASH_RE = /^[^#]+#/;
function createHref(base, location) {
	return base.replace(BEFORE_HASH_RE, "#") + location;
}
function getElementPosition(el, offset) {
	const docRect = document.documentElement.getBoundingClientRect();
	const elRect = el.getBoundingClientRect();
	return {
		behavior: offset.behavior,
		left: elRect.left - docRect.left - (offset.left || 0),
		top: elRect.top - docRect.top - (offset.top || 0)
	};
}
var computeScrollPosition = () => ({
	left: window.scrollX,
	top: window.scrollY
});
function scrollToPosition(position) {
	let scrollToOptions;
	if ("el" in position) {
		const positionEl = position.el;
		const isIdSelector = typeof positionEl === "string" && positionEl.startsWith("#");
		/**
		* `id`s can accept pretty much any characters, including CSS combinators
		* like `>` or `~`. It's still possible to retrieve elements using
		* `document.getElementById('~')` but it needs to be escaped when using
		* `document.querySelector('#\\~')` for it to be valid. The only
		* requirements for `id`s are them to be unique on the page and to not be
		* empty (`id=""`). Because of that, when passing an id selector, it should
		* be properly escaped for it to work with `querySelector`. We could check
		* for the id selector to be simple (no CSS combinators `+ >~`) but that
		* would make things inconsistent since they are valid characters for an
		* `id` but would need to be escaped when using `querySelector`, breaking
		* their usage and ending up in no selector returned. Selectors need to be
		* escaped:
		*
		* - `#1-thing` becomes `#\31 -thing`
		* - `#with~symbols` becomes `#with\\~symbols`
		*
		* - More information about  the topic can be found at
		*   https://mathiasbynens.be/notes/html5-id-class.
		* - Practical example: https://mathiasbynens.be/demo/html5-id
		*/
		if (typeof position.el === "string") {
			if (!isIdSelector || !document.getElementById(position.el.slice(1))) try {
				const foundEl = document.querySelector(position.el);
				if (isIdSelector && foundEl) {
					warn$1(`The selector "${position.el}" should be passed as "el: document.querySelector('${position.el}')" because it starts with "#".`);
					return;
				}
			} catch (err) {
				warn$1(`The selector "${position.el}" is invalid. If you are using an id selector, make sure to escape it. You can find more information about escaping characters in selectors at https://mathiasbynens.be/notes/css-escapes or use CSS.escape (https://developer.mozilla.org/en-US/docs/Web/API/CSS/escape).`);
				return;
			}
		}
		const el = typeof positionEl === "string" ? isIdSelector ? document.getElementById(positionEl.slice(1)) : document.querySelector(positionEl) : positionEl;
		if (!el) {
			warn$1(`Couldn't find element using selector "${position.el}" returned by scrollBehavior.`);
			return;
		}
		scrollToOptions = getElementPosition(el, position);
	} else scrollToOptions = position;
	if ("scrollBehavior" in document.documentElement.style) window.scrollTo(scrollToOptions);
	else window.scrollTo(scrollToOptions.left != null ? scrollToOptions.left : window.scrollX, scrollToOptions.top != null ? scrollToOptions.top : window.scrollY);
}
function getScrollKey(path, delta) {
	return (history.state ? history.state.position - delta : -1) + path;
}
var scrollPositions = /* @__PURE__ */ new Map();
function saveScrollPosition(key, scrollPosition) {
	scrollPositions.set(key, scrollPosition);
}
function getSavedScrollPosition(key) {
	const scroll = scrollPositions.get(key);
	scrollPositions.delete(key);
	return scroll;
}
/**
* ScrollBehavior instance used by the router to compute and restore the scroll
* position when navigating.
*/
function isRouteLocation(route) {
	return typeof route === "string" || route && typeof route === "object";
}
function isRouteName(name) {
	return typeof name === "string" || typeof name === "symbol";
}
/**
* Flags so we can combine them when checking for multiple errors. This is the internal version of
* {@link NavigationFailureType}.
*
* @internal
*/
var ErrorTypes = /* @__PURE__ */ function(ErrorTypes$1) {
	ErrorTypes$1[ErrorTypes$1["MATCHER_NOT_FOUND"] = 1] = "MATCHER_NOT_FOUND";
	ErrorTypes$1[ErrorTypes$1["NAVIGATION_GUARD_REDIRECT"] = 2] = "NAVIGATION_GUARD_REDIRECT";
	ErrorTypes$1[ErrorTypes$1["NAVIGATION_ABORTED"] = 4] = "NAVIGATION_ABORTED";
	ErrorTypes$1[ErrorTypes$1["NAVIGATION_CANCELLED"] = 8] = "NAVIGATION_CANCELLED";
	ErrorTypes$1[ErrorTypes$1["NAVIGATION_DUPLICATED"] = 16] = "NAVIGATION_DUPLICATED";
	return ErrorTypes$1;
}({});
var NavigationFailureSymbol = Symbol("navigation failure");
/**
* Enumeration with all possible types for navigation failures. Can be passed to
* {@link isNavigationFailure} to check for specific failures.
*/
var NavigationFailureType = /* @__PURE__ */ function(NavigationFailureType$1) {
	/**
	* An aborted navigation is a navigation that failed because a navigation
	* guard returned `false` or called `next(false)`
	*/
	NavigationFailureType$1[NavigationFailureType$1["aborted"] = 4] = "aborted";
	/**
	* A cancelled navigation is a navigation that failed because a more recent
	* navigation finished started (not necessarily finished).
	*/
	NavigationFailureType$1[NavigationFailureType$1["cancelled"] = 8] = "cancelled";
	/**
	* A duplicated navigation is a navigation that failed because it was
	* initiated while already being at the exact same location.
	*/
	NavigationFailureType$1[NavigationFailureType$1["duplicated"] = 16] = "duplicated";
	return NavigationFailureType$1;
}({});
var ErrorTypeMessages = {
	[ErrorTypes.MATCHER_NOT_FOUND]({ location, currentLocation }) {
		return `No match for\n ${JSON.stringify(location)}${currentLocation ? "\nwhile being at\n" + JSON.stringify(currentLocation) : ""}`;
	},
	[ErrorTypes.NAVIGATION_GUARD_REDIRECT]({ from, to }) {
		return `Redirected from "${from.fullPath}" to "${stringifyRoute(to)}" via a navigation guard.`;
	},
	[ErrorTypes.NAVIGATION_ABORTED]({ from, to }) {
		return `Navigation aborted from "${from.fullPath}" to "${to.fullPath}" via a navigation guard.`;
	},
	[ErrorTypes.NAVIGATION_CANCELLED]({ from, to }) {
		return `Navigation cancelled from "${from.fullPath}" to "${to.fullPath}" with a new navigation.`;
	},
	[ErrorTypes.NAVIGATION_DUPLICATED]({ from, to }) {
		return `Avoided redundant navigation to current location: "${from.fullPath}".`;
	}
};
/**
* Creates a typed NavigationFailure object.
* @internal
* @param type - NavigationFailureType
* @param params - { from, to }
*/
function createRouterError(type, params) {
	return assign(new Error(ErrorTypeMessages[type](params)), {
		type,
		[NavigationFailureSymbol]: true
	}, params);
}
function isNavigationFailure(error, type) {
	return error instanceof Error && NavigationFailureSymbol in error && (type == null || !!(error.type & type));
}
var propertiesToLog = [
	"params",
	"query",
	"hash"
];
function stringifyRoute(to) {
	if (typeof to === "string") return to;
	if (to.path != null) return to.path;
	const location = {};
	for (const key of propertiesToLog) if (key in to) location[key] = to[key];
	return JSON.stringify(location, null, 2);
}
/**
* Transforms a queryString into a {@link LocationQuery} object. Accept both, a
* version with the leading `?` and without Should work as URLSearchParams

* @internal
*
* @param search - search string to parse
* @returns a query object
*/
function parseQuery(search) {
	const query = {};
	if (search === "" || search === "?") return query;
	const searchParams = (search[0] === "?" ? search.slice(1) : search).split("&");
	for (let i = 0; i < searchParams.length; ++i) {
		const searchParam = searchParams[i].replace(PLUS_RE, " ");
		const eqPos = searchParam.indexOf("=");
		const key = decode(eqPos < 0 ? searchParam : searchParam.slice(0, eqPos));
		const value = eqPos < 0 ? null : decode(searchParam.slice(eqPos + 1));
		if (key in query) {
			let currentValue = query[key];
			if (!isArray(currentValue)) currentValue = query[key] = [currentValue];
			currentValue.push(value);
		} else query[key] = value;
	}
	return query;
}
/**
* Stringifies a {@link LocationQueryRaw} object. Like `URLSearchParams`, it
* doesn't prepend a `?`
*
* @internal
*
* @param query - query object to stringify
* @returns string version of the query without the leading `?`
*/
function stringifyQuery(query) {
	let search = "";
	for (let key in query) {
		const value = query[key];
		key = encodeQueryKey(key);
		if (value == null) {
			if (value !== void 0) search += (search.length ? "&" : "") + key;
			continue;
		}
		(isArray(value) ? value.map((v) => v && encodeQueryValue(v)) : [value && encodeQueryValue(value)]).forEach((value$1) => {
			if (value$1 !== void 0) {
				search += (search.length ? "&" : "") + key;
				if (value$1 != null) search += "=" + value$1;
			}
		});
	}
	return search;
}
/**
* Transforms a {@link LocationQueryRaw} into a {@link LocationQuery} by casting
* numbers into strings, removing keys with an undefined value and replacing
* undefined with null in arrays
*
* @param query - query object to normalize
* @returns a normalized query object
*/
function normalizeQuery(query) {
	const normalizedQuery = {};
	for (const key in query) {
		const value = query[key];
		if (value !== void 0) normalizedQuery[key] = isArray(value) ? value.map((v) => v == null ? null : "" + v) : value == null ? value : "" + value;
	}
	return normalizedQuery;
}
/**
* RouteRecord being rendered by the closest ancestor Router View. Used for
* `onBeforeRouteUpdate` and `onBeforeRouteLeave`. rvlm stands for Router View
* Location Matched
*
* @internal
*/
var matchedRouteKey = Symbol("router view location matched");
/**
* Allows overriding the router view depth to control which component in
* `matched` is rendered. rvd stands for Router View Depth
*
* @internal
*/
var viewDepthKey = Symbol("router view depth");
/**
* Allows overriding the router instance returned by `useRouter` in tests. r
* stands for router
*
* @internal
*/
var routerKey = Symbol("router");
/**
* Allows overriding the current route returned by `useRoute` in tests. rl
* stands for route location
*
* @internal
*/
var routeLocationKey = Symbol("route location");
/**
* Allows overriding the current route used by router-view. Internally this is
* used when the `route` prop is passed.
*
* @internal
*/
var routerViewLocationKey = Symbol("router view location");
/**
* Create a list of callbacks that can be reset. Used to create before and after navigation guards list
*/
function useCallbacks() {
	let handlers = [];
	function add(handler) {
		handlers.push(handler);
		return () => {
			const i = handlers.indexOf(handler);
			if (i > -1) handlers.splice(i, 1);
		};
	}
	function reset() {
		handlers = [];
	}
	return {
		add,
		list: () => handlers.slice(),
		reset
	};
}
function registerGuard(record, name, guard) {
	const removeFromList = () => {
		record[name].delete(guard);
	};
	onUnmounted(removeFromList);
	onDeactivated(removeFromList);
	onActivated(() => {
		record[name].add(guard);
	});
	record[name].add(guard);
}
/**
* Add a navigation guard that triggers whenever the component for the current
* location is about to be left. Similar to {@link beforeRouteLeave} but can be
* used in any component. The guard is removed when the component is unmounted.
*
* @param leaveGuard - {@link NavigationGuard}
*/
function onBeforeRouteLeave(leaveGuard) {
	if (!getCurrentInstance()) {
		warn$1("getCurrentInstance() returned null. onBeforeRouteLeave() must be called at the top of a setup function");
		return;
	}
	const activeRecord = inject(matchedRouteKey, {}).value;
	if (!activeRecord) {
		warn$1("No active route record was found when calling `onBeforeRouteLeave()`. Make sure you call this function inside a component child of <router-view>. Maybe you called it inside of App.vue?");
		return;
	}
	registerGuard(activeRecord, "leaveGuards", leaveGuard);
}
/**
* Add a navigation guard that triggers whenever the current location is about
* to be updated. Similar to {@link beforeRouteUpdate} but can be used in any
* component. The guard is removed when the component is unmounted.
*
* @param updateGuard - {@link NavigationGuard}
*/
function onBeforeRouteUpdate(updateGuard) {
	if (!getCurrentInstance()) {
		warn$1("getCurrentInstance() returned null. onBeforeRouteUpdate() must be called at the top of a setup function");
		return;
	}
	const activeRecord = inject(matchedRouteKey, {}).value;
	if (!activeRecord) {
		warn$1("No active route record was found when calling `onBeforeRouteUpdate()`. Make sure you call this function inside a component child of <router-view>. Maybe you called it inside of App.vue?");
		return;
	}
	registerGuard(activeRecord, "updateGuards", updateGuard);
}
function guardToPromiseFn(guard, to, from, record, name, runWithContext = (fn) => fn()) {
	const enterCallbackArray = record && (record.enterCallbacks[name] = record.enterCallbacks[name] || []);
	return () => new Promise((resolve, reject) => {
		const next = (valid) => {
			if (valid === false) reject(createRouterError(ErrorTypes.NAVIGATION_ABORTED, {
				from,
				to
			}));
			else if (valid instanceof Error) reject(valid);
			else if (isRouteLocation(valid)) reject(createRouterError(ErrorTypes.NAVIGATION_GUARD_REDIRECT, {
				from: to,
				to: valid
			}));
			else {
				if (enterCallbackArray && record.enterCallbacks[name] === enterCallbackArray && typeof valid === "function") enterCallbackArray.push(valid);
				resolve();
			}
		};
		const guardReturn = runWithContext(() => guard.call(record && record.instances[name], to, from, canOnlyBeCalledOnce(next, to, from)));
		let guardCall = Promise.resolve(guardReturn);
		if (guard.length < 3) guardCall = guardCall.then(next);
		if (guard.length > 2) {
			const message = `The "next" callback was never called inside of ${guard.name ? "\"" + guard.name + "\"" : ""}:\n${guard.toString()}\n. If you are returning a value instead of calling "next", make sure to remove the "next" parameter from your function.`;
			if (typeof guardReturn === "object" && "then" in guardReturn) guardCall = guardCall.then((resolvedValue) => {
				if (!next._called) {
					warn$1(message);
					return Promise.reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
				}
				return resolvedValue;
			});
			else if (guardReturn !== void 0) {
				if (!next._called) {
					warn$1(message);
					reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
					return;
				}
			}
		}
		guardCall.catch((err) => reject(err));
	});
}
function canOnlyBeCalledOnce(next, to, from) {
	let called = 0;
	return function() {
		if (called++ === 1) warn$1(`The "next" callback was called more than once in one navigation guard when going from "${from.fullPath}" to "${to.fullPath}". It should be called exactly one time in each navigation guard. This will fail in production.`);
		next._called = true;
		if (called === 1) next.apply(null, arguments);
	};
}
function extractComponentsGuards(matched, guardType, to, from, runWithContext = (fn) => fn()) {
	const guards = [];
	for (const record of matched) {
		if (!record.components && record.children && !record.children.length) warn$1(`Record with path "${record.path}" is either missing a "component(s)" or "children" property.`);
		for (const name in record.components) {
			let rawComponent = record.components[name];
			if (!rawComponent || typeof rawComponent !== "object" && typeof rawComponent !== "function") {
				warn$1(`Component "${name}" in record with path "${record.path}" is not a valid component. Received "${String(rawComponent)}".`);
				throw new Error("Invalid route component");
			} else if ("then" in rawComponent) {
				warn$1(`Component "${name}" in record with path "${record.path}" is a Promise instead of a function that returns a Promise. Did you write "import('./MyPage.vue')" instead of "() => import('./MyPage.vue')" ? This will break in production if not fixed.`);
				const promise = rawComponent;
				rawComponent = () => promise;
			} else if (rawComponent.__asyncLoader && !rawComponent.__warnedDefineAsync) {
				rawComponent.__warnedDefineAsync = true;
				warn$1(`Component "${name}" in record with path "${record.path}" is defined using "defineAsyncComponent()". Write "() => import('./MyPage.vue')" instead of "defineAsyncComponent(() => import('./MyPage.vue'))".`);
			}
			if (guardType !== "beforeRouteEnter" && !record.instances[name]) continue;
			if (isRouteComponent(rawComponent)) {
				const guard = (rawComponent.__vccOpts || rawComponent)[guardType];
				guard && guards.push(guardToPromiseFn(guard, to, from, record, name, runWithContext));
			} else {
				let componentPromise = rawComponent();
				if (!("catch" in componentPromise)) {
					warn$1(`Component "${name}" in record with path "${record.path}" is a function that does not return a Promise. If you were passing a functional component, make sure to add a "displayName" to the component. This will break in production if not fixed.`);
					componentPromise = Promise.resolve(componentPromise);
				}
				guards.push(() => componentPromise.then((resolved) => {
					if (!resolved) throw new Error(`Couldn't resolve component "${name}" at "${record.path}"`);
					const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
					record.mods[name] = resolved;
					record.components[name] = resolvedComponent;
					const guard = (resolvedComponent.__vccOpts || resolvedComponent)[guardType];
					return guard && guardToPromiseFn(guard, to, from, record, name, runWithContext)();
				}));
			}
		}
	}
	return guards;
}
/**
* Ensures a route is loaded, so it can be passed as o prop to `<RouterView>`.
*
* @param route - resolved route to load
*/
function loadRouteLocation(route) {
	return route.matched.every((record) => record.redirect) ? Promise.reject(/* @__PURE__ */ new Error("Cannot load a route that redirects.")) : Promise.all(route.matched.map((record) => record.components && Promise.all(Object.keys(record.components).reduce((promises, name) => {
		const rawComponent = record.components[name];
		if (typeof rawComponent === "function" && !("displayName" in rawComponent)) promises.push(rawComponent().then((resolved) => {
			if (!resolved) return Promise.reject(/* @__PURE__ */ new Error(`Couldn't resolve component "${name}" at "${record.path}". Ensure you passed a function that returns a promise.`));
			const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
			record.mods[name] = resolved;
			record.components[name] = resolvedComponent;
		}));
		return promises;
	}, [])))).then(() => route);
}
/**
* Split the leaving, updating, and entering records.
* @internal
*
* @param  to - Location we are navigating to
* @param from - Location we are navigating from
*/
function extractChangingRecords(to, from) {
	const leavingRecords = [];
	const updatingRecords = [];
	const enteringRecords = [];
	const len = Math.max(from.matched.length, to.matched.length);
	for (let i = 0; i < len; i++) {
		const recordFrom = from.matched[i];
		if (recordFrom) if (to.matched.find((record) => isSameRouteRecord(record, recordFrom))) updatingRecords.push(recordFrom);
		else leavingRecords.push(recordFrom);
		const recordTo = to.matched[i];
		if (recordTo) {
			if (!from.matched.find((record) => isSameRouteRecord(record, recordTo))) enteringRecords.push(recordTo);
		}
	}
	return [
		leavingRecords,
		updatingRecords,
		enteringRecords
	];
}
/**
* Copies a route location and removes any problematic properties that cannot be shown in devtools (e.g. Vue instances).
*
* @param routeLocation - routeLocation to format
* @param tooltip - optional tooltip
* @returns a copy of the routeLocation
*/
function formatRouteLocation(routeLocation, tooltip) {
	const copy = assign({}, routeLocation, { matched: routeLocation.matched.map((matched) => omit(matched, [
		"instances",
		"children",
		"aliasOf"
	])) });
	return { _custom: {
		type: null,
		readOnly: true,
		display: routeLocation.fullPath,
		tooltip,
		value: copy
	} };
}
function formatDisplay(display) {
	return { _custom: { display } };
}
var routerId = 0;
function addDevtools(app, router, matcher) {
	if (router.__hasDevtools) return;
	router.__hasDevtools = true;
	const id = routerId++;
	setupDevtoolsPlugin({
		id: "org.vuejs.router" + (id ? "." + id : ""),
		label: "Vue Router",
		packageName: "vue-router",
		homepage: "https://router.vuejs.org",
		logo: "https://router.vuejs.org/logo.png",
		componentStateTypes: ["Routing"],
		app
	}, (api) => {
		if (typeof api.now !== "function") warn$1("[Vue Router]: You seem to be using an outdated version of Vue Devtools. Are you still using the Beta release instead of the stable one? You can find the links at https://devtools.vuejs.org/guide/installation.html.");
		api.on.inspectComponent((payload, ctx) => {
			if (payload.instanceData) payload.instanceData.state.push({
				type: "Routing",
				key: "$route",
				editable: false,
				value: formatRouteLocation(router.currentRoute.value, "Current Route")
			});
		});
		api.on.visitComponentTree(({ treeNode: node, componentInstance }) => {
			if (componentInstance.__vrv_devtools) {
				const info = componentInstance.__vrv_devtools;
				node.tags.push({
					label: (info.name ? `${info.name.toString()}: ` : "") + info.path,
					textColor: 0,
					tooltip: "This component is rendered by &lt;router-view&gt;",
					backgroundColor: PINK_500
				});
			}
			if (isArray(componentInstance.__vrl_devtools)) {
				componentInstance.__devtoolsApi = api;
				componentInstance.__vrl_devtools.forEach((devtoolsData) => {
					let label = devtoolsData.route.path;
					let backgroundColor = ORANGE_400;
					let tooltip = "";
					let textColor = 0;
					if (devtoolsData.error) {
						label = devtoolsData.error;
						backgroundColor = RED_100;
						textColor = RED_700;
					} else if (devtoolsData.isExactActive) {
						backgroundColor = LIME_500;
						tooltip = "This is exactly active";
					} else if (devtoolsData.isActive) {
						backgroundColor = BLUE_600;
						tooltip = "This link is active";
					}
					node.tags.push({
						label,
						textColor,
						tooltip,
						backgroundColor
					});
				});
			}
		});
		watch(router.currentRoute, () => {
			refreshRoutesView();
			api.notifyComponentUpdate();
			api.sendInspectorTree(routerInspectorId);
			api.sendInspectorState(routerInspectorId);
		});
		const navigationsLayerId = "router:navigations:" + id;
		api.addTimelineLayer({
			id: navigationsLayerId,
			label: `Router${id ? " " + id : ""} Navigations`,
			color: 4237508
		});
		router.onError((error, to) => {
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					title: "Error during Navigation",
					subtitle: to.fullPath,
					logType: "error",
					time: api.now(),
					data: { error },
					groupId: to.meta.__navigationId
				}
			});
		});
		let navigationId = 0;
		router.beforeEach((to, from) => {
			const data = {
				guard: formatDisplay("beforeEach"),
				from: formatRouteLocation(from, "Current Location during this navigation"),
				to: formatRouteLocation(to, "Target location")
			};
			Object.defineProperty(to.meta, "__navigationId", { value: navigationId++ });
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					time: api.now(),
					title: "Start of navigation",
					subtitle: to.fullPath,
					data,
					groupId: to.meta.__navigationId
				}
			});
		});
		router.afterEach((to, from, failure) => {
			const data = { guard: formatDisplay("afterEach") };
			if (failure) {
				data.failure = { _custom: {
					type: Error,
					readOnly: true,
					display: failure ? failure.message : "",
					tooltip: "Navigation Failure",
					value: failure
				} };
				data.status = formatDisplay("❌");
			} else data.status = formatDisplay("✅");
			data.from = formatRouteLocation(from, "Current Location during this navigation");
			data.to = formatRouteLocation(to, "Target location");
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					title: "End of navigation",
					subtitle: to.fullPath,
					time: api.now(),
					data,
					logType: failure ? "warning" : "default",
					groupId: to.meta.__navigationId
				}
			});
		});
		/**
		* Inspector of Existing routes
		*/
		const routerInspectorId = "router-inspector:" + id;
		api.addInspector({
			id: routerInspectorId,
			label: "Routes" + (id ? " " + id : ""),
			icon: "book",
			treeFilterPlaceholder: "Search routes"
		});
		function refreshRoutesView() {
			if (!activeRoutesPayload) return;
			const payload = activeRoutesPayload;
			let routes = matcher.getRoutes().filter((route) => !route.parent || !route.parent.record.components);
			routes.forEach(resetMatchStateOnRouteRecord);
			if (payload.filter) routes = routes.filter((route) => isRouteMatching(route, payload.filter.toLowerCase()));
			routes.forEach((route) => markRouteRecordActive(route, router.currentRoute.value));
			payload.rootNodes = routes.map(formatRouteRecordForInspector);
		}
		let activeRoutesPayload;
		api.on.getInspectorTree((payload) => {
			activeRoutesPayload = payload;
			if (payload.app === app && payload.inspectorId === routerInspectorId) refreshRoutesView();
		});
		/**
		* Display information about the currently selected route record
		*/
		api.on.getInspectorState((payload) => {
			if (payload.app === app && payload.inspectorId === routerInspectorId) {
				const route = matcher.getRoutes().find((route$1) => route$1.record.__vd_id === payload.nodeId);
				if (route) payload.state = { options: formatRouteRecordMatcherForStateInspector(route) };
			}
		});
		api.sendInspectorTree(routerInspectorId);
		api.sendInspectorState(routerInspectorId);
	});
}
function modifierForKey(key) {
	if (key.optional) return key.repeatable ? "*" : "?";
	else return key.repeatable ? "+" : "";
}
function formatRouteRecordMatcherForStateInspector(route) {
	const { record } = route;
	const fields = [{
		editable: false,
		key: "path",
		value: record.path
	}];
	if (record.name != null) fields.push({
		editable: false,
		key: "name",
		value: record.name
	});
	fields.push({
		editable: false,
		key: "regexp",
		value: route.re
	});
	if (route.keys.length) fields.push({
		editable: false,
		key: "keys",
		value: { _custom: {
			type: null,
			readOnly: true,
			display: route.keys.map((key) => `${key.name}${modifierForKey(key)}`).join(" "),
			tooltip: "Param keys",
			value: route.keys
		} }
	});
	if (record.redirect != null) fields.push({
		editable: false,
		key: "redirect",
		value: record.redirect
	});
	if (route.alias.length) fields.push({
		editable: false,
		key: "aliases",
		value: route.alias.map((alias) => alias.record.path)
	});
	if (Object.keys(route.record.meta).length) fields.push({
		editable: false,
		key: "meta",
		value: route.record.meta
	});
	fields.push({
		key: "score",
		editable: false,
		value: { _custom: {
			type: null,
			readOnly: true,
			display: route.score.map((score) => score.join(", ")).join(" | "),
			tooltip: "Score used to sort routes",
			value: route.score
		} }
	});
	return fields;
}
/**
* Extracted from tailwind palette
*/
var PINK_500 = 15485081;
var BLUE_600 = 2450411;
var LIME_500 = 8702998;
var CYAN_400 = 2282478;
var ORANGE_400 = 16486972;
var DARK = 6710886;
var RED_100 = 16704226;
var RED_700 = 12131356;
function formatRouteRecordForInspector(route) {
	const tags = [];
	const { record } = route;
	if (record.name != null) tags.push({
		label: String(record.name),
		textColor: 0,
		backgroundColor: CYAN_400
	});
	if (record.aliasOf) tags.push({
		label: "alias",
		textColor: 0,
		backgroundColor: ORANGE_400
	});
	if (route.__vd_match) tags.push({
		label: "matches",
		textColor: 0,
		backgroundColor: PINK_500
	});
	if (route.__vd_exactActive) tags.push({
		label: "exact",
		textColor: 0,
		backgroundColor: LIME_500
	});
	if (route.__vd_active) tags.push({
		label: "active",
		textColor: 0,
		backgroundColor: BLUE_600
	});
	if (record.redirect) tags.push({
		label: typeof record.redirect === "string" ? `redirect: ${record.redirect}` : "redirects",
		textColor: 16777215,
		backgroundColor: DARK
	});
	let id = record.__vd_id;
	if (id == null) {
		id = String(routeRecordId++);
		record.__vd_id = id;
	}
	return {
		id,
		label: record.path,
		tags,
		children: route.children.map(formatRouteRecordForInspector)
	};
}
var routeRecordId = 0;
var EXTRACT_REGEXP_RE = /^\/(.*)\/([a-z]*)$/;
function markRouteRecordActive(route, currentRoute) {
	const isExactActive = currentRoute.matched.length && isSameRouteRecord(currentRoute.matched[currentRoute.matched.length - 1], route.record);
	route.__vd_exactActive = route.__vd_active = isExactActive;
	if (!isExactActive) route.__vd_active = currentRoute.matched.some((match) => isSameRouteRecord(match, route.record));
	route.children.forEach((childRoute) => markRouteRecordActive(childRoute, currentRoute));
}
function resetMatchStateOnRouteRecord(route) {
	route.__vd_match = false;
	route.children.forEach(resetMatchStateOnRouteRecord);
}
function isRouteMatching(route, filter) {
	const found = String(route.re).match(EXTRACT_REGEXP_RE);
	route.__vd_match = false;
	if (!found || found.length < 3) return false;
	if (new RegExp(found[1].replace(/\$$/, ""), found[2]).test(filter)) {
		route.children.forEach((child) => isRouteMatching(child, filter));
		if (route.record.path !== "/" || filter === "/") {
			route.__vd_match = route.re.test(filter);
			return true;
		}
		return false;
	}
	const path = route.record.path.toLowerCase();
	const decodedPath = decode(path);
	if (!filter.startsWith("/") && (decodedPath.includes(filter) || path.includes(filter))) return true;
	if (decodedPath.startsWith(filter) || path.startsWith(filter)) return true;
	if (route.record.name && String(route.record.name).includes(filter)) return true;
	return route.children.some((child) => isRouteMatching(child, filter));
}
function omit(obj, keys) {
	const ret = {};
	for (const key in obj) if (!keys.includes(key)) ret[key] = obj[key];
	return ret;
}
//#endregion
//#region node_modules/vue-router/dist/vue-router.mjs
/*!
* vue-router v4.6.4
* (c) 2025 Eduardo San Martin Morote
* @license MIT
*/
var createBaseLocation = () => location.protocol + "//" + location.host;
/**
* Creates a normalized history location from a window.location object
* @param base - The base path
* @param location - The window.location object
*/
function createCurrentLocation(base, location$1) {
	const { pathname, search, hash } = location$1;
	const hashPos = base.indexOf("#");
	if (hashPos > -1) {
		let slicePos = hash.includes(base.slice(hashPos)) ? base.slice(hashPos).length : 1;
		let pathFromHash = hash.slice(slicePos);
		if (pathFromHash[0] !== "/") pathFromHash = "/" + pathFromHash;
		return stripBase(pathFromHash, "");
	}
	return stripBase(pathname, base) + search + hash;
}
function useHistoryListeners(base, historyState, currentLocation, replace) {
	let listeners = [];
	let teardowns = [];
	let pauseState = null;
	const popStateHandler = ({ state }) => {
		const to = createCurrentLocation(base, location);
		const from = currentLocation.value;
		const fromState = historyState.value;
		let delta = 0;
		if (state) {
			currentLocation.value = to;
			historyState.value = state;
			if (pauseState && pauseState === from) {
				pauseState = null;
				return;
			}
			delta = fromState ? state.position - fromState.position : 0;
		} else replace(to);
		listeners.forEach((listener) => {
			listener(currentLocation.value, from, {
				delta,
				type: NavigationType.pop,
				direction: delta ? delta > 0 ? NavigationDirection.forward : NavigationDirection.back : NavigationDirection.unknown
			});
		});
	};
	function pauseListeners() {
		pauseState = currentLocation.value;
	}
	function listen(callback) {
		listeners.push(callback);
		const teardown = () => {
			const index = listeners.indexOf(callback);
			if (index > -1) listeners.splice(index, 1);
		};
		teardowns.push(teardown);
		return teardown;
	}
	function beforeUnloadListener() {
		if (document.visibilityState === "hidden") {
			const { history: history$1 } = window;
			if (!history$1.state) return;
			history$1.replaceState(assign({}, history$1.state, { scroll: computeScrollPosition() }), "");
		}
	}
	function destroy() {
		for (const teardown of teardowns) teardown();
		teardowns = [];
		window.removeEventListener("popstate", popStateHandler);
		window.removeEventListener("pagehide", beforeUnloadListener);
		document.removeEventListener("visibilitychange", beforeUnloadListener);
	}
	window.addEventListener("popstate", popStateHandler);
	window.addEventListener("pagehide", beforeUnloadListener);
	document.addEventListener("visibilitychange", beforeUnloadListener);
	return {
		pauseListeners,
		listen,
		destroy
	};
}
/**
* Creates a state object
*/
function buildState(back, current, forward, replaced = false, computeScroll = false) {
	return {
		back,
		current,
		forward,
		replaced,
		position: window.history.length,
		scroll: computeScroll ? computeScrollPosition() : null
	};
}
function useHistoryStateNavigation(base) {
	const { history: history$1, location: location$1 } = window;
	const currentLocation = { value: createCurrentLocation(base, location$1) };
	const historyState = { value: history$1.state };
	if (!historyState.value) changeLocation(currentLocation.value, {
		back: null,
		current: currentLocation.value,
		forward: null,
		position: history$1.length - 1,
		replaced: true,
		scroll: null
	}, true);
	function changeLocation(to, state, replace$1) {
		/**
		* if a base tag is provided, and we are on a normal domain, we have to
		* respect the provided `base` attribute because pushState() will use it and
		* potentially erase anything before the `#` like at
		* https://github.com/vuejs/router/issues/685 where a base of
		* `/folder/#` but a base of `/` would erase the `/folder/` section. If
		* there is no host, the `<base>` tag makes no sense and if there isn't a
		* base tag we can just use everything after the `#`.
		*/
		const hashIndex = base.indexOf("#");
		const url = hashIndex > -1 ? (location$1.host && document.querySelector("base") ? base : base.slice(hashIndex)) + to : createBaseLocation() + base + to;
		try {
			history$1[replace$1 ? "replaceState" : "pushState"](state, "", url);
			historyState.value = state;
		} catch (err) {
			warn$1("Error with push/replace State", err);
			location$1[replace$1 ? "replace" : "assign"](url);
		}
	}
	function replace(to, data) {
		changeLocation(to, assign({}, history$1.state, buildState(historyState.value.back, to, historyState.value.forward, true), data, { position: historyState.value.position }), true);
		currentLocation.value = to;
	}
	function push(to, data) {
		const currentState = assign({}, historyState.value, history$1.state, {
			forward: to,
			scroll: computeScrollPosition()
		});
		if (!history$1.state) warn$1("history.state seems to have been manually replaced without preserving the necessary values. Make sure to preserve existing history state if you are manually calling history.replaceState:\n\nhistory.replaceState(history.state, '', url)\n\nYou can find more information at https://router.vuejs.org/guide/migration/#Usage-of-history-state");
		changeLocation(currentState.current, currentState, true);
		changeLocation(to, assign({}, buildState(currentLocation.value, to, null), { position: currentState.position + 1 }, data), false);
		currentLocation.value = to;
	}
	return {
		location: currentLocation,
		state: historyState,
		push,
		replace
	};
}
/**
* Creates an HTML5 history. Most common history for single page applications.
*
* @param base -
*/
function createWebHistory(base) {
	base = normalizeBase(base);
	const historyNavigation = useHistoryStateNavigation(base);
	const historyListeners = useHistoryListeners(base, historyNavigation.state, historyNavigation.location, historyNavigation.replace);
	function go(delta, triggerListeners = true) {
		if (!triggerListeners) historyListeners.pauseListeners();
		history.go(delta);
	}
	const routerHistory = assign({
		location: "",
		base,
		go,
		createHref: createHref.bind(null, base)
	}, historyNavigation, historyListeners);
	Object.defineProperty(routerHistory, "location", {
		enumerable: true,
		get: () => historyNavigation.location.value
	});
	Object.defineProperty(routerHistory, "state", {
		enumerable: true,
		get: () => historyNavigation.state.value
	});
	return routerHistory;
}
/**
* Creates an in-memory based history. The main purpose of this history is to handle SSR. It starts in a special location that is nowhere.
* It's up to the user to replace that location with the starter location by either calling `router.push` or `router.replace`.
*
* @param base - Base applied to all urls, defaults to '/'
* @returns a history object that can be passed to the router constructor
*/
function createMemoryHistory(base = "") {
	let listeners = [];
	let queue = [["", {}]];
	let position = 0;
	base = normalizeBase(base);
	function setLocation(location$1, state = {}) {
		position++;
		if (position !== queue.length) queue.splice(position);
		queue.push([location$1, state]);
	}
	function triggerListeners(to, from, { direction, delta }) {
		const info = {
			direction,
			delta,
			type: NavigationType.pop
		};
		for (const callback of listeners) callback(to, from, info);
	}
	const routerHistory = {
		location: "",
		state: {},
		base,
		createHref: createHref.bind(null, base),
		replace(to, state) {
			queue.splice(position--, 1);
			setLocation(to, state);
		},
		push(to, state) {
			setLocation(to, state);
		},
		listen(callback) {
			listeners.push(callback);
			return () => {
				const index = listeners.indexOf(callback);
				if (index > -1) listeners.splice(index, 1);
			};
		},
		destroy() {
			listeners = [];
			queue = [["", {}]];
			position = 0;
		},
		go(delta, shouldTrigger = true) {
			const from = this.location;
			const direction = delta < 0 ? NavigationDirection.back : NavigationDirection.forward;
			position = Math.max(0, Math.min(position + delta, queue.length - 1));
			if (shouldTrigger) triggerListeners(this.location, from, {
				direction,
				delta
			});
		}
	};
	Object.defineProperty(routerHistory, "location", {
		enumerable: true,
		get: () => queue[position][0]
	});
	Object.defineProperty(routerHistory, "state", {
		enumerable: true,
		get: () => queue[position][1]
	});
	return routerHistory;
}
/**
* Creates a hash history. Useful for web applications with no host (e.g. `file://`) or when configuring a server to
* handle any URL is not possible.
*
* @param base - optional base to provide. Defaults to `location.pathname + location.search` If there is a `<base>` tag
* in the `head`, its value will be ignored in favor of this parameter **but note it affects all the history.pushState()
* calls**, meaning that if you use a `<base>` tag, it's `href` value **has to match this parameter** (ignoring anything
* after the `#`).
*
* @example
* ```js
* // at https://example.com/folder
* createWebHashHistory() // gives a url of `https://example.com/folder#`
* createWebHashHistory('/folder/') // gives a url of `https://example.com/folder/#`
* // if the `#` is provided in the base, it won't be added by `createWebHashHistory`
* createWebHashHistory('/folder/#/app/') // gives a url of `https://example.com/folder/#/app/`
* // you should avoid doing this because it changes the original url and breaks copying urls
* createWebHashHistory('/other-folder/') // gives a url of `https://example.com/other-folder/#`
*
* // at file:///usr/etc/folder/index.html
* // for locations with no `host`, the base is ignored
* createWebHashHistory('/iAmIgnored') // gives a url of `file:///usr/etc/folder/index.html#`
* ```
*/
function createWebHashHistory(base) {
	base = location.host ? base || location.pathname + location.search : "";
	if (!base.includes("#")) base += "#";
	if (!base.endsWith("#/") && !base.endsWith("#")) warn$1(`A hash base must end with a "#":\n"${base}" should be "${base.replace(/#.*$/, "#")}".`);
	return createWebHistory(base);
}
var TokenType = /* @__PURE__ */ function(TokenType$1) {
	TokenType$1[TokenType$1["Static"] = 0] = "Static";
	TokenType$1[TokenType$1["Param"] = 1] = "Param";
	TokenType$1[TokenType$1["Group"] = 2] = "Group";
	return TokenType$1;
}({});
var TokenizerState = /* @__PURE__ */ function(TokenizerState$1) {
	TokenizerState$1[TokenizerState$1["Static"] = 0] = "Static";
	TokenizerState$1[TokenizerState$1["Param"] = 1] = "Param";
	TokenizerState$1[TokenizerState$1["ParamRegExp"] = 2] = "ParamRegExp";
	TokenizerState$1[TokenizerState$1["ParamRegExpEnd"] = 3] = "ParamRegExpEnd";
	TokenizerState$1[TokenizerState$1["EscapeNext"] = 4] = "EscapeNext";
	return TokenizerState$1;
}(TokenizerState || {});
var ROOT_TOKEN = {
	type: TokenType.Static,
	value: ""
};
var VALID_PARAM_RE = /[a-zA-Z0-9_]/;
function tokenizePath(path) {
	if (!path) return [[]];
	if (path === "/") return [[ROOT_TOKEN]];
	if (!path.startsWith("/")) throw new Error(`Route paths should start with a "/": "${path}" should be "/${path}".`);
	function crash(message) {
		throw new Error(`ERR (${state})/"${buffer}": ${message}`);
	}
	let state = TokenizerState.Static;
	let previousState = state;
	const tokens = [];
	let segment;
	function finalizeSegment() {
		if (segment) tokens.push(segment);
		segment = [];
	}
	let i = 0;
	let char;
	let buffer = "";
	let customRe = "";
	function consumeBuffer() {
		if (!buffer) return;
		if (state === TokenizerState.Static) segment.push({
			type: TokenType.Static,
			value: buffer
		});
		else if (state === TokenizerState.Param || state === TokenizerState.ParamRegExp || state === TokenizerState.ParamRegExpEnd) {
			if (segment.length > 1 && (char === "*" || char === "+")) crash(`A repeatable param (${buffer}) must be alone in its segment. eg: '/:ids+.`);
			segment.push({
				type: TokenType.Param,
				value: buffer,
				regexp: customRe,
				repeatable: char === "*" || char === "+",
				optional: char === "*" || char === "?"
			});
		} else crash("Invalid state to consume buffer");
		buffer = "";
	}
	function addCharToBuffer() {
		buffer += char;
	}
	while (i < path.length) {
		char = path[i++];
		if (char === "\\" && state !== TokenizerState.ParamRegExp) {
			previousState = state;
			state = TokenizerState.EscapeNext;
			continue;
		}
		switch (state) {
			case TokenizerState.Static:
				if (char === "/") {
					if (buffer) consumeBuffer();
					finalizeSegment();
				} else if (char === ":") {
					consumeBuffer();
					state = TokenizerState.Param;
				} else addCharToBuffer();
				break;
			case TokenizerState.EscapeNext:
				addCharToBuffer();
				state = previousState;
				break;
			case TokenizerState.Param:
				if (char === "(") state = TokenizerState.ParamRegExp;
				else if (VALID_PARAM_RE.test(char)) addCharToBuffer();
				else {
					consumeBuffer();
					state = TokenizerState.Static;
					if (char !== "*" && char !== "?" && char !== "+") i--;
				}
				break;
			case TokenizerState.ParamRegExp:
				if (char === ")") if (customRe[customRe.length - 1] == "\\") customRe = customRe.slice(0, -1) + char;
				else state = TokenizerState.ParamRegExpEnd;
				else customRe += char;
				break;
			case TokenizerState.ParamRegExpEnd:
				consumeBuffer();
				state = TokenizerState.Static;
				if (char !== "*" && char !== "?" && char !== "+") i--;
				customRe = "";
				break;
			default: crash("Unknown state");
		}
	}
	if (state === TokenizerState.ParamRegExp) crash(`Unfinished custom RegExp for param "${buffer}"`);
	consumeBuffer();
	finalizeSegment();
	return tokens;
}
var BASE_PARAM_PATTERN = "[^/]+?";
var BASE_PATH_PARSER_OPTIONS = {
	sensitive: false,
	strict: false,
	start: true,
	end: true
};
var PathScore = /* @__PURE__ */ function(PathScore$1) {
	PathScore$1[PathScore$1["_multiplier"] = 10] = "_multiplier";
	PathScore$1[PathScore$1["Root"] = 90] = "Root";
	PathScore$1[PathScore$1["Segment"] = 40] = "Segment";
	PathScore$1[PathScore$1["SubSegment"] = 30] = "SubSegment";
	PathScore$1[PathScore$1["Static"] = 40] = "Static";
	PathScore$1[PathScore$1["Dynamic"] = 20] = "Dynamic";
	PathScore$1[PathScore$1["BonusCustomRegExp"] = 10] = "BonusCustomRegExp";
	PathScore$1[PathScore$1["BonusWildcard"] = -50] = "BonusWildcard";
	PathScore$1[PathScore$1["BonusRepeatable"] = -20] = "BonusRepeatable";
	PathScore$1[PathScore$1["BonusOptional"] = -8] = "BonusOptional";
	PathScore$1[PathScore$1["BonusStrict"] = .7000000000000001] = "BonusStrict";
	PathScore$1[PathScore$1["BonusCaseSensitive"] = .25] = "BonusCaseSensitive";
	return PathScore$1;
}(PathScore || {});
var REGEX_CHARS_RE = /[.+*?^${}()[\]/\\]/g;
/**
* Creates a path parser from an array of Segments (a segment is an array of Tokens)
*
* @param segments - array of segments returned by tokenizePath
* @param extraOptions - optional options for the regexp
* @returns a PathParser
*/
function tokensToParser(segments, extraOptions) {
	const options = assign({}, BASE_PATH_PARSER_OPTIONS, extraOptions);
	const score = [];
	let pattern = options.start ? "^" : "";
	const keys = [];
	for (const segment of segments) {
		const segmentScores = segment.length ? [] : [PathScore.Root];
		if (options.strict && !segment.length) pattern += "/";
		for (let tokenIndex = 0; tokenIndex < segment.length; tokenIndex++) {
			const token = segment[tokenIndex];
			let subSegmentScore = PathScore.Segment + (options.sensitive ? PathScore.BonusCaseSensitive : 0);
			if (token.type === TokenType.Static) {
				if (!tokenIndex) pattern += "/";
				pattern += token.value.replace(REGEX_CHARS_RE, "\\$&");
				subSegmentScore += PathScore.Static;
			} else if (token.type === TokenType.Param) {
				const { value, repeatable, optional, regexp } = token;
				keys.push({
					name: value,
					repeatable,
					optional
				});
				const re$1 = regexp ? regexp : BASE_PARAM_PATTERN;
				if (re$1 !== BASE_PARAM_PATTERN) {
					subSegmentScore += PathScore.BonusCustomRegExp;
					try {
						`${re$1}`;
					} catch (err) {
						throw new Error(`Invalid custom RegExp for param "${value}" (${re$1}): ` + err.message);
					}
				}
				let subPattern = repeatable ? `((?:${re$1})(?:/(?:${re$1}))*)` : `(${re$1})`;
				if (!tokenIndex) subPattern = optional && segment.length < 2 ? `(?:/${subPattern})` : "/" + subPattern;
				if (optional) subPattern += "?";
				pattern += subPattern;
				subSegmentScore += PathScore.Dynamic;
				if (optional) subSegmentScore += PathScore.BonusOptional;
				if (repeatable) subSegmentScore += PathScore.BonusRepeatable;
				if (re$1 === ".*") subSegmentScore += PathScore.BonusWildcard;
			}
			segmentScores.push(subSegmentScore);
		}
		score.push(segmentScores);
	}
	if (options.strict && options.end) {
		const i = score.length - 1;
		score[i][score[i].length - 1] += PathScore.BonusStrict;
	}
	if (!options.strict) pattern += "/?";
	if (options.end) pattern += "$";
	else if (options.strict && !pattern.endsWith("/")) pattern += "(?:/|$)";
	const re = new RegExp(pattern, options.sensitive ? "" : "i");
	function parse(path) {
		const match = path.match(re);
		const params = {};
		if (!match) return null;
		for (let i = 1; i < match.length; i++) {
			const value = match[i] || "";
			const key = keys[i - 1];
			params[key.name] = value && key.repeatable ? value.split("/") : value;
		}
		return params;
	}
	function stringify(params) {
		let path = "";
		let avoidDuplicatedSlash = false;
		for (const segment of segments) {
			if (!avoidDuplicatedSlash || !path.endsWith("/")) path += "/";
			avoidDuplicatedSlash = false;
			for (const token of segment) if (token.type === TokenType.Static) path += token.value;
			else if (token.type === TokenType.Param) {
				const { value, repeatable, optional } = token;
				const param = value in params ? params[value] : "";
				if (isArray(param) && !repeatable) throw new Error(`Provided param "${value}" is an array but it is not repeatable (* or + modifiers)`);
				const text = isArray(param) ? param.join("/") : param;
				if (!text) if (optional) {
					if (segment.length < 2) if (path.endsWith("/")) path = path.slice(0, -1);
					else avoidDuplicatedSlash = true;
				} else throw new Error(`Missing required param "${value}"`);
				path += text;
			}
		}
		return path || "/";
	}
	return {
		re,
		score,
		keys,
		parse,
		stringify
	};
}
/**
* Compares an array of numbers as used in PathParser.score and returns a
* number. This function can be used to `sort` an array
*
* @param a - first array of numbers
* @param b - second array of numbers
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
* should be sorted first
*/
function compareScoreArray(a, b) {
	let i = 0;
	while (i < a.length && i < b.length) {
		const diff = b[i] - a[i];
		if (diff) return diff;
		i++;
	}
	if (a.length < b.length) return a.length === 1 && a[0] === PathScore.Static + PathScore.Segment ? -1 : 1;
	else if (a.length > b.length) return b.length === 1 && b[0] === PathScore.Static + PathScore.Segment ? 1 : -1;
	return 0;
}
/**
* Compare function that can be used with `sort` to sort an array of PathParser
*
* @param a - first PathParser
* @param b - second PathParser
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
*/
function comparePathParserScore(a, b) {
	let i = 0;
	const aScore = a.score;
	const bScore = b.score;
	while (i < aScore.length && i < bScore.length) {
		const comp = compareScoreArray(aScore[i], bScore[i]);
		if (comp) return comp;
		i++;
	}
	if (Math.abs(bScore.length - aScore.length) === 1) {
		if (isLastScoreNegative(aScore)) return 1;
		if (isLastScoreNegative(bScore)) return -1;
	}
	return bScore.length - aScore.length;
}
/**
* This allows detecting splats at the end of a path: /home/:id(.*)*
*
* @param score - score to check
* @returns true if the last entry is negative
*/
function isLastScoreNegative(score) {
	const last = score[score.length - 1];
	return score.length > 0 && last[last.length - 1] < 0;
}
var PATH_PARSER_OPTIONS_DEFAULTS = {
	strict: false,
	end: true,
	sensitive: false
};
function createRouteRecordMatcher(record, parent, options) {
	const parser = tokensToParser(tokenizePath(record.path), options);
	{
		const existingKeys = /* @__PURE__ */ new Set();
		for (const key of parser.keys) {
			if (existingKeys.has(key.name)) warn$1(`Found duplicated params with name "${key.name}" for path "${record.path}". Only the last one will be available on "$route.params".`);
			existingKeys.add(key.name);
		}
	}
	const matcher = assign(parser, {
		record,
		parent,
		children: [],
		alias: []
	});
	if (parent) {
		if (!matcher.record.aliasOf === !parent.record.aliasOf) parent.children.push(matcher);
	}
	return matcher;
}
/**
* Creates a Router Matcher.
*
* @internal
* @param routes - array of initial routes
* @param globalOptions - global route options
*/
function createRouterMatcher(routes, globalOptions) {
	const matchers = [];
	const matcherMap = /* @__PURE__ */ new Map();
	globalOptions = mergeOptions(PATH_PARSER_OPTIONS_DEFAULTS, globalOptions);
	function getRecordMatcher(name) {
		return matcherMap.get(name);
	}
	function addRoute(record, parent, originalRecord) {
		const isRootAdd = !originalRecord;
		const mainNormalizedRecord = normalizeRouteRecord(record);
		checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent);
		mainNormalizedRecord.aliasOf = originalRecord && originalRecord.record;
		const options = mergeOptions(globalOptions, record);
		const normalizedRecords = [mainNormalizedRecord];
		if ("alias" in record) {
			const aliases = typeof record.alias === "string" ? [record.alias] : record.alias;
			for (const alias of aliases) normalizedRecords.push(normalizeRouteRecord(assign({}, mainNormalizedRecord, {
				components: originalRecord ? originalRecord.record.components : mainNormalizedRecord.components,
				path: alias,
				aliasOf: originalRecord ? originalRecord.record : mainNormalizedRecord
			})));
		}
		let matcher;
		let originalMatcher;
		for (const normalizedRecord of normalizedRecords) {
			const { path } = normalizedRecord;
			if (parent && path[0] !== "/") {
				const parentPath = parent.record.path;
				const connectingSlash = parentPath[parentPath.length - 1] === "/" ? "" : "/";
				normalizedRecord.path = parent.record.path + (path && connectingSlash + path);
			}
			if (normalizedRecord.path === "*") throw new Error("Catch all routes (\"*\") must now be defined using a param with a custom regexp.\nSee more at https://router.vuejs.org/guide/migration/#Removed-star-or-catch-all-routes.");
			matcher = createRouteRecordMatcher(normalizedRecord, parent, options);
			if (parent && path[0] === "/") checkMissingParamsInAbsolutePath(matcher, parent);
			if (originalRecord) {
				originalRecord.alias.push(matcher);
				checkSameParams(originalRecord, matcher);
			} else {
				originalMatcher = originalMatcher || matcher;
				if (originalMatcher !== matcher) originalMatcher.alias.push(matcher);
				if (isRootAdd && record.name && !isAliasRecord(matcher)) {
					checkSameNameAsAncestor(record, parent);
					removeRoute(record.name);
				}
			}
			if (isMatchable(matcher)) insertMatcher(matcher);
			if (mainNormalizedRecord.children) {
				const children = mainNormalizedRecord.children;
				for (let i = 0; i < children.length; i++) addRoute(children[i], matcher, originalRecord && originalRecord.children[i]);
			}
			originalRecord = originalRecord || matcher;
		}
		return originalMatcher ? () => {
			removeRoute(originalMatcher);
		} : noop;
	}
	function removeRoute(matcherRef) {
		if (isRouteName(matcherRef)) {
			const matcher = matcherMap.get(matcherRef);
			if (matcher) {
				matcherMap.delete(matcherRef);
				matchers.splice(matchers.indexOf(matcher), 1);
				matcher.children.forEach(removeRoute);
				matcher.alias.forEach(removeRoute);
			}
		} else {
			const index = matchers.indexOf(matcherRef);
			if (index > -1) {
				matchers.splice(index, 1);
				if (matcherRef.record.name) matcherMap.delete(matcherRef.record.name);
				matcherRef.children.forEach(removeRoute);
				matcherRef.alias.forEach(removeRoute);
			}
		}
	}
	function getRoutes() {
		return matchers;
	}
	function insertMatcher(matcher) {
		const index = findInsertionIndex(matcher, matchers);
		matchers.splice(index, 0, matcher);
		if (matcher.record.name && !isAliasRecord(matcher)) matcherMap.set(matcher.record.name, matcher);
	}
	function resolve(location$1, currentLocation) {
		let matcher;
		let params = {};
		let path;
		let name;
		if ("name" in location$1 && location$1.name) {
			matcher = matcherMap.get(location$1.name);
			if (!matcher) throw createRouterError(ErrorTypes.MATCHER_NOT_FOUND, { location: location$1 });
			{
				const invalidParams = Object.keys(location$1.params || {}).filter((paramName) => !matcher.keys.find((k) => k.name === paramName));
				if (invalidParams.length) warn$1(`Discarded invalid param(s) "${invalidParams.join("\", \"")}" when navigating. See https://github.com/vuejs/router/blob/main/packages/router/CHANGELOG.md#414-2022-08-22 for more details.`);
			}
			name = matcher.record.name;
			params = assign(pickParams(currentLocation.params, matcher.keys.filter((k) => !k.optional).concat(matcher.parent ? matcher.parent.keys.filter((k) => k.optional) : []).map((k) => k.name)), location$1.params && pickParams(location$1.params, matcher.keys.map((k) => k.name)));
			path = matcher.stringify(params);
		} else if (location$1.path != null) {
			path = location$1.path;
			if (!path.startsWith("/")) warn$1(`The Matcher cannot resolve relative paths but received "${path}". Unless you directly called \`matcher.resolve("${path}")\`, this is probably a bug in vue-router. Please open an issue at https://github.com/vuejs/router/issues/new/choose.`);
			matcher = matchers.find((m) => m.re.test(path));
			if (matcher) {
				params = matcher.parse(path);
				name = matcher.record.name;
			}
		} else {
			matcher = currentLocation.name ? matcherMap.get(currentLocation.name) : matchers.find((m) => m.re.test(currentLocation.path));
			if (!matcher) throw createRouterError(ErrorTypes.MATCHER_NOT_FOUND, {
				location: location$1,
				currentLocation
			});
			name = matcher.record.name;
			params = assign({}, currentLocation.params, location$1.params);
			path = matcher.stringify(params);
		}
		const matched = [];
		let parentMatcher = matcher;
		while (parentMatcher) {
			matched.unshift(parentMatcher.record);
			parentMatcher = parentMatcher.parent;
		}
		return {
			name,
			path,
			params,
			matched,
			meta: mergeMetaFields(matched)
		};
	}
	routes.forEach((route) => addRoute(route));
	function clearRoutes() {
		matchers.length = 0;
		matcherMap.clear();
	}
	return {
		addRoute,
		resolve,
		removeRoute,
		clearRoutes,
		getRoutes,
		getRecordMatcher
	};
}
/**
* Picks an object param to contain only specified keys.
*
* @param params - params object to pick from
* @param keys - keys to pick
*/
function pickParams(params, keys) {
	const newParams = {};
	for (const key of keys) if (key in params) newParams[key] = params[key];
	return newParams;
}
/**
* Normalizes a RouteRecordRaw. Creates a copy
*
* @param record
* @returns the normalized version
*/
function normalizeRouteRecord(record) {
	const normalized = {
		path: record.path,
		redirect: record.redirect,
		name: record.name,
		meta: record.meta || {},
		aliasOf: record.aliasOf,
		beforeEnter: record.beforeEnter,
		props: normalizeRecordProps(record),
		children: record.children || [],
		instances: {},
		leaveGuards: /* @__PURE__ */ new Set(),
		updateGuards: /* @__PURE__ */ new Set(),
		enterCallbacks: {},
		components: "components" in record ? record.components || null : record.component && { default: record.component }
	};
	Object.defineProperty(normalized, "mods", { value: {} });
	return normalized;
}
/**
* Normalize the optional `props` in a record to always be an object similar to
* components. Also accept a boolean for components.
* @param record
*/
function normalizeRecordProps(record) {
	const propsObject = {};
	const props = record.props || false;
	if ("component" in record) propsObject.default = props;
	else for (const name in record.components) propsObject[name] = typeof props === "object" ? props[name] : props;
	return propsObject;
}
/**
* Checks if a record or any of its parent is an alias
* @param record
*/
function isAliasRecord(record) {
	while (record) {
		if (record.record.aliasOf) return true;
		record = record.parent;
	}
	return false;
}
/**
* Merge meta fields of an array of records
*
* @param matched - array of matched records
*/
function mergeMetaFields(matched) {
	return matched.reduce((meta, record) => assign(meta, record.meta), {});
}
function isSameParam(a, b) {
	return a.name === b.name && a.optional === b.optional && a.repeatable === b.repeatable;
}
/**
* Check if a path and its alias have the same required params
*
* @param a - original record
* @param b - alias record
*/
function checkSameParams(a, b) {
	for (const key of a.keys) if (!key.optional && !b.keys.find(isSameParam.bind(null, key))) return warn$1(`Alias "${b.record.path}" and the original record: "${a.record.path}" must have the exact same param named "${key.name}"`);
	for (const key of b.keys) if (!key.optional && !a.keys.find(isSameParam.bind(null, key))) return warn$1(`Alias "${b.record.path}" and the original record: "${a.record.path}" must have the exact same param named "${key.name}"`);
}
/**
* A route with a name and a child with an empty path without a name should warn when adding the route
*
* @param mainNormalizedRecord - RouteRecordNormalized
* @param parent - RouteRecordMatcher
*/
function checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent) {
	if (parent && parent.record.name && !mainNormalizedRecord.name && !mainNormalizedRecord.path) warn$1(`The route named "${String(parent.record.name)}" has a child without a name and an empty path. Using that name won't render the empty path child so you probably want to move the name to the child instead. If this is intentional, add a name to the child route to remove the warning.`);
}
function checkSameNameAsAncestor(record, parent) {
	for (let ancestor = parent; ancestor; ancestor = ancestor.parent) if (ancestor.record.name === record.name) throw new Error(`A route named "${String(record.name)}" has been added as a ${parent === ancestor ? "child" : "descendant"} of a route with the same name. Route names must be unique and a nested route cannot use the same name as an ancestor.`);
}
function checkMissingParamsInAbsolutePath(record, parent) {
	for (const key of parent.keys) if (!record.keys.find(isSameParam.bind(null, key))) return warn$1(`Absolute path "${record.record.path}" must have the exact same param named "${key.name}" as its parent "${parent.record.path}".`);
}
/**
* Performs a binary search to find the correct insertion index for a new matcher.
*
* Matchers are primarily sorted by their score. If scores are tied then we also consider parent/child relationships,
* with descendants coming before ancestors. If there's still a tie, new routes are inserted after existing routes.
*
* @param matcher - new matcher to be inserted
* @param matchers - existing matchers
*/
function findInsertionIndex(matcher, matchers) {
	let lower = 0;
	let upper = matchers.length;
	while (lower !== upper) {
		const mid = lower + upper >> 1;
		if (comparePathParserScore(matcher, matchers[mid]) < 0) upper = mid;
		else lower = mid + 1;
	}
	const insertionAncestor = getInsertionAncestor(matcher);
	if (insertionAncestor) {
		upper = matchers.lastIndexOf(insertionAncestor, upper - 1);
		if (upper < 0) warn$1(`Finding ancestor route "${insertionAncestor.record.path}" failed for "${matcher.record.path}"`);
	}
	return upper;
}
function getInsertionAncestor(matcher) {
	let ancestor = matcher;
	while (ancestor = ancestor.parent) if (isMatchable(ancestor) && comparePathParserScore(matcher, ancestor) === 0) return ancestor;
}
/**
* Checks if a matcher can be reachable. This means if it's possible to reach it as a route. For example, routes without
* a component, or name, or redirect, are just used to group other routes.
* @param matcher
* @param matcher.record record of the matcher
* @returns
*/
function isMatchable({ record }) {
	return !!(record.name || record.components && Object.keys(record.components).length || record.redirect);
}
/**
* Returns the internal behavior of a {@link RouterLink} without the rendering part.
*
* @param props - a `to` location and an optional `replace` flag
*/
function useLink(props) {
	const router = inject(routerKey);
	const currentRoute = inject(routeLocationKey);
	let hasPrevious = false;
	let previousTo = null;
	const route = computed(() => {
		const to = unref(props.to);
		if (!hasPrevious || to !== previousTo) {
			if (!isRouteLocation(to)) if (hasPrevious) warn$1(`Invalid value for prop "to" in useLink()\n- to:`, to, `\n- previous to:`, previousTo, `\n- props:`, props);
			else warn$1(`Invalid value for prop "to" in useLink()\n- to:`, to, `\n- props:`, props);
			previousTo = to;
			hasPrevious = true;
		}
		return router.resolve(to);
	});
	const activeRecordIndex = computed(() => {
		const { matched } = route.value;
		const { length } = matched;
		const routeMatched = matched[length - 1];
		const currentMatched = currentRoute.matched;
		if (!routeMatched || !currentMatched.length) return -1;
		const index = currentMatched.findIndex(isSameRouteRecord.bind(null, routeMatched));
		if (index > -1) return index;
		const parentRecordPath = getOriginalPath(matched[length - 2]);
		return length > 1 && getOriginalPath(routeMatched) === parentRecordPath && currentMatched[currentMatched.length - 1].path !== parentRecordPath ? currentMatched.findIndex(isSameRouteRecord.bind(null, matched[length - 2])) : index;
	});
	const isActive = computed(() => activeRecordIndex.value > -1 && includesParams(currentRoute.params, route.value.params));
	const isExactActive = computed(() => activeRecordIndex.value > -1 && activeRecordIndex.value === currentRoute.matched.length - 1 && isSameRouteLocationParams(currentRoute.params, route.value.params));
	function navigate(e = {}) {
		if (guardEvent(e)) {
			const p = router[unref(props.replace) ? "replace" : "push"](unref(props.to)).catch(noop);
			if (props.viewTransition && typeof document !== "undefined" && "startViewTransition" in document) document.startViewTransition(() => p);
			return p;
		}
		return Promise.resolve();
	}
	if (isBrowser) {
		const instance = getCurrentInstance();
		if (instance) {
			const linkContextDevtools = {
				route: route.value,
				isActive: isActive.value,
				isExactActive: isExactActive.value,
				error: null
			};
			instance.__vrl_devtools = instance.__vrl_devtools || [];
			instance.__vrl_devtools.push(linkContextDevtools);
			watchEffect(() => {
				linkContextDevtools.route = route.value;
				linkContextDevtools.isActive = isActive.value;
				linkContextDevtools.isExactActive = isExactActive.value;
				linkContextDevtools.error = isRouteLocation(unref(props.to)) ? null : "Invalid \"to\" value";
			}, { flush: "post" });
		}
	}
	/**
	* NOTE: update {@link _RouterLinkI}'s `$slots` type when updating this
	*/
	return {
		route,
		href: computed(() => route.value.href),
		isActive,
		isExactActive,
		navigate
	};
}
function preferSingleVNode(vnodes) {
	return vnodes.length === 1 ? vnodes[0] : vnodes;
}
/**
* Component to render a link that triggers a navigation on click.
*/
var RouterLink = /* @__PURE__ */ defineComponent({
	name: "RouterLink",
	compatConfig: { MODE: 3 },
	props: {
		to: {
			type: [String, Object],
			required: true
		},
		replace: Boolean,
		activeClass: String,
		exactActiveClass: String,
		custom: Boolean,
		ariaCurrentValue: {
			type: String,
			default: "page"
		},
		viewTransition: Boolean
	},
	useLink,
	setup(props, { slots }) {
		const link = reactive(useLink(props));
		const { options } = inject(routerKey);
		const elClass = computed(() => ({
			[getLinkClass(props.activeClass, options.linkActiveClass, "router-link-active")]: link.isActive,
			[getLinkClass(props.exactActiveClass, options.linkExactActiveClass, "router-link-exact-active")]: link.isExactActive
		}));
		return () => {
			const children = slots.default && preferSingleVNode(slots.default(link));
			return props.custom ? children : h("a", {
				"aria-current": link.isExactActive ? props.ariaCurrentValue : null,
				href: link.href,
				onClick: link.navigate,
				class: elClass.value
			}, children);
		};
	}
});
function guardEvent(e) {
	if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) return;
	if (e.defaultPrevented) return;
	if (e.button !== void 0 && e.button !== 0) return;
	if (e.currentTarget && e.currentTarget.getAttribute) {
		const target = e.currentTarget.getAttribute("target");
		if (/\b_blank\b/i.test(target)) return;
	}
	if (e.preventDefault) e.preventDefault();
	return true;
}
function includesParams(outer, inner) {
	for (const key in inner) {
		const innerValue = inner[key];
		const outerValue = outer[key];
		if (typeof innerValue === "string") {
			if (innerValue !== outerValue) return false;
		} else if (!isArray(outerValue) || outerValue.length !== innerValue.length || innerValue.some((value, i) => value.valueOf() !== outerValue[i].valueOf())) return false;
	}
	return true;
}
/**
* Get the original path value of a record by following its aliasOf
* @param record
*/
function getOriginalPath(record) {
	return record ? record.aliasOf ? record.aliasOf.path : record.path : "";
}
/**
* Utility class to get the active class based on defaults.
* @param propClass
* @param globalClass
* @param defaultClass
*/
var getLinkClass = (propClass, globalClass, defaultClass) => propClass != null ? propClass : globalClass != null ? globalClass : defaultClass;
var RouterViewImpl = /* @__PURE__ */ defineComponent({
	name: "RouterView",
	inheritAttrs: false,
	props: {
		name: {
			type: String,
			default: "default"
		},
		route: Object
	},
	compatConfig: { MODE: 3 },
	setup(props, { attrs, slots }) {
		warnDeprecatedUsage();
		const injectedRoute = inject(routerViewLocationKey);
		const routeToDisplay = computed(() => props.route || injectedRoute.value);
		const injectedDepth = inject(viewDepthKey, 0);
		const depth = computed(() => {
			let initialDepth = unref(injectedDepth);
			const { matched } = routeToDisplay.value;
			let matchedRoute;
			while ((matchedRoute = matched[initialDepth]) && !matchedRoute.components) initialDepth++;
			return initialDepth;
		});
		const matchedRouteRef = computed(() => routeToDisplay.value.matched[depth.value]);
		provide(viewDepthKey, computed(() => depth.value + 1));
		provide(matchedRouteKey, matchedRouteRef);
		provide(routerViewLocationKey, routeToDisplay);
		const viewRef = ref();
		watch(() => [
			viewRef.value,
			matchedRouteRef.value,
			props.name
		], ([instance, to, name], [oldInstance, from, oldName]) => {
			if (to) {
				to.instances[name] = instance;
				if (from && from !== to && instance && instance === oldInstance) {
					if (!to.leaveGuards.size) to.leaveGuards = from.leaveGuards;
					if (!to.updateGuards.size) to.updateGuards = from.updateGuards;
				}
			}
			if (instance && to && (!from || !isSameRouteRecord(to, from) || !oldInstance)) (to.enterCallbacks[name] || []).forEach((callback) => callback(instance));
		}, { flush: "post" });
		return () => {
			const route = routeToDisplay.value;
			const currentName = props.name;
			const matchedRoute = matchedRouteRef.value;
			const ViewComponent = matchedRoute && matchedRoute.components[currentName];
			if (!ViewComponent) return normalizeSlot(slots.default, {
				Component: ViewComponent,
				route
			});
			const routePropsOption = matchedRoute.props[currentName];
			const routeProps = routePropsOption ? routePropsOption === true ? route.params : typeof routePropsOption === "function" ? routePropsOption(route) : routePropsOption : null;
			const onVnodeUnmounted = (vnode) => {
				if (vnode.component.isUnmounted) matchedRoute.instances[currentName] = null;
			};
			const component = h(ViewComponent, assign({}, routeProps, attrs, {
				onVnodeUnmounted,
				ref: viewRef
			}));
			if (isBrowser && component.ref) {
				const info = {
					depth: depth.value,
					name: matchedRoute.name,
					path: matchedRoute.path,
					meta: matchedRoute.meta
				};
				(isArray(component.ref) ? component.ref.map((r) => r.i) : [component.ref.i]).forEach((instance) => {
					instance.__vrv_devtools = info;
				});
			}
			return normalizeSlot(slots.default, {
				Component: component,
				route
			}) || component;
		};
	}
});
function normalizeSlot(slot, data) {
	if (!slot) return null;
	const slotContent = slot(data);
	return slotContent.length === 1 ? slotContent[0] : slotContent;
}
/**
* Component to display the current route the user is at.
*/
var RouterView = RouterViewImpl;
function warnDeprecatedUsage() {
	const instance = getCurrentInstance();
	const parentName = instance.parent && instance.parent.type.name;
	const parentSubTreeType = instance.parent && instance.parent.subTree && instance.parent.subTree.type;
	if (parentName && (parentName === "KeepAlive" || parentName.includes("Transition")) && typeof parentSubTreeType === "object" && parentSubTreeType.name === "RouterView") {
		const comp = parentName === "KeepAlive" ? "keep-alive" : "transition";
		warn$1(`<router-view> can no longer be used directly inside <transition> or <keep-alive>.
Use slot props instead:

<router-view v-slot="{ Component }">
  <${comp}>\n    <component :is="Component" />\n  </${comp}>\n</router-view>`);
	}
}
/**
* Creates a Router instance that can be used by a Vue app.
*
* @param options - {@link RouterOptions}
*/
function createRouter(options) {
	const matcher = createRouterMatcher(options.routes, options);
	const parseQuery$1 = options.parseQuery || parseQuery;
	const stringifyQuery$1 = options.stringifyQuery || stringifyQuery;
	const routerHistory = options.history;
	if (!routerHistory) throw new Error("Provide the \"history\" option when calling \"createRouter()\": https://router.vuejs.org/api/interfaces/RouterOptions.html#history");
	const beforeGuards = useCallbacks();
	const beforeResolveGuards = useCallbacks();
	const afterGuards = useCallbacks();
	const currentRoute = shallowRef(START_LOCATION_NORMALIZED);
	let pendingLocation = START_LOCATION_NORMALIZED;
	if (isBrowser && options.scrollBehavior && "scrollRestoration" in history) history.scrollRestoration = "manual";
	const normalizeParams = applyToParams.bind(null, (paramValue) => "" + paramValue);
	const encodeParams = applyToParams.bind(null, encodeParam);
	const decodeParams = applyToParams.bind(null, decode);
	function addRoute(parentOrRoute, route) {
		let parent;
		let record;
		if (isRouteName(parentOrRoute)) {
			parent = matcher.getRecordMatcher(parentOrRoute);
			if (!parent) warn$1(`Parent route "${String(parentOrRoute)}" not found when adding child route`, route);
			record = route;
		} else record = parentOrRoute;
		return matcher.addRoute(record, parent);
	}
	function removeRoute(name) {
		const recordMatcher = matcher.getRecordMatcher(name);
		if (recordMatcher) matcher.removeRoute(recordMatcher);
		else warn$1(`Cannot remove non-existent route "${String(name)}"`);
	}
	function getRoutes() {
		return matcher.getRoutes().map((routeMatcher) => routeMatcher.record);
	}
	function hasRoute(name) {
		return !!matcher.getRecordMatcher(name);
	}
	function resolve(rawLocation, currentLocation) {
		currentLocation = assign({}, currentLocation || currentRoute.value);
		if (typeof rawLocation === "string") {
			const locationNormalized = parseURL(parseQuery$1, rawLocation, currentLocation.path);
			const matchedRoute$1 = matcher.resolve({ path: locationNormalized.path }, currentLocation);
			const href$1 = routerHistory.createHref(locationNormalized.fullPath);
			if (href$1.startsWith("//")) warn$1(`Location "${rawLocation}" resolved to "${href$1}". A resolved location cannot start with multiple slashes.`);
			else if (!matchedRoute$1.matched.length) warn$1(`No match found for location with path "${rawLocation}"`);
			return assign(locationNormalized, matchedRoute$1, {
				params: decodeParams(matchedRoute$1.params),
				hash: decode(locationNormalized.hash),
				redirectedFrom: void 0,
				href: href$1
			});
		}
		if (!isRouteLocation(rawLocation)) {
			warn$1(`router.resolve() was passed an invalid location. This will fail in production.\n- Location:`, rawLocation);
			return resolve({});
		}
		let matcherLocation;
		if (rawLocation.path != null) {
			if ("params" in rawLocation && !("name" in rawLocation) && Object.keys(rawLocation.params).length) warn$1(`Path "${rawLocation.path}" was passed with params but they will be ignored. Use a named route alongside params instead.`);
			matcherLocation = assign({}, rawLocation, { path: parseURL(parseQuery$1, rawLocation.path, currentLocation.path).path });
		} else {
			const targetParams = assign({}, rawLocation.params);
			for (const key in targetParams) if (targetParams[key] == null) delete targetParams[key];
			matcherLocation = assign({}, rawLocation, { params: encodeParams(targetParams) });
			currentLocation.params = encodeParams(currentLocation.params);
		}
		const matchedRoute = matcher.resolve(matcherLocation, currentLocation);
		const hash = rawLocation.hash || "";
		if (hash && !hash.startsWith("#")) warn$1(`A \`hash\` should always start with the character "#". Replace "${hash}" with "#${hash}".`);
		matchedRoute.params = normalizeParams(decodeParams(matchedRoute.params));
		const fullPath = stringifyURL(stringifyQuery$1, assign({}, rawLocation, {
			hash: encodeHash(hash),
			path: matchedRoute.path
		}));
		const href = routerHistory.createHref(fullPath);
		if (href.startsWith("//")) warn$1(`Location "${rawLocation}" resolved to "${href}". A resolved location cannot start with multiple slashes.`);
		else if (!matchedRoute.matched.length) warn$1(`No match found for location with path "${rawLocation.path != null ? rawLocation.path : rawLocation}"`);
		return assign({
			fullPath,
			hash,
			query: stringifyQuery$1 === stringifyQuery ? normalizeQuery(rawLocation.query) : rawLocation.query || {}
		}, matchedRoute, {
			redirectedFrom: void 0,
			href
		});
	}
	function locationAsObject(to) {
		return typeof to === "string" ? parseURL(parseQuery$1, to, currentRoute.value.path) : assign({}, to);
	}
	function checkCanceledNavigation(to, from) {
		if (pendingLocation !== to) return createRouterError(ErrorTypes.NAVIGATION_CANCELLED, {
			from,
			to
		});
	}
	function push(to) {
		return pushWithRedirect(to);
	}
	function replace(to) {
		return push(assign(locationAsObject(to), { replace: true }));
	}
	function handleRedirectRecord(to, from) {
		const lastMatched = to.matched[to.matched.length - 1];
		if (lastMatched && lastMatched.redirect) {
			const { redirect } = lastMatched;
			let newTargetLocation = typeof redirect === "function" ? redirect(to, from) : redirect;
			if (typeof newTargetLocation === "string") {
				newTargetLocation = newTargetLocation.includes("?") || newTargetLocation.includes("#") ? newTargetLocation = locationAsObject(newTargetLocation) : { path: newTargetLocation };
				newTargetLocation.params = {};
			}
			if (newTargetLocation.path == null && !("name" in newTargetLocation)) {
				warn$1(`Invalid redirect found:\n${JSON.stringify(newTargetLocation, null, 2)}\n when navigating to "${to.fullPath}". A redirect must contain a name or path. This will break in production.`);
				throw new Error("Invalid redirect");
			}
			return assign({
				query: to.query,
				hash: to.hash,
				params: newTargetLocation.path != null ? {} : to.params
			}, newTargetLocation);
		}
	}
	function pushWithRedirect(to, redirectedFrom) {
		const targetLocation = pendingLocation = resolve(to);
		const from = currentRoute.value;
		const data = to.state;
		const force = to.force;
		const replace$1 = to.replace === true;
		const shouldRedirect = handleRedirectRecord(targetLocation, from);
		if (shouldRedirect) return pushWithRedirect(assign(locationAsObject(shouldRedirect), {
			state: typeof shouldRedirect === "object" ? assign({}, data, shouldRedirect.state) : data,
			force,
			replace: replace$1
		}), redirectedFrom || targetLocation);
		const toLocation = targetLocation;
		toLocation.redirectedFrom = redirectedFrom;
		let failure;
		if (!force && isSameRouteLocation(stringifyQuery$1, from, targetLocation)) {
			failure = createRouterError(ErrorTypes.NAVIGATION_DUPLICATED, {
				to: toLocation,
				from
			});
			handleScroll(from, from, true, false);
		}
		return (failure ? Promise.resolve(failure) : navigate(toLocation, from)).catch((error) => isNavigationFailure(error) ? isNavigationFailure(error, ErrorTypes.NAVIGATION_GUARD_REDIRECT) ? error : markAsReady(error) : triggerError(error, toLocation, from)).then((failure$1) => {
			if (failure$1) {
				if (isNavigationFailure(failure$1, ErrorTypes.NAVIGATION_GUARD_REDIRECT)) {
					if (isSameRouteLocation(stringifyQuery$1, resolve(failure$1.to), toLocation) && redirectedFrom && (redirectedFrom._count = redirectedFrom._count ? redirectedFrom._count + 1 : 1) > 30) {
						warn$1(`Detected a possibly infinite redirection in a navigation guard when going from "${from.fullPath}" to "${toLocation.fullPath}". Aborting to avoid a Stack Overflow.\n Are you always returning a new location within a navigation guard? That would lead to this error. Only return when redirecting or aborting, that should fix this. This might break in production if not fixed.`);
						return Promise.reject(/* @__PURE__ */ new Error("Infinite redirect in navigation guard"));
					}
					return pushWithRedirect(assign({ replace: replace$1 }, locationAsObject(failure$1.to), {
						state: typeof failure$1.to === "object" ? assign({}, data, failure$1.to.state) : data,
						force
					}), redirectedFrom || toLocation);
				}
			} else failure$1 = finalizeNavigation(toLocation, from, true, replace$1, data);
			triggerAfterEach(toLocation, from, failure$1);
			return failure$1;
		});
	}
	/**
	* Helper to reject and skip all navigation guards if a new navigation happened
	* @param to
	* @param from
	*/
	function checkCanceledNavigationAndReject(to, from) {
		const error = checkCanceledNavigation(to, from);
		return error ? Promise.reject(error) : Promise.resolve();
	}
	function runWithContext(fn) {
		const app = installedApps.values().next().value;
		return app && typeof app.runWithContext === "function" ? app.runWithContext(fn) : fn();
	}
	function navigate(to, from) {
		let guards;
		const [leavingRecords, updatingRecords, enteringRecords] = extractChangingRecords(to, from);
		guards = extractComponentsGuards(leavingRecords.reverse(), "beforeRouteLeave", to, from);
		for (const record of leavingRecords) record.leaveGuards.forEach((guard) => {
			guards.push(guardToPromiseFn(guard, to, from));
		});
		const canceledNavigationCheck = checkCanceledNavigationAndReject.bind(null, to, from);
		guards.push(canceledNavigationCheck);
		return runGuardQueue(guards).then(() => {
			guards = [];
			for (const guard of beforeGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = extractComponentsGuards(updatingRecords, "beforeRouteUpdate", to, from);
			for (const record of updatingRecords) record.updateGuards.forEach((guard) => {
				guards.push(guardToPromiseFn(guard, to, from));
			});
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const record of enteringRecords) if (record.beforeEnter) if (isArray(record.beforeEnter)) for (const beforeEnter of record.beforeEnter) guards.push(guardToPromiseFn(beforeEnter, to, from));
			else guards.push(guardToPromiseFn(record.beforeEnter, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			to.matched.forEach((record) => record.enterCallbacks = {});
			guards = extractComponentsGuards(enteringRecords, "beforeRouteEnter", to, from, runWithContext);
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const guard of beforeResolveGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).catch((err) => isNavigationFailure(err, ErrorTypes.NAVIGATION_CANCELLED) ? err : Promise.reject(err));
	}
	function triggerAfterEach(to, from, failure) {
		afterGuards.list().forEach((guard) => runWithContext(() => guard(to, from, failure)));
	}
	/**
	* - Cleans up any navigation guards
	* - Changes the url if necessary
	* - Calls the scrollBehavior
	*/
	function finalizeNavigation(toLocation, from, isPush, replace$1, data) {
		const error = checkCanceledNavigation(toLocation, from);
		if (error) return error;
		const isFirstNavigation = from === START_LOCATION_NORMALIZED;
		const state = !isBrowser ? {} : history.state;
		if (isPush) if (replace$1 || isFirstNavigation) routerHistory.replace(toLocation.fullPath, assign({ scroll: isFirstNavigation && state && state.scroll }, data));
		else routerHistory.push(toLocation.fullPath, data);
		currentRoute.value = toLocation;
		handleScroll(toLocation, from, isPush, isFirstNavigation);
		markAsReady();
	}
	let removeHistoryListener;
	function setupListeners() {
		if (removeHistoryListener) return;
		removeHistoryListener = routerHistory.listen((to, _from, info) => {
			if (!router.listening) return;
			const toLocation = resolve(to);
			const shouldRedirect = handleRedirectRecord(toLocation, router.currentRoute.value);
			if (shouldRedirect) {
				pushWithRedirect(assign(shouldRedirect, {
					replace: true,
					force: true
				}), toLocation).catch(noop);
				return;
			}
			pendingLocation = toLocation;
			const from = currentRoute.value;
			if (isBrowser) saveScrollPosition(getScrollKey(from.fullPath, info.delta), computeScrollPosition());
			navigate(toLocation, from).catch((error) => {
				if (isNavigationFailure(error, ErrorTypes.NAVIGATION_ABORTED | ErrorTypes.NAVIGATION_CANCELLED)) return error;
				if (isNavigationFailure(error, ErrorTypes.NAVIGATION_GUARD_REDIRECT)) {
					pushWithRedirect(assign(locationAsObject(error.to), { force: true }), toLocation).then((failure) => {
						if (isNavigationFailure(failure, ErrorTypes.NAVIGATION_ABORTED | ErrorTypes.NAVIGATION_DUPLICATED) && !info.delta && info.type === NavigationType.pop) routerHistory.go(-1, false);
					}).catch(noop);
					return Promise.reject();
				}
				if (info.delta) routerHistory.go(-info.delta, false);
				return triggerError(error, toLocation, from);
			}).then((failure) => {
				failure = failure || finalizeNavigation(toLocation, from, false);
				if (failure) {
					if (info.delta && !isNavigationFailure(failure, ErrorTypes.NAVIGATION_CANCELLED)) routerHistory.go(-info.delta, false);
					else if (info.type === NavigationType.pop && isNavigationFailure(failure, ErrorTypes.NAVIGATION_ABORTED | ErrorTypes.NAVIGATION_DUPLICATED)) routerHistory.go(-1, false);
				}
				triggerAfterEach(toLocation, from, failure);
			}).catch(noop);
		});
	}
	let readyHandlers = useCallbacks();
	let errorListeners = useCallbacks();
	let ready;
	/**
	* Trigger errorListeners added via onError and throws the error as well
	*
	* @param error - error to throw
	* @param to - location we were navigating to when the error happened
	* @param from - location we were navigating from when the error happened
	* @returns the error as a rejected promise
	*/
	function triggerError(error, to, from) {
		markAsReady(error);
		const list = errorListeners.list();
		if (list.length) list.forEach((handler) => handler(error, to, from));
		else {
			warn$1("uncaught error during route navigation:");
			console.error(error);
		}
		return Promise.reject(error);
	}
	function isReady() {
		if (ready && currentRoute.value !== START_LOCATION_NORMALIZED) return Promise.resolve();
		return new Promise((resolve$1, reject) => {
			readyHandlers.add([resolve$1, reject]);
		});
	}
	function markAsReady(err) {
		if (!ready) {
			ready = !err;
			setupListeners();
			readyHandlers.list().forEach(([resolve$1, reject]) => err ? reject(err) : resolve$1());
			readyHandlers.reset();
		}
		return err;
	}
	function handleScroll(to, from, isPush, isFirstNavigation) {
		const { scrollBehavior } = options;
		if (!isBrowser || !scrollBehavior) return Promise.resolve();
		const scrollPosition = !isPush && getSavedScrollPosition(getScrollKey(to.fullPath, 0)) || (isFirstNavigation || !isPush) && history.state && history.state.scroll || null;
		return nextTick().then(() => scrollBehavior(to, from, scrollPosition)).then((position) => position && scrollToPosition(position)).catch((err) => triggerError(err, to, from));
	}
	const go = (delta) => routerHistory.go(delta);
	let started;
	const installedApps = /* @__PURE__ */ new Set();
	const router = {
		currentRoute,
		listening: true,
		addRoute,
		removeRoute,
		clearRoutes: matcher.clearRoutes,
		hasRoute,
		getRoutes,
		resolve,
		options,
		push,
		replace,
		go,
		back: () => go(-1),
		forward: () => go(1),
		beforeEach: beforeGuards.add,
		beforeResolve: beforeResolveGuards.add,
		afterEach: afterGuards.add,
		onError: errorListeners.add,
		isReady,
		install(app) {
			app.component("RouterLink", RouterLink);
			app.component("RouterView", RouterView);
			app.config.globalProperties.$router = router;
			Object.defineProperty(app.config.globalProperties, "$route", {
				enumerable: true,
				get: () => unref(currentRoute)
			});
			if (isBrowser && !started && currentRoute.value === START_LOCATION_NORMALIZED) {
				started = true;
				push(routerHistory.location).catch((err) => {
					warn$1("Unexpected error when starting the router:", err);
				});
			}
			const reactiveRoute = {};
			for (const key in START_LOCATION_NORMALIZED) Object.defineProperty(reactiveRoute, key, {
				get: () => currentRoute.value[key],
				enumerable: true
			});
			app.provide(routerKey, router);
			app.provide(routeLocationKey, shallowReactive(reactiveRoute));
			app.provide(routerViewLocationKey, currentRoute);
			const unmountApp = app.unmount;
			installedApps.add(app);
			app.unmount = function() {
				installedApps.delete(app);
				if (installedApps.size < 1) {
					pendingLocation = START_LOCATION_NORMALIZED;
					removeHistoryListener && removeHistoryListener();
					removeHistoryListener = null;
					currentRoute.value = START_LOCATION_NORMALIZED;
					started = false;
					ready = false;
				}
				unmountApp();
			};
			if (isBrowser) addDevtools(app, router, matcher);
		}
	};
	function runGuardQueue(guards) {
		return guards.reduce((promise, guard) => promise.then(() => runWithContext(guard)), Promise.resolve());
	}
	return router;
}
/**
* Returns the router instance. Equivalent to using `$router` inside
* templates.
*/
function useRouter() {
	return inject(routerKey);
}
/**
* Returns the current route location. Equivalent to using `$route` inside
* templates.
*/
function useRoute(_name) {
	return inject(routeLocationKey);
}
//#endregion
export { NavigationFailureType, RouterLink, RouterView, START_LOCATION_NORMALIZED as START_LOCATION, createMemoryHistory, createRouter, createRouterMatcher, createWebHashHistory, createWebHistory, isNavigationFailure, loadRouteLocation, matchedRouteKey, onBeforeRouteLeave, onBeforeRouteUpdate, parseQuery, routeLocationKey, routerKey, routerViewLocationKey, stringifyQuery, useLink, useRoute, useRouter, viewDepthKey };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnVlLXJvdXRlci5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi9AdnVlL2RldnRvb2xzLWFwaS9saWIvZXNtL2Vudi5qcyIsIi4uLy4uL0B2dWUvZGV2dG9vbHMtYXBpL2xpYi9lc20vY29uc3QuanMiLCIuLi8uLi9AdnVlL2RldnRvb2xzLWFwaS9saWIvZXNtL3RpbWUuanMiLCIuLi8uLi9AdnVlL2RldnRvb2xzLWFwaS9saWIvZXNtL3Byb3h5LmpzIiwiLi4vLi4vQHZ1ZS9kZXZ0b29scy1hcGkvbGliL2VzbS9pbmRleC5qcyIsIi4uLy4uL3Z1ZS1yb3V0ZXIvZGlzdC9kZXZ0b29scy1FV044MWlPbC5tanMiLCIuLi8uLi92dWUtcm91dGVyL2Rpc3QvdnVlLXJvdXRlci5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIGdldERldnRvb2xzR2xvYmFsSG9vaygpIHtcbiAgICByZXR1cm4gZ2V0VGFyZ2V0KCkuX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXztcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRUYXJnZXQoKSB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciBuYXZpZ2F0b3IgYW5kIHdpbmRvd3MgYXJlIG5vdCBhdmFpbGFibGUgaW4gYWxsIGVudmlyb25tZW50c1xuICAgIHJldHVybiAodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpXG4gICAgICAgID8gd2luZG93XG4gICAgICAgIDogdHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnXG4gICAgICAgICAgICA/IGdsb2JhbFRoaXNcbiAgICAgICAgICAgIDoge307XG59XG5leHBvcnQgY29uc3QgaXNQcm94eUF2YWlsYWJsZSA9IHR5cGVvZiBQcm94eSA9PT0gJ2Z1bmN0aW9uJztcbiIsImV4cG9ydCBjb25zdCBIT09LX1NFVFVQID0gJ2RldnRvb2xzLXBsdWdpbjpzZXR1cCc7XG5leHBvcnQgY29uc3QgSE9PS19QTFVHSU5fU0VUVElOR1NfU0VUID0gJ3BsdWdpbjpzZXR0aW5nczpzZXQnO1xuIiwibGV0IHN1cHBvcnRlZDtcbmxldCBwZXJmO1xuZXhwb3J0IGZ1bmN0aW9uIGlzUGVyZm9ybWFuY2VTdXBwb3J0ZWQoKSB7XG4gICAgdmFyIF9hO1xuICAgIGlmIChzdXBwb3J0ZWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gc3VwcG9ydGVkO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LnBlcmZvcm1hbmNlKSB7XG4gICAgICAgIHN1cHBvcnRlZCA9IHRydWU7XG4gICAgICAgIHBlcmYgPSB3aW5kb3cucGVyZm9ybWFuY2U7XG4gICAgfVxuICAgIGVsc2UgaWYgKHR5cGVvZiBnbG9iYWxUaGlzICE9PSAndW5kZWZpbmVkJyAmJiAoKF9hID0gZ2xvYmFsVGhpcy5wZXJmX2hvb2tzKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EucGVyZm9ybWFuY2UpKSB7XG4gICAgICAgIHN1cHBvcnRlZCA9IHRydWU7XG4gICAgICAgIHBlcmYgPSBnbG9iYWxUaGlzLnBlcmZfaG9va3MucGVyZm9ybWFuY2U7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBzdXBwb3J0ZWQgPSBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIHN1cHBvcnRlZDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBub3coKSB7XG4gICAgcmV0dXJuIGlzUGVyZm9ybWFuY2VTdXBwb3J0ZWQoKSA/IHBlcmYubm93KCkgOiBEYXRlLm5vdygpO1xufVxuIiwiaW1wb3J0IHsgSE9PS19QTFVHSU5fU0VUVElOR1NfU0VUIH0gZnJvbSAnLi9jb25zdC5qcyc7XG5pbXBvcnQgeyBub3cgfSBmcm9tICcuL3RpbWUuanMnO1xuZXhwb3J0IGNsYXNzIEFwaVByb3h5IHtcbiAgICBjb25zdHJ1Y3RvcihwbHVnaW4sIGhvb2spIHtcbiAgICAgICAgdGhpcy50YXJnZXQgPSBudWxsO1xuICAgICAgICB0aGlzLnRhcmdldFF1ZXVlID0gW107XG4gICAgICAgIHRoaXMub25RdWV1ZSA9IFtdO1xuICAgICAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgICAgICAgdGhpcy5ob29rID0gaG9vaztcbiAgICAgICAgY29uc3QgZGVmYXVsdFNldHRpbmdzID0ge307XG4gICAgICAgIGlmIChwbHVnaW4uc2V0dGluZ3MpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgaWQgaW4gcGx1Z2luLnNldHRpbmdzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXRlbSA9IHBsdWdpbi5zZXR0aW5nc1tpZF07XG4gICAgICAgICAgICAgICAgZGVmYXVsdFNldHRpbmdzW2lkXSA9IGl0ZW0uZGVmYXVsdFZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxvY2FsU2V0dGluZ3NTYXZlSWQgPSBgX192dWUtZGV2dG9vbHMtcGx1Z2luLXNldHRpbmdzX18ke3BsdWdpbi5pZH1gO1xuICAgICAgICBsZXQgY3VycmVudFNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgZGVmYXVsdFNldHRpbmdzKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJhdyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGxvY2FsU2V0dGluZ3NTYXZlSWQpO1xuICAgICAgICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UocmF3KTtcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oY3VycmVudFNldHRpbmdzLCBkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgLy8gbm9vcFxuICAgICAgICB9XG4gICAgICAgIHRoaXMuZmFsbGJhY2tzID0ge1xuICAgICAgICAgICAgZ2V0U2V0dGluZ3MoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnRTZXR0aW5ncztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXRTZXR0aW5ncyh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGxvY2FsU2V0dGluZ3NTYXZlSWQsIEpTT04uc3RyaW5naWZ5KHZhbHVlKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIG5vb3BcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY3VycmVudFNldHRpbmdzID0gdmFsdWU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbm93KCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBub3coKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgICAgIGlmIChob29rKSB7XG4gICAgICAgICAgICBob29rLm9uKEhPT0tfUExVR0lOX1NFVFRJTkdTX1NFVCwgKHBsdWdpbklkLCB2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChwbHVnaW5JZCA9PT0gdGhpcy5wbHVnaW4uaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5mYWxsYmFja3Muc2V0U2V0dGluZ3ModmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMucHJveGllZE9uID0gbmV3IFByb3h5KHt9LCB7XG4gICAgICAgICAgICBnZXQ6IChfdGFyZ2V0LCBwcm9wKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMudGFyZ2V0KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnRhcmdldC5vbltwcm9wXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoLi4uYXJncykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vblF1ZXVlLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogcHJvcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmdzLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucHJveGllZFRhcmdldCA9IG5ldyBQcm94eSh7fSwge1xuICAgICAgICAgICAgZ2V0OiAoX3RhcmdldCwgcHJvcCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLnRhcmdldCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy50YXJnZXRbcHJvcF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHByb3AgPT09ICdvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucHJveGllZE9uO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChPYmplY3Qua2V5cyh0aGlzLmZhbGxiYWNrcykuaW5jbHVkZXMocHJvcCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRhcmdldFF1ZXVlLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogcHJvcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmdzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmU6ICgpID0+IHsgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZmFsbGJhY2tzW3Byb3BdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRhcmdldFF1ZXVlLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6IHByb3AsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgYXN5bmMgc2V0UmVhbFRhcmdldCh0YXJnZXQpIHtcbiAgICAgICAgdGhpcy50YXJnZXQgPSB0YXJnZXQ7XG4gICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiB0aGlzLm9uUXVldWUpIHtcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0Lm9uW2l0ZW0ubWV0aG9kXSguLi5pdGVtLmFyZ3MpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiB0aGlzLnRhcmdldFF1ZXVlKSB7XG4gICAgICAgICAgICBpdGVtLnJlc29sdmUoYXdhaXQgdGhpcy50YXJnZXRbaXRlbS5tZXRob2RdKC4uLml0ZW0uYXJncykpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgZ2V0RGV2dG9vbHNHbG9iYWxIb29rLCBnZXRUYXJnZXQsIGlzUHJveHlBdmFpbGFibGUgfSBmcm9tICcuL2Vudi5qcyc7XG5pbXBvcnQgeyBIT09LX1NFVFVQIH0gZnJvbSAnLi9jb25zdC5qcyc7XG5pbXBvcnQgeyBBcGlQcm94eSB9IGZyb20gJy4vcHJveHkuanMnO1xuZXhwb3J0ICogZnJvbSAnLi9hcGkvaW5kZXguanMnO1xuZXhwb3J0ICogZnJvbSAnLi9wbHVnaW4uanMnO1xuZXhwb3J0ICogZnJvbSAnLi90aW1lLmpzJztcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cERldnRvb2xzUGx1Z2luKHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4pIHtcbiAgICBjb25zdCBkZXNjcmlwdG9yID0gcGx1Z2luRGVzY3JpcHRvcjtcbiAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoKTtcbiAgICBjb25zdCBob29rID0gZ2V0RGV2dG9vbHNHbG9iYWxIb29rKCk7XG4gICAgY29uc3QgZW5hYmxlUHJveHkgPSBpc1Byb3h5QXZhaWxhYmxlICYmIGRlc2NyaXB0b3IuZW5hYmxlRWFybHlQcm94eTtcbiAgICBpZiAoaG9vayAmJiAodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX1BMVUdJTl9BUElfQVZBSUxBQkxFX18gfHwgIWVuYWJsZVByb3h5KSkge1xuICAgICAgICBob29rLmVtaXQoSE9PS19TRVRVUCwgcGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCBwcm94eSA9IGVuYWJsZVByb3h5ID8gbmV3IEFwaVByb3h5KGRlc2NyaXB0b3IsIGhvb2spIDogbnVsbDtcbiAgICAgICAgY29uc3QgbGlzdCA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19QTFVHSU5TX18gPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfUExVR0lOU19fIHx8IFtdO1xuICAgICAgICBsaXN0LnB1c2goe1xuICAgICAgICAgICAgcGx1Z2luRGVzY3JpcHRvcjogZGVzY3JpcHRvcixcbiAgICAgICAgICAgIHNldHVwRm4sXG4gICAgICAgICAgICBwcm94eSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChwcm94eSkge1xuICAgICAgICAgICAgc2V0dXBGbihwcm94eS5wcm94aWVkVGFyZ2V0KTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIi8qIVxuICogdnVlLXJvdXRlciB2NC42LjRcbiAqIChjKSAyMDI1IEVkdWFyZG8gU2FuIE1hcnRpbiBNb3JvdGVcbiAqIEBsaWNlbnNlIE1JVFxuICovXG5pbXBvcnQgeyBnZXRDdXJyZW50SW5zdGFuY2UsIGluamVjdCwgb25BY3RpdmF0ZWQsIG9uRGVhY3RpdmF0ZWQsIG9uVW5tb3VudGVkLCB3YXRjaCB9IGZyb20gXCJ2dWVcIjtcbmltcG9ydCB7IHNldHVwRGV2dG9vbHNQbHVnaW4gfSBmcm9tIFwiQHZ1ZS9kZXZ0b29scy1hcGlcIjtcblxuLy8jcmVnaW9uIHNyYy91dGlscy9lbnYudHNcbmNvbnN0IGlzQnJvd3NlciA9IHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIjtcblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL2luZGV4LnRzXG4vKipcbiogSWRlbnRpdHkgZnVuY3Rpb24gdGhhdCByZXR1cm5zIHRoZSB2YWx1ZSBhcyBpcy5cbipcbiogQHBhcmFtIHYgLSB0aGUgdmFsdWUgdG8gcmV0dXJuXG4qXG4qIEBpbnRlcm5hbFxuKi9cbmNvbnN0IGlkZW50aXR5Rm4gPSAodikgPT4gdjtcbi8qKlxuKiBBbGxvd3MgZGlmZmVyZW50aWF0aW5nIGxhenkgY29tcG9uZW50cyBmcm9tIGZ1bmN0aW9uYWwgY29tcG9uZW50cyBhbmQgdnVlLWNsYXNzLWNvbXBvbmVudFxuKiBAaW50ZXJuYWxcbipcbiogQHBhcmFtIGNvbXBvbmVudFxuKi9cbmZ1bmN0aW9uIGlzUm91dGVDb21wb25lbnQoY29tcG9uZW50KSB7XG5cdHJldHVybiB0eXBlb2YgY29tcG9uZW50ID09PSBcIm9iamVjdFwiIHx8IFwiZGlzcGxheU5hbWVcIiBpbiBjb21wb25lbnQgfHwgXCJwcm9wc1wiIGluIGNvbXBvbmVudCB8fCBcIl9fdmNjT3B0c1wiIGluIGNvbXBvbmVudDtcbn1cbmZ1bmN0aW9uIGlzRVNNb2R1bGUob2JqKSB7XG5cdHJldHVybiBvYmouX19lc01vZHVsZSB8fCBvYmpbU3ltYm9sLnRvU3RyaW5nVGFnXSA9PT0gXCJNb2R1bGVcIiB8fCBvYmouZGVmYXVsdCAmJiBpc1JvdXRlQ29tcG9uZW50KG9iai5kZWZhdWx0KTtcbn1cbmNvbnN0IGFzc2lnbiA9IE9iamVjdC5hc3NpZ247XG5mdW5jdGlvbiBhcHBseVRvUGFyYW1zKGZuLCBwYXJhbXMpIHtcblx0Y29uc3QgbmV3UGFyYW1zID0ge307XG5cdGZvciAoY29uc3Qga2V5IGluIHBhcmFtcykge1xuXHRcdGNvbnN0IHZhbHVlID0gcGFyYW1zW2tleV07XG5cdFx0bmV3UGFyYW1zW2tleV0gPSBpc0FycmF5KHZhbHVlKSA/IHZhbHVlLm1hcChmbikgOiBmbih2YWx1ZSk7XG5cdH1cblx0cmV0dXJuIG5ld1BhcmFtcztcbn1cbmNvbnN0IG5vb3AgPSAoKSA9PiB7fTtcbi8qKlxuKiBUeXBlc2FmZSBhbHRlcm5hdGl2ZSB0byBBcnJheS5pc0FycmF5XG4qIGh0dHBzOi8vZ2l0aHViLmNvbS9taWNyb3NvZnQvVHlwZVNjcmlwdC9wdWxsLzQ4MjI4XG4qXG4qIEBpbnRlcm5hbFxuKi9cbmNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5O1xuZnVuY3Rpb24gbWVyZ2VPcHRpb25zKGRlZmF1bHRzLCBwYXJ0aWFsT3B0aW9ucykge1xuXHRjb25zdCBvcHRpb25zID0ge307XG5cdGZvciAoY29uc3Qga2V5IGluIGRlZmF1bHRzKSBvcHRpb25zW2tleV0gPSBrZXkgaW4gcGFydGlhbE9wdGlvbnMgPyBwYXJ0aWFsT3B0aW9uc1trZXldIDogZGVmYXVsdHNba2V5XTtcblx0cmV0dXJuIG9wdGlvbnM7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy93YXJuaW5nLnRzXG5mdW5jdGlvbiB3YXJuJDEobXNnKSB7XG5cdGNvbnN0IGFyZ3MgPSBBcnJheS5mcm9tKGFyZ3VtZW50cykuc2xpY2UoMSk7XG5cdGNvbnNvbGUud2Fybi5hcHBseShjb25zb2xlLCBbXCJbVnVlIFJvdXRlciB3YXJuXTogXCIgKyBtc2ddLmNvbmNhdChhcmdzKSk7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9lbmNvZGluZy50c1xuLyoqXG4qIEVuY29kaW5nIFJ1bGVzICjikKMgPSBTcGFjZSlcbiogLSBQYXRoOiDikKMgXCIgPCA+ICMgPyB7IH1cbiogLSBRdWVyeTog4pCjIFwiIDwgPiAjICYgPVxuKiAtIEhhc2g6IOKQoyBcIiA8ID4gYFxuKlxuKiBPbiB0b3Agb2YgdGhhdCwgdGhlIFJGQzM5ODYgKGh0dHBzOi8vdG9vbHMuaWV0Zi5vcmcvaHRtbC9yZmMzOTg2I3NlY3Rpb24tMi4yKVxuKiBkZWZpbmVzIHNvbWUgZXh0cmEgY2hhcmFjdGVycyB0byBiZSBlbmNvZGVkLiBNb3N0IGJyb3dzZXJzIGRvIG5vdCBlbmNvZGUgdGhlbVxuKiBpbiBlbmNvZGVVUkkgaHR0cHM6Ly9naXRodWIuY29tL3doYXR3Zy91cmwvaXNzdWVzLzM2OSwgc28gaXQgbWF5IGJlIHNhZmVyIHRvXG4qIGFsc28gZW5jb2RlIGAhJygpKmAuIExlYXZpbmcgdW4tZW5jb2RlZCBvbmx5IEFTQ0lJIGFscGhhbnVtZXJpYyhgYS16QS1aMC05YClcbiogcGx1cyBgLS5ffmAuIFRoaXMgZXh0cmEgc2FmZXR5IHNob3VsZCBiZSBhcHBsaWVkIHRvIHF1ZXJ5IGJ5IHBhdGNoaW5nIHRoZVxuKiBzdHJpbmcgcmV0dXJuZWQgYnkgZW5jb2RlVVJJQ29tcG9uZW50IGVuY29kZVVSSSBhbHNvIGVuY29kZXMgYFtcXF1eYC4gYFxcYFxuKiBzaG91bGQgYmUgZW5jb2RlZCB0byBhdm9pZCBhbWJpZ3VpdHkuIEJyb3dzZXJzIChJRSwgRkYsIEMpIHRyYW5zZm9ybSBhIGBcXGBcbiogaW50byBhIGAvYCBpZiBkaXJlY3RseSB0eXBlZCBpbi4gVGhlIF9iYWNrdGlja18gKGBgYGBgKSBzaG91bGQgYWxzbyBiZVxuKiBlbmNvZGVkIGV2ZXJ5d2hlcmUgYmVjYXVzZSBzb21lIGJyb3dzZXJzIGxpa2UgRkYgZW5jb2RlIGl0IHdoZW4gZGlyZWN0bHlcbiogd3JpdHRlbiB3aGlsZSBvdGhlcnMgZG9uJ3QuIFNhZmFyaSBhbmQgSUUgZG9uJ3QgZW5jb2RlIGBgXCI8Pnt9YGBgIGluIGhhc2guXG4qL1xuY29uc3QgSEFTSF9SRSA9IC8jL2c7XG5jb25zdCBBTVBFUlNBTkRfUkUgPSAvJi9nO1xuY29uc3QgU0xBU0hfUkUgPSAvXFwvL2c7XG5jb25zdCBFUVVBTF9SRSA9IC89L2c7XG5jb25zdCBJTV9SRSA9IC9cXD8vZztcbmNvbnN0IFBMVVNfUkUgPSAvXFwrL2c7XG4vKipcbiogTk9URTogSXQncyBub3QgY2xlYXIgdG8gbWUgaWYgd2Ugc2hvdWxkIGVuY29kZSB0aGUgKyBzeW1ib2wgaW4gcXVlcmllcywgaXRcbiogc2VlbXMgdG8gYmUgbGVzcyBmbGV4aWJsZSB0aGFuIG5vdCBkb2luZyBzbyBhbmQgSSBjYW4ndCBmaW5kIG91dCB0aGUgbGVnYWN5XG4qIHN5c3RlbXMgcmVxdWlyaW5nIHRoaXMgZm9yIHJlZ3VsYXIgcmVxdWVzdHMgbGlrZSB0ZXh0L2h0bWwuIEluIHRoZSBzdGFuZGFyZCxcbiogdGhlIGVuY29kaW5nIG9mIHRoZSBwbHVzIGNoYXJhY3RlciBpcyBvbmx5IG1lbnRpb25lZCBmb3JcbiogYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkXG4qIChodHRwczovL3VybC5zcGVjLndoYXR3Zy5vcmcvI3VybGVuY29kZWQtcGFyc2luZykgYW5kIG1vc3QgYnJvd3NlcnMgc2VlbXMgbG9cbiogbGVhdmUgdGhlIHBsdXMgY2hhcmFjdGVyIGFzIGlzIGluIHF1ZXJpZXMuIFRvIGJlIG1vcmUgZmxleGlibGUsIHdlIGFsbG93IHRoZVxuKiBwbHVzIGNoYXJhY3RlciBvbiB0aGUgcXVlcnksIGJ1dCBpdCBjYW4gYWxzbyBiZSBtYW51YWxseSBlbmNvZGVkIGJ5IHRoZSB1c2VyLlxuKlxuKiBSZXNvdXJjZXM6XG4qIC0gaHR0cHM6Ly91cmwuc3BlYy53aGF0d2cub3JnLyN1cmxlbmNvZGVkLXBhcnNpbmdcbiogLSBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8xNjM0MjcxL3VybC1lbmNvZGluZy10aGUtc3BhY2UtY2hhcmFjdGVyLW9yLTIwXG4qL1xuY29uc3QgRU5DX0JSQUNLRVRfT1BFTl9SRSA9IC8lNUIvZztcbmNvbnN0IEVOQ19CUkFDS0VUX0NMT1NFX1JFID0gLyU1RC9nO1xuY29uc3QgRU5DX0NBUkVUX1JFID0gLyU1RS9nO1xuY29uc3QgRU5DX0JBQ0tUSUNLX1JFID0gLyU2MC9nO1xuY29uc3QgRU5DX0NVUkxZX09QRU5fUkUgPSAvJTdCL2c7XG5jb25zdCBFTkNfUElQRV9SRSA9IC8lN0MvZztcbmNvbnN0IEVOQ19DVVJMWV9DTE9TRV9SRSA9IC8lN0QvZztcbmNvbnN0IEVOQ19TUEFDRV9SRSA9IC8lMjAvZztcbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgcGF0aCwgc2VhcmNoIGFuZCBoYXNoXG4qIHNlY3Rpb25zIG9mIHRoZSBVUkwuXG4qXG4qIEBpbnRlcm5hbFxuKiBAcGFyYW0gdGV4dCAtIHN0cmluZyB0byBlbmNvZGVcbiogQHJldHVybnMgZW5jb2RlZCBzdHJpbmdcbiovXG5mdW5jdGlvbiBjb21tb25FbmNvZGUodGV4dCkge1xuXHRyZXR1cm4gdGV4dCA9PSBudWxsID8gXCJcIiA6IGVuY29kZVVSSShcIlwiICsgdGV4dCkucmVwbGFjZShFTkNfUElQRV9SRSwgXCJ8XCIpLnJlcGxhY2UoRU5DX0JSQUNLRVRfT1BFTl9SRSwgXCJbXCIpLnJlcGxhY2UoRU5DX0JSQUNLRVRfQ0xPU0VfUkUsIFwiXVwiKTtcbn1cbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgaGFzaCBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZUhhc2godGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoRU5DX0NVUkxZX09QRU5fUkUsIFwie1wiKS5yZXBsYWNlKEVOQ19DVVJMWV9DTE9TRV9SRSwgXCJ9XCIpLnJlcGxhY2UoRU5DX0NBUkVUX1JFLCBcIl5cIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgcXVlcnkgdmFsdWVzIG9uIHRoZSBxdWVyeVxuKiBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZVF1ZXJ5VmFsdWUodGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoUExVU19SRSwgXCIlMkJcIikucmVwbGFjZShFTkNfU1BBQ0VfUkUsIFwiK1wiKS5yZXBsYWNlKEhBU0hfUkUsIFwiJTIzXCIpLnJlcGxhY2UoQU1QRVJTQU5EX1JFLCBcIiUyNlwiKS5yZXBsYWNlKEVOQ19CQUNLVElDS19SRSwgXCJgXCIpLnJlcGxhY2UoRU5DX0NVUkxZX09QRU5fUkUsIFwie1wiKS5yZXBsYWNlKEVOQ19DVVJMWV9DTE9TRV9SRSwgXCJ9XCIpLnJlcGxhY2UoRU5DX0NBUkVUX1JFLCBcIl5cIik7XG59XG4vKipcbiogTGlrZSBgZW5jb2RlUXVlcnlWYWx1ZWAgYnV0IGFsc28gZW5jb2RlcyB0aGUgYD1gIGNoYXJhY3Rlci5cbipcbiogQHBhcmFtIHRleHQgLSBzdHJpbmcgdG8gZW5jb2RlXG4qL1xuZnVuY3Rpb24gZW5jb2RlUXVlcnlLZXkodGV4dCkge1xuXHRyZXR1cm4gZW5jb2RlUXVlcnlWYWx1ZSh0ZXh0KS5yZXBsYWNlKEVRVUFMX1JFLCBcIiUzRFwiKTtcbn1cbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgcGF0aCBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZVBhdGgodGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoSEFTSF9SRSwgXCIlMjNcIikucmVwbGFjZShJTV9SRSwgXCIlM0ZcIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgb24gdGhlIHBhdGggc2VjdGlvbiBvZiB0aGUgVVJMIGFzIGFcbiogcGFyYW0uIFRoaXMgZnVuY3Rpb24gZW5jb2RlcyBldmVyeXRoaW5nIHtAbGluayBlbmNvZGVQYXRofSBkb2VzIHBsdXMgdGhlXG4qIHNsYXNoIChgL2ApIGNoYXJhY3Rlci4gSWYgYHRleHRgIGlzIGBudWxsYCBvciBgdW5kZWZpbmVkYCwgcmV0dXJucyBhbiBlbXB0eVxuKiBzdHJpbmcgaW5zdGVhZC5cbipcbiogQHBhcmFtIHRleHQgLSBzdHJpbmcgdG8gZW5jb2RlXG4qIEByZXR1cm5zIGVuY29kZWQgc3RyaW5nXG4qL1xuZnVuY3Rpb24gZW5jb2RlUGFyYW0odGV4dCkge1xuXHRyZXR1cm4gZW5jb2RlUGF0aCh0ZXh0KS5yZXBsYWNlKFNMQVNIX1JFLCBcIiUyRlwiKTtcbn1cbmZ1bmN0aW9uIGRlY29kZSh0ZXh0KSB7XG5cdGlmICh0ZXh0ID09IG51bGwpIHJldHVybiBudWxsO1xuXHR0cnkge1xuXHRcdHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoXCJcIiArIHRleHQpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgd2FybiQxKGBFcnJvciBkZWNvZGluZyBcIiR7dGV4dH1cIi4gVXNpbmcgb3JpZ2luYWwgdmFsdWVgKTtcblx0fVxuXHRyZXR1cm4gXCJcIiArIHRleHQ7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9sb2NhdGlvbi50c1xuY29uc3QgVFJBSUxJTkdfU0xBU0hfUkUgPSAvXFwvJC87XG5jb25zdCByZW1vdmVUcmFpbGluZ1NsYXNoID0gKHBhdGgpID0+IHBhdGgucmVwbGFjZShUUkFJTElOR19TTEFTSF9SRSwgXCJcIik7XG4vKipcbiogVHJhbnNmb3JtcyBhIFVSSSBpbnRvIGEgbm9ybWFsaXplZCBoaXN0b3J5IGxvY2F0aW9uXG4qXG4qIEBwYXJhbSBwYXJzZVF1ZXJ5XG4qIEBwYXJhbSBsb2NhdGlvbiAtIFVSSSB0byBub3JtYWxpemVcbiogQHBhcmFtIGN1cnJlbnRMb2NhdGlvbiAtIGN1cnJlbnQgYWJzb2x1dGUgbG9jYXRpb24uIEFsbG93cyByZXNvbHZpbmcgcmVsYXRpdmVcbiogcGF0aHMuIE11c3Qgc3RhcnQgd2l0aCBgL2AuIERlZmF1bHRzIHRvIGAvYFxuKiBAcmV0dXJucyBhIG5vcm1hbGl6ZWQgaGlzdG9yeSBsb2NhdGlvblxuKi9cbmZ1bmN0aW9uIHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgbG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbiA9IFwiL1wiKSB7XG5cdGxldCBwYXRoLCBxdWVyeSA9IHt9LCBzZWFyY2hTdHJpbmcgPSBcIlwiLCBoYXNoID0gXCJcIjtcblx0Y29uc3QgaGFzaFBvcyA9IGxvY2F0aW9uLmluZGV4T2YoXCIjXCIpO1xuXHRsZXQgc2VhcmNoUG9zID0gbG9jYXRpb24uaW5kZXhPZihcIj9cIik7XG5cdHNlYXJjaFBvcyA9IGhhc2hQb3MgPj0gMCAmJiBzZWFyY2hQb3MgPiBoYXNoUG9zID8gLTEgOiBzZWFyY2hQb3M7XG5cdGlmIChzZWFyY2hQb3MgPj0gMCkge1xuXHRcdHBhdGggPSBsb2NhdGlvbi5zbGljZSgwLCBzZWFyY2hQb3MpO1xuXHRcdHNlYXJjaFN0cmluZyA9IGxvY2F0aW9uLnNsaWNlKHNlYXJjaFBvcywgaGFzaFBvcyA+IDAgPyBoYXNoUG9zIDogbG9jYXRpb24ubGVuZ3RoKTtcblx0XHRxdWVyeSA9IHBhcnNlUXVlcnkkMShzZWFyY2hTdHJpbmcuc2xpY2UoMSkpO1xuXHR9XG5cdGlmIChoYXNoUG9zID49IDApIHtcblx0XHRwYXRoID0gcGF0aCB8fCBsb2NhdGlvbi5zbGljZSgwLCBoYXNoUG9zKTtcblx0XHRoYXNoID0gbG9jYXRpb24uc2xpY2UoaGFzaFBvcywgbG9jYXRpb24ubGVuZ3RoKTtcblx0fVxuXHRwYXRoID0gcmVzb2x2ZVJlbGF0aXZlUGF0aChwYXRoICE9IG51bGwgPyBwYXRoIDogbG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbik7XG5cdHJldHVybiB7XG5cdFx0ZnVsbFBhdGg6IHBhdGggKyBzZWFyY2hTdHJpbmcgKyBoYXNoLFxuXHRcdHBhdGgsXG5cdFx0cXVlcnksXG5cdFx0aGFzaDogZGVjb2RlKGhhc2gpXG5cdH07XG59XG5mdW5jdGlvbiBORVdfc3RyaW5naWZ5VVJMKHN0cmluZ2lmeVF1ZXJ5JDEsIHBhdGgsIHF1ZXJ5LCBoYXNoID0gXCJcIikge1xuXHRjb25zdCBzZWFyY2hUZXh0ID0gc3RyaW5naWZ5UXVlcnkkMShxdWVyeSk7XG5cdHJldHVybiBwYXRoICsgKHNlYXJjaFRleHQgJiYgXCI/XCIpICsgc2VhcmNoVGV4dCArIGVuY29kZUhhc2goaGFzaCk7XG59XG4vKipcbiogU3RyaW5naWZpZXMgYSBVUkwgb2JqZWN0XG4qXG4qIEBwYXJhbSBzdHJpbmdpZnlRdWVyeVxuKiBAcGFyYW0gbG9jYXRpb25cbiovXG5mdW5jdGlvbiBzdHJpbmdpZnlVUkwoc3RyaW5naWZ5UXVlcnkkMSwgbG9jYXRpb24pIHtcblx0Y29uc3QgcXVlcnkgPSBsb2NhdGlvbi5xdWVyeSA/IHN0cmluZ2lmeVF1ZXJ5JDEobG9jYXRpb24ucXVlcnkpIDogXCJcIjtcblx0cmV0dXJuIGxvY2F0aW9uLnBhdGggKyAocXVlcnkgJiYgXCI/XCIpICsgcXVlcnkgKyAobG9jYXRpb24uaGFzaCB8fCBcIlwiKTtcbn1cbi8qKlxuKiBTdHJpcHMgb2ZmIHRoZSBiYXNlIGZyb20gdGhlIGJlZ2lubmluZyBvZiBhIGxvY2F0aW9uLnBhdGhuYW1lIGluIGEgbm9uLWNhc2Utc2Vuc2l0aXZlIHdheS5cbipcbiogQHBhcmFtIHBhdGhuYW1lIC0gbG9jYXRpb24ucGF0aG5hbWVcbiogQHBhcmFtIGJhc2UgLSBiYXNlIHRvIHN0cmlwIG9mZlxuKi9cbmZ1bmN0aW9uIHN0cmlwQmFzZShwYXRobmFtZSwgYmFzZSkge1xuXHRpZiAoIWJhc2UgfHwgIXBhdGhuYW1lLnRvTG93ZXJDYXNlKCkuc3RhcnRzV2l0aChiYXNlLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gcGF0aG5hbWU7XG5cdHJldHVybiBwYXRobmFtZS5zbGljZShiYXNlLmxlbmd0aCkgfHwgXCIvXCI7XG59XG4vKipcbiogQ2hlY2tzIGlmIHR3byBSb3V0ZUxvY2F0aW9uIGFyZSBlcXVhbC4gVGhpcyBtZWFucyB0aGF0IGJvdGggbG9jYXRpb25zIGFyZVxuKiBwb2ludGluZyB0b3dhcmRzIHRoZSBzYW1lIHtAbGluayBSb3V0ZVJlY29yZH0gYW5kIHRoYXQgYWxsIGBwYXJhbXNgLCBgcXVlcnlgXG4qIHBhcmFtZXRlcnMgYW5kIGBoYXNoYCBhcmUgdGhlIHNhbWVcbipcbiogQHBhcmFtIHN0cmluZ2lmeVF1ZXJ5IC0gQSBmdW5jdGlvbiB0aGF0IHRha2VzIGEgcXVlcnkgb2JqZWN0IG9mIHR5cGUgTG9jYXRpb25RdWVyeVJhdyBhbmQgcmV0dXJucyBhIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiBpdC5cbiogQHBhcmFtIGEgLSBmaXJzdCB7QGxpbmsgUm91dGVMb2NhdGlvbn1cbiogQHBhcmFtIGIgLSBzZWNvbmQge0BsaW5rIFJvdXRlTG9jYXRpb259XG4qL1xuZnVuY3Rpb24gaXNTYW1lUm91dGVMb2NhdGlvbihzdHJpbmdpZnlRdWVyeSQxLCBhLCBiKSB7XG5cdGNvbnN0IGFMYXN0SW5kZXggPSBhLm1hdGNoZWQubGVuZ3RoIC0gMTtcblx0Y29uc3QgYkxhc3RJbmRleCA9IGIubWF0Y2hlZC5sZW5ndGggLSAxO1xuXHRyZXR1cm4gYUxhc3RJbmRleCA+IC0xICYmIGFMYXN0SW5kZXggPT09IGJMYXN0SW5kZXggJiYgaXNTYW1lUm91dGVSZWNvcmQoYS5tYXRjaGVkW2FMYXN0SW5kZXhdLCBiLm1hdGNoZWRbYkxhc3RJbmRleF0pICYmIGlzU2FtZVJvdXRlTG9jYXRpb25QYXJhbXMoYS5wYXJhbXMsIGIucGFyYW1zKSAmJiBzdHJpbmdpZnlRdWVyeSQxKGEucXVlcnkpID09PSBzdHJpbmdpZnlRdWVyeSQxKGIucXVlcnkpICYmIGEuaGFzaCA9PT0gYi5oYXNoO1xufVxuLyoqXG4qIENoZWNrIGlmIHR3byBgUm91dGVSZWNvcmRzYCBhcmUgZXF1YWwuIFRha2VzIGludG8gYWNjb3VudCBhbGlhc2VzOiB0aGV5IGFyZVxuKiBjb25zaWRlcmVkIGVxdWFsIHRvIHRoZSBgUm91dGVSZWNvcmRgIHRoZXkgYXJlIGFsaWFzaW5nLlxuKlxuKiBAcGFyYW0gYSAtIGZpcnN0IHtAbGluayBSb3V0ZVJlY29yZH1cbiogQHBhcmFtIGIgLSBzZWNvbmQge0BsaW5rIFJvdXRlUmVjb3JkfVxuKi9cbmZ1bmN0aW9uIGlzU2FtZVJvdXRlUmVjb3JkKGEsIGIpIHtcblx0cmV0dXJuIChhLmFsaWFzT2YgfHwgYSkgPT09IChiLmFsaWFzT2YgfHwgYik7XG59XG5mdW5jdGlvbiBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zKGEsIGIpIHtcblx0aWYgKE9iamVjdC5rZXlzKGEpLmxlbmd0aCAhPT0gT2JqZWN0LmtleXMoYikubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG5cdGZvciAodmFyIGtleSBpbiBhKSBpZiAoIWlzU2FtZVJvdXRlTG9jYXRpb25QYXJhbXNWYWx1ZShhW2tleV0sIGJba2V5XSkpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zVmFsdWUoYSwgYikge1xuXHRyZXR1cm4gaXNBcnJheShhKSA/IGlzRXF1aXZhbGVudEFycmF5KGEsIGIpIDogaXNBcnJheShiKSA/IGlzRXF1aXZhbGVudEFycmF5KGIsIGEpIDogYT8udmFsdWVPZigpID09PSBiPy52YWx1ZU9mKCk7XG59XG4vKipcbiogQ2hlY2sgaWYgdHdvIGFycmF5cyBhcmUgdGhlIHNhbWUgb3IgaWYgYW4gYXJyYXkgd2l0aCBvbmUgc2luZ2xlIGVudHJ5IGlzIHRoZVxuKiBzYW1lIGFzIGFub3RoZXIgcHJpbWl0aXZlIHZhbHVlLiBVc2VkIHRvIGNoZWNrIHF1ZXJ5IGFuZCBwYXJhbWV0ZXJzXG4qXG4qIEBwYXJhbSBhIC0gYXJyYXkgb2YgdmFsdWVzXG4qIEBwYXJhbSBiIC0gYXJyYXkgb2YgdmFsdWVzIG9yIGEgc2luZ2xlIHZhbHVlXG4qL1xuZnVuY3Rpb24gaXNFcXVpdmFsZW50QXJyYXkoYSwgYikge1xuXHRyZXR1cm4gaXNBcnJheShiKSA/IGEubGVuZ3RoID09PSBiLmxlbmd0aCAmJiBhLmV2ZXJ5KCh2YWx1ZSwgaSkgPT4gdmFsdWUgPT09IGJbaV0pIDogYS5sZW5ndGggPT09IDEgJiYgYVswXSA9PT0gYjtcbn1cbi8qKlxuKiBSZXNvbHZlcyBhIHJlbGF0aXZlIHBhdGggdGhhdCBzdGFydHMgd2l0aCBgLmAuXG4qXG4qIEBwYXJhbSB0byAtIHBhdGggbG9jYXRpb24gd2UgYXJlIHJlc29sdmluZ1xuKiBAcGFyYW0gZnJvbSAtIGN1cnJlbnRMb2NhdGlvbi5wYXRoLCBzaG91bGQgc3RhcnQgd2l0aCBgL2BcbiovXG5mdW5jdGlvbiByZXNvbHZlUmVsYXRpdmVQYXRoKHRvLCBmcm9tKSB7XG5cdGlmICh0by5zdGFydHNXaXRoKFwiL1wiKSkgcmV0dXJuIHRvO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFmcm9tLnN0YXJ0c1dpdGgoXCIvXCIpKSB7XG5cdFx0d2FybiQxKGBDYW5ub3QgcmVzb2x2ZSBhIHJlbGF0aXZlIGxvY2F0aW9uIHdpdGhvdXQgYW4gYWJzb2x1dGUgcGF0aC4gVHJ5aW5nIHRvIHJlc29sdmUgXCIke3RvfVwiIGZyb20gXCIke2Zyb219XCIuIEl0IHNob3VsZCBsb29rIGxpa2UgXCIvJHtmcm9tfVwiLmApO1xuXHRcdHJldHVybiB0bztcblx0fVxuXHRpZiAoIXRvKSByZXR1cm4gZnJvbTtcblx0Y29uc3QgZnJvbVNlZ21lbnRzID0gZnJvbS5zcGxpdChcIi9cIik7XG5cdGNvbnN0IHRvU2VnbWVudHMgPSB0by5zcGxpdChcIi9cIik7XG5cdGNvbnN0IGxhc3RUb1NlZ21lbnQgPSB0b1NlZ21lbnRzW3RvU2VnbWVudHMubGVuZ3RoIC0gMV07XG5cdGlmIChsYXN0VG9TZWdtZW50ID09PSBcIi4uXCIgfHwgbGFzdFRvU2VnbWVudCA9PT0gXCIuXCIpIHRvU2VnbWVudHMucHVzaChcIlwiKTtcblx0bGV0IHBvc2l0aW9uID0gZnJvbVNlZ21lbnRzLmxlbmd0aCAtIDE7XG5cdGxldCB0b1Bvc2l0aW9uO1xuXHRsZXQgc2VnbWVudDtcblx0Zm9yICh0b1Bvc2l0aW9uID0gMDsgdG9Qb3NpdGlvbiA8IHRvU2VnbWVudHMubGVuZ3RoOyB0b1Bvc2l0aW9uKyspIHtcblx0XHRzZWdtZW50ID0gdG9TZWdtZW50c1t0b1Bvc2l0aW9uXTtcblx0XHRpZiAoc2VnbWVudCA9PT0gXCIuXCIpIGNvbnRpbnVlO1xuXHRcdGlmIChzZWdtZW50ID09PSBcIi4uXCIpIHtcblx0XHRcdGlmIChwb3NpdGlvbiA+IDEpIHBvc2l0aW9uLS07XG5cdFx0fSBlbHNlIGJyZWFrO1xuXHR9XG5cdHJldHVybiBmcm9tU2VnbWVudHMuc2xpY2UoMCwgcG9zaXRpb24pLmpvaW4oXCIvXCIpICsgXCIvXCIgKyB0b1NlZ21lbnRzLnNsaWNlKHRvUG9zaXRpb24pLmpvaW4oXCIvXCIpO1xufVxuLyoqXG4qIEluaXRpYWwgcm91dGUgbG9jYXRpb24gd2hlcmUgdGhlIHJvdXRlciBpcy4gQ2FuIGJlIHVzZWQgaW4gbmF2aWdhdGlvbiBndWFyZHNcbiogdG8gZGlmZmVyZW50aWF0ZSB0aGUgaW5pdGlhbCBuYXZpZ2F0aW9uLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGBqc1xuKiBpbXBvcnQgeyBTVEFSVF9MT0NBVElPTiB9IGZyb20gJ3Z1ZS1yb3V0ZXInXG4qXG4qIHJvdXRlci5iZWZvcmVFYWNoKCh0bywgZnJvbSkgPT4ge1xuKiAgIGlmIChmcm9tID09PSBTVEFSVF9MT0NBVElPTikge1xuKiAgICAgLy8gaW5pdGlhbCBuYXZpZ2F0aW9uXG4qICAgfVxuKiB9KVxuKiBgYGBcbiovXG5jb25zdCBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEID0ge1xuXHRwYXRoOiBcIi9cIixcblx0bmFtZTogdm9pZCAwLFxuXHRwYXJhbXM6IHt9LFxuXHRxdWVyeToge30sXG5cdGhhc2g6IFwiXCIsXG5cdGZ1bGxQYXRoOiBcIi9cIixcblx0bWF0Y2hlZDogW10sXG5cdG1ldGE6IHt9LFxuXHRyZWRpcmVjdGVkRnJvbTogdm9pZCAwXG59O1xuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaGlzdG9yeS9jb21tb24udHNcbmxldCBOYXZpZ2F0aW9uVHlwZSA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihOYXZpZ2F0aW9uVHlwZSQxKSB7XG5cdE5hdmlnYXRpb25UeXBlJDFbXCJwb3BcIl0gPSBcInBvcFwiO1xuXHROYXZpZ2F0aW9uVHlwZSQxW1wicHVzaFwiXSA9IFwicHVzaFwiO1xuXHRyZXR1cm4gTmF2aWdhdGlvblR5cGUkMTtcbn0oe30pO1xubGV0IE5hdmlnYXRpb25EaXJlY3Rpb24gPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oTmF2aWdhdGlvbkRpcmVjdGlvbiQxKSB7XG5cdE5hdmlnYXRpb25EaXJlY3Rpb24kMVtcImJhY2tcIl0gPSBcImJhY2tcIjtcblx0TmF2aWdhdGlvbkRpcmVjdGlvbiQxW1wiZm9yd2FyZFwiXSA9IFwiZm9yd2FyZFwiO1xuXHROYXZpZ2F0aW9uRGlyZWN0aW9uJDFbXCJ1bmtub3duXCJdID0gXCJcIjtcblx0cmV0dXJuIE5hdmlnYXRpb25EaXJlY3Rpb24kMTtcbn0oe30pO1xuLyoqXG4qIFN0YXJ0aW5nIGxvY2F0aW9uIGZvciBIaXN0b3JpZXNcbiovXG5jb25zdCBTVEFSVCA9IFwiXCI7XG4vKipcbiogTm9ybWFsaXplcyBhIGJhc2UgYnkgcmVtb3ZpbmcgYW55IHRyYWlsaW5nIHNsYXNoIGFuZCByZWFkaW5nIHRoZSBiYXNlIHRhZyBpZlxuKiBwcmVzZW50LlxuKlxuKiBAcGFyYW0gYmFzZSAtIGJhc2UgdG8gbm9ybWFsaXplXG4qL1xuZnVuY3Rpb24gbm9ybWFsaXplQmFzZShiYXNlKSB7XG5cdGlmICghYmFzZSkgaWYgKGlzQnJvd3Nlcikge1xuXHRcdGNvbnN0IGJhc2VFbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJiYXNlXCIpO1xuXHRcdGJhc2UgPSBiYXNlRWwgJiYgYmFzZUVsLmdldEF0dHJpYnV0ZShcImhyZWZcIikgfHwgXCIvXCI7XG5cdFx0YmFzZSA9IGJhc2UucmVwbGFjZSgvXlxcdys6XFwvXFwvW15cXC9dKy8sIFwiXCIpO1xuXHR9IGVsc2UgYmFzZSA9IFwiL1wiO1xuXHRpZiAoYmFzZVswXSAhPT0gXCIvXCIgJiYgYmFzZVswXSAhPT0gXCIjXCIpIGJhc2UgPSBcIi9cIiArIGJhc2U7XG5cdHJldHVybiByZW1vdmVUcmFpbGluZ1NsYXNoKGJhc2UpO1xufVxuY29uc3QgQkVGT1JFX0hBU0hfUkUgPSAvXlteI10rIy87XG5mdW5jdGlvbiBjcmVhdGVIcmVmKGJhc2UsIGxvY2F0aW9uKSB7XG5cdHJldHVybiBiYXNlLnJlcGxhY2UoQkVGT1JFX0hBU0hfUkUsIFwiI1wiKSArIGxvY2F0aW9uO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2Nyb2xsQmVoYXZpb3IudHNcbmZ1bmN0aW9uIGdldEVsZW1lbnRQb3NpdGlvbihlbCwgb2Zmc2V0KSB7XG5cdGNvbnN0IGRvY1JlY3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdGNvbnN0IGVsUmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRyZXR1cm4ge1xuXHRcdGJlaGF2aW9yOiBvZmZzZXQuYmVoYXZpb3IsXG5cdFx0bGVmdDogZWxSZWN0LmxlZnQgLSBkb2NSZWN0LmxlZnQgLSAob2Zmc2V0LmxlZnQgfHwgMCksXG5cdFx0dG9wOiBlbFJlY3QudG9wIC0gZG9jUmVjdC50b3AgLSAob2Zmc2V0LnRvcCB8fCAwKVxuXHR9O1xufVxuY29uc3QgY29tcHV0ZVNjcm9sbFBvc2l0aW9uID0gKCkgPT4gKHtcblx0bGVmdDogd2luZG93LnNjcm9sbFgsXG5cdHRvcDogd2luZG93LnNjcm9sbFlcbn0pO1xuZnVuY3Rpb24gc2Nyb2xsVG9Qb3NpdGlvbihwb3NpdGlvbikge1xuXHRsZXQgc2Nyb2xsVG9PcHRpb25zO1xuXHRpZiAoXCJlbFwiIGluIHBvc2l0aW9uKSB7XG5cdFx0Y29uc3QgcG9zaXRpb25FbCA9IHBvc2l0aW9uLmVsO1xuXHRcdGNvbnN0IGlzSWRTZWxlY3RvciA9IHR5cGVvZiBwb3NpdGlvbkVsID09PSBcInN0cmluZ1wiICYmIHBvc2l0aW9uRWwuc3RhcnRzV2l0aChcIiNcIik7XG5cdFx0LyoqXG5cdFx0KiBgaWRgcyBjYW4gYWNjZXB0IHByZXR0eSBtdWNoIGFueSBjaGFyYWN0ZXJzLCBpbmNsdWRpbmcgQ1NTIGNvbWJpbmF0b3JzXG5cdFx0KiBsaWtlIGA+YCBvciBgfmAuIEl0J3Mgc3RpbGwgcG9zc2libGUgdG8gcmV0cmlldmUgZWxlbWVudHMgdXNpbmdcblx0XHQqIGBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnficpYCBidXQgaXQgbmVlZHMgdG8gYmUgZXNjYXBlZCB3aGVuIHVzaW5nXG5cdFx0KiBgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI1xcXFx+JylgIGZvciBpdCB0byBiZSB2YWxpZC4gVGhlIG9ubHlcblx0XHQqIHJlcXVpcmVtZW50cyBmb3IgYGlkYHMgYXJlIHRoZW0gdG8gYmUgdW5pcXVlIG9uIHRoZSBwYWdlIGFuZCB0byBub3QgYmVcblx0XHQqIGVtcHR5IChgaWQ9XCJcImApLiBCZWNhdXNlIG9mIHRoYXQsIHdoZW4gcGFzc2luZyBhbiBpZCBzZWxlY3RvciwgaXQgc2hvdWxkXG5cdFx0KiBiZSBwcm9wZXJseSBlc2NhcGVkIGZvciBpdCB0byB3b3JrIHdpdGggYHF1ZXJ5U2VsZWN0b3JgLiBXZSBjb3VsZCBjaGVja1xuXHRcdCogZm9yIHRoZSBpZCBzZWxlY3RvciB0byBiZSBzaW1wbGUgKG5vIENTUyBjb21iaW5hdG9ycyBgKyA+fmApIGJ1dCB0aGF0XG5cdFx0KiB3b3VsZCBtYWtlIHRoaW5ncyBpbmNvbnNpc3RlbnQgc2luY2UgdGhleSBhcmUgdmFsaWQgY2hhcmFjdGVycyBmb3IgYW5cblx0XHQqIGBpZGAgYnV0IHdvdWxkIG5lZWQgdG8gYmUgZXNjYXBlZCB3aGVuIHVzaW5nIGBxdWVyeVNlbGVjdG9yYCwgYnJlYWtpbmdcblx0XHQqIHRoZWlyIHVzYWdlIGFuZCBlbmRpbmcgdXAgaW4gbm8gc2VsZWN0b3IgcmV0dXJuZWQuIFNlbGVjdG9ycyBuZWVkIHRvIGJlXG5cdFx0KiBlc2NhcGVkOlxuXHRcdCpcblx0XHQqIC0gYCMxLXRoaW5nYCBiZWNvbWVzIGAjXFwzMSAtdGhpbmdgXG5cdFx0KiAtIGAjd2l0aH5zeW1ib2xzYCBiZWNvbWVzIGAjd2l0aFxcXFx+c3ltYm9sc2Bcblx0XHQqXG5cdFx0KiAtIE1vcmUgaW5mb3JtYXRpb24gYWJvdXQgIHRoZSB0b3BpYyBjYW4gYmUgZm91bmQgYXRcblx0XHQqICAgaHR0cHM6Ly9tYXRoaWFzYnluZW5zLmJlL25vdGVzL2h0bWw1LWlkLWNsYXNzLlxuXHRcdCogLSBQcmFjdGljYWwgZXhhbXBsZTogaHR0cHM6Ly9tYXRoaWFzYnluZW5zLmJlL2RlbW8vaHRtbDUtaWRcblx0XHQqL1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgdHlwZW9mIHBvc2l0aW9uLmVsID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRpZiAoIWlzSWRTZWxlY3RvciB8fCAhZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQocG9zaXRpb24uZWwuc2xpY2UoMSkpKSB0cnkge1xuXHRcdFx0XHRjb25zdCBmb3VuZEVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihwb3NpdGlvbi5lbCk7XG5cdFx0XHRcdGlmIChpc0lkU2VsZWN0b3IgJiYgZm91bmRFbCkge1xuXHRcdFx0XHRcdHdhcm4kMShgVGhlIHNlbGVjdG9yIFwiJHtwb3NpdGlvbi5lbH1cIiBzaG91bGQgYmUgcGFzc2VkIGFzIFwiZWw6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyR7cG9zaXRpb24uZWx9JylcIiBiZWNhdXNlIGl0IHN0YXJ0cyB3aXRoIFwiI1wiLmApO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdHdhcm4kMShgVGhlIHNlbGVjdG9yIFwiJHtwb3NpdGlvbi5lbH1cIiBpcyBpbnZhbGlkLiBJZiB5b3UgYXJlIHVzaW5nIGFuIGlkIHNlbGVjdG9yLCBtYWtlIHN1cmUgdG8gZXNjYXBlIGl0LiBZb3UgY2FuIGZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCBlc2NhcGluZyBjaGFyYWN0ZXJzIGluIHNlbGVjdG9ycyBhdCBodHRwczovL21hdGhpYXNieW5lbnMuYmUvbm90ZXMvY3NzLWVzY2FwZXMgb3IgdXNlIENTUy5lc2NhcGUgKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DU1MvZXNjYXBlKS5gKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRjb25zdCBlbCA9IHR5cGVvZiBwb3NpdGlvbkVsID09PSBcInN0cmluZ1wiID8gaXNJZFNlbGVjdG9yID8gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQocG9zaXRpb25FbC5zbGljZSgxKSkgOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHBvc2l0aW9uRWwpIDogcG9zaXRpb25FbDtcblx0XHRpZiAoIWVsKSB7XG5cdFx0XHRwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgd2FybiQxKGBDb3VsZG4ndCBmaW5kIGVsZW1lbnQgdXNpbmcgc2VsZWN0b3IgXCIke3Bvc2l0aW9uLmVsfVwiIHJldHVybmVkIGJ5IHNjcm9sbEJlaGF2aW9yLmApO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRzY3JvbGxUb09wdGlvbnMgPSBnZXRFbGVtZW50UG9zaXRpb24oZWwsIHBvc2l0aW9uKTtcblx0fSBlbHNlIHNjcm9sbFRvT3B0aW9ucyA9IHBvc2l0aW9uO1xuXHRpZiAoXCJzY3JvbGxCZWhhdmlvclwiIGluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZSkgd2luZG93LnNjcm9sbFRvKHNjcm9sbFRvT3B0aW9ucyk7XG5cdGVsc2Ugd2luZG93LnNjcm9sbFRvKHNjcm9sbFRvT3B0aW9ucy5sZWZ0ICE9IG51bGwgPyBzY3JvbGxUb09wdGlvbnMubGVmdCA6IHdpbmRvdy5zY3JvbGxYLCBzY3JvbGxUb09wdGlvbnMudG9wICE9IG51bGwgPyBzY3JvbGxUb09wdGlvbnMudG9wIDogd2luZG93LnNjcm9sbFkpO1xufVxuZnVuY3Rpb24gZ2V0U2Nyb2xsS2V5KHBhdGgsIGRlbHRhKSB7XG5cdHJldHVybiAoaGlzdG9yeS5zdGF0ZSA/IGhpc3Rvcnkuc3RhdGUucG9zaXRpb24gLSBkZWx0YSA6IC0xKSArIHBhdGg7XG59XG5jb25zdCBzY3JvbGxQb3NpdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuZnVuY3Rpb24gc2F2ZVNjcm9sbFBvc2l0aW9uKGtleSwgc2Nyb2xsUG9zaXRpb24pIHtcblx0c2Nyb2xsUG9zaXRpb25zLnNldChrZXksIHNjcm9sbFBvc2l0aW9uKTtcbn1cbmZ1bmN0aW9uIGdldFNhdmVkU2Nyb2xsUG9zaXRpb24oa2V5KSB7XG5cdGNvbnN0IHNjcm9sbCA9IHNjcm9sbFBvc2l0aW9ucy5nZXQoa2V5KTtcblx0c2Nyb2xsUG9zaXRpb25zLmRlbGV0ZShrZXkpO1xuXHRyZXR1cm4gc2Nyb2xsO1xufVxuLyoqXG4qIFNjcm9sbEJlaGF2aW9yIGluc3RhbmNlIHVzZWQgYnkgdGhlIHJvdXRlciB0byBjb21wdXRlIGFuZCByZXN0b3JlIHRoZSBzY3JvbGxcbiogcG9zaXRpb24gd2hlbiBuYXZpZ2F0aW5nLlxuKi9cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3R5cGVzL3R5cGVHdWFyZHMudHNcbmZ1bmN0aW9uIGlzUm91dGVMb2NhdGlvbihyb3V0ZSkge1xuXHRyZXR1cm4gdHlwZW9mIHJvdXRlID09PSBcInN0cmluZ1wiIHx8IHJvdXRlICYmIHR5cGVvZiByb3V0ZSA9PT0gXCJvYmplY3RcIjtcbn1cbmZ1bmN0aW9uIGlzUm91dGVOYW1lKG5hbWUpIHtcblx0cmV0dXJuIHR5cGVvZiBuYW1lID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiBuYW1lID09PSBcInN5bWJvbFwiO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZXJyb3JzLnRzXG4vKipcbiogRmxhZ3Mgc28gd2UgY2FuIGNvbWJpbmUgdGhlbSB3aGVuIGNoZWNraW5nIGZvciBtdWx0aXBsZSBlcnJvcnMuIFRoaXMgaXMgdGhlIGludGVybmFsIHZlcnNpb24gb2Zcbioge0BsaW5rIE5hdmlnYXRpb25GYWlsdXJlVHlwZX0uXG4qXG4qIEBpbnRlcm5hbFxuKi9cbmxldCBFcnJvclR5cGVzID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKEVycm9yVHlwZXMkMSkge1xuXHRFcnJvclR5cGVzJDFbRXJyb3JUeXBlcyQxW1wiTUFUQ0hFUl9OT1RfRk9VTkRcIl0gPSAxXSA9IFwiTUFUQ0hFUl9OT1RfRk9VTkRcIjtcblx0RXJyb3JUeXBlcyQxW0Vycm9yVHlwZXMkMVtcIk5BVklHQVRJT05fR1VBUkRfUkVESVJFQ1RcIl0gPSAyXSA9IFwiTkFWSUdBVElPTl9HVUFSRF9SRURJUkVDVFwiO1xuXHRFcnJvclR5cGVzJDFbRXJyb3JUeXBlcyQxW1wiTkFWSUdBVElPTl9BQk9SVEVEXCJdID0gNF0gPSBcIk5BVklHQVRJT05fQUJPUlRFRFwiO1xuXHRFcnJvclR5cGVzJDFbRXJyb3JUeXBlcyQxW1wiTkFWSUdBVElPTl9DQU5DRUxMRURcIl0gPSA4XSA9IFwiTkFWSUdBVElPTl9DQU5DRUxMRURcIjtcblx0RXJyb3JUeXBlcyQxW0Vycm9yVHlwZXMkMVtcIk5BVklHQVRJT05fRFVQTElDQVRFRFwiXSA9IDE2XSA9IFwiTkFWSUdBVElPTl9EVVBMSUNBVEVEXCI7XG5cdHJldHVybiBFcnJvclR5cGVzJDE7XG59KHt9KTtcbmNvbnN0IE5hdmlnYXRpb25GYWlsdXJlU3ltYm9sID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwibmF2aWdhdGlvbiBmYWlsdXJlXCIgOiBcIlwiKTtcbi8qKlxuKiBFbnVtZXJhdGlvbiB3aXRoIGFsbCBwb3NzaWJsZSB0eXBlcyBmb3IgbmF2aWdhdGlvbiBmYWlsdXJlcy4gQ2FuIGJlIHBhc3NlZCB0b1xuKiB7QGxpbmsgaXNOYXZpZ2F0aW9uRmFpbHVyZX0gdG8gY2hlY2sgZm9yIHNwZWNpZmljIGZhaWx1cmVzLlxuKi9cbmxldCBOYXZpZ2F0aW9uRmFpbHVyZVR5cGUgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oTmF2aWdhdGlvbkZhaWx1cmVUeXBlJDEpIHtcblx0LyoqXG5cdCogQW4gYWJvcnRlZCBuYXZpZ2F0aW9uIGlzIGEgbmF2aWdhdGlvbiB0aGF0IGZhaWxlZCBiZWNhdXNlIGEgbmF2aWdhdGlvblxuXHQqIGd1YXJkIHJldHVybmVkIGBmYWxzZWAgb3IgY2FsbGVkIGBuZXh0KGZhbHNlKWBcblx0Ki9cblx0TmF2aWdhdGlvbkZhaWx1cmVUeXBlJDFbTmF2aWdhdGlvbkZhaWx1cmVUeXBlJDFbXCJhYm9ydGVkXCJdID0gNF0gPSBcImFib3J0ZWRcIjtcblx0LyoqXG5cdCogQSBjYW5jZWxsZWQgbmF2aWdhdGlvbiBpcyBhIG5hdmlnYXRpb24gdGhhdCBmYWlsZWQgYmVjYXVzZSBhIG1vcmUgcmVjZW50XG5cdCogbmF2aWdhdGlvbiBmaW5pc2hlZCBzdGFydGVkIChub3QgbmVjZXNzYXJpbHkgZmluaXNoZWQpLlxuXHQqL1xuXHROYXZpZ2F0aW9uRmFpbHVyZVR5cGUkMVtOYXZpZ2F0aW9uRmFpbHVyZVR5cGUkMVtcImNhbmNlbGxlZFwiXSA9IDhdID0gXCJjYW5jZWxsZWRcIjtcblx0LyoqXG5cdCogQSBkdXBsaWNhdGVkIG5hdmlnYXRpb24gaXMgYSBuYXZpZ2F0aW9uIHRoYXQgZmFpbGVkIGJlY2F1c2UgaXQgd2FzXG5cdCogaW5pdGlhdGVkIHdoaWxlIGFscmVhZHkgYmVpbmcgYXQgdGhlIGV4YWN0IHNhbWUgbG9jYXRpb24uXG5cdCovXG5cdE5hdmlnYXRpb25GYWlsdXJlVHlwZSQxW05hdmlnYXRpb25GYWlsdXJlVHlwZSQxW1wiZHVwbGljYXRlZFwiXSA9IDE2XSA9IFwiZHVwbGljYXRlZFwiO1xuXHRyZXR1cm4gTmF2aWdhdGlvbkZhaWx1cmVUeXBlJDE7XG59KHt9KTtcbmNvbnN0IEVycm9yVHlwZU1lc3NhZ2VzID0ge1xuXHRbRXJyb3JUeXBlcy5NQVRDSEVSX05PVF9GT1VORF0oeyBsb2NhdGlvbiwgY3VycmVudExvY2F0aW9uIH0pIHtcblx0XHRyZXR1cm4gYE5vIG1hdGNoIGZvclxcbiAke0pTT04uc3RyaW5naWZ5KGxvY2F0aW9uKX0ke2N1cnJlbnRMb2NhdGlvbiA/IFwiXFxud2hpbGUgYmVpbmcgYXRcXG5cIiArIEpTT04uc3RyaW5naWZ5KGN1cnJlbnRMb2NhdGlvbikgOiBcIlwifWA7XG5cdH0sXG5cdFtFcnJvclR5cGVzLk5BVklHQVRJT05fR1VBUkRfUkVESVJFQ1RdKHsgZnJvbSwgdG8gfSkge1xuXHRcdHJldHVybiBgUmVkaXJlY3RlZCBmcm9tIFwiJHtmcm9tLmZ1bGxQYXRofVwiIHRvIFwiJHtzdHJpbmdpZnlSb3V0ZSh0byl9XCIgdmlhIGEgbmF2aWdhdGlvbiBndWFyZC5gO1xuXHR9LFxuXHRbRXJyb3JUeXBlcy5OQVZJR0FUSU9OX0FCT1JURURdKHsgZnJvbSwgdG8gfSkge1xuXHRcdHJldHVybiBgTmF2aWdhdGlvbiBhYm9ydGVkIGZyb20gXCIke2Zyb20uZnVsbFBhdGh9XCIgdG8gXCIke3RvLmZ1bGxQYXRofVwiIHZpYSBhIG5hdmlnYXRpb24gZ3VhcmQuYDtcblx0fSxcblx0W0Vycm9yVHlwZXMuTkFWSUdBVElPTl9DQU5DRUxMRURdKHsgZnJvbSwgdG8gfSkge1xuXHRcdHJldHVybiBgTmF2aWdhdGlvbiBjYW5jZWxsZWQgZnJvbSBcIiR7ZnJvbS5mdWxsUGF0aH1cIiB0byBcIiR7dG8uZnVsbFBhdGh9XCIgd2l0aCBhIG5ldyBuYXZpZ2F0aW9uLmA7XG5cdH0sXG5cdFtFcnJvclR5cGVzLk5BVklHQVRJT05fRFVQTElDQVRFRF0oeyBmcm9tLCB0byB9KSB7XG5cdFx0cmV0dXJuIGBBdm9pZGVkIHJlZHVuZGFudCBuYXZpZ2F0aW9uIHRvIGN1cnJlbnQgbG9jYXRpb246IFwiJHtmcm9tLmZ1bGxQYXRofVwiLmA7XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlcyBhIHR5cGVkIE5hdmlnYXRpb25GYWlsdXJlIG9iamVjdC5cbiogQGludGVybmFsXG4qIEBwYXJhbSB0eXBlIC0gTmF2aWdhdGlvbkZhaWx1cmVUeXBlXG4qIEBwYXJhbSBwYXJhbXMgLSB7IGZyb20sIHRvIH1cbiovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXJFcnJvcih0eXBlLCBwYXJhbXMpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBmYWxzZSkgcmV0dXJuIGFzc2lnbihuZXcgRXJyb3IoRXJyb3JUeXBlTWVzc2FnZXNbdHlwZV0ocGFyYW1zKSksIHtcblx0XHR0eXBlLFxuXHRcdFtOYXZpZ2F0aW9uRmFpbHVyZVN5bWJvbF06IHRydWVcblx0fSwgcGFyYW1zKTtcblx0ZWxzZSByZXR1cm4gYXNzaWduKC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoKSwge1xuXHRcdHR5cGUsXG5cdFx0W05hdmlnYXRpb25GYWlsdXJlU3ltYm9sXTogdHJ1ZVxuXHR9LCBwYXJhbXMpO1xufVxuZnVuY3Rpb24gaXNOYXZpZ2F0aW9uRmFpbHVyZShlcnJvciwgdHlwZSkge1xuXHRyZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBOYXZpZ2F0aW9uRmFpbHVyZVN5bWJvbCBpbiBlcnJvciAmJiAodHlwZSA9PSBudWxsIHx8ICEhKGVycm9yLnR5cGUgJiB0eXBlKSk7XG59XG5jb25zdCBwcm9wZXJ0aWVzVG9Mb2cgPSBbXG5cdFwicGFyYW1zXCIsXG5cdFwicXVlcnlcIixcblx0XCJoYXNoXCJcbl07XG5mdW5jdGlvbiBzdHJpbmdpZnlSb3V0ZSh0bykge1xuXHRpZiAodHlwZW9mIHRvID09PSBcInN0cmluZ1wiKSByZXR1cm4gdG87XG5cdGlmICh0by5wYXRoICE9IG51bGwpIHJldHVybiB0by5wYXRoO1xuXHRjb25zdCBsb2NhdGlvbiA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBvZiBwcm9wZXJ0aWVzVG9Mb2cpIGlmIChrZXkgaW4gdG8pIGxvY2F0aW9uW2tleV0gPSB0b1trZXldO1xuXHRyZXR1cm4gSlNPTi5zdHJpbmdpZnkobG9jYXRpb24sIG51bGwsIDIpO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvcXVlcnkudHNcbi8qKlxuKiBUcmFuc2Zvcm1zIGEgcXVlcnlTdHJpbmcgaW50byBhIHtAbGluayBMb2NhdGlvblF1ZXJ5fSBvYmplY3QuIEFjY2VwdCBib3RoLCBhXG4qIHZlcnNpb24gd2l0aCB0aGUgbGVhZGluZyBgP2AgYW5kIHdpdGhvdXQgU2hvdWxkIHdvcmsgYXMgVVJMU2VhcmNoUGFyYW1zXG5cbiogQGludGVybmFsXG4qXG4qIEBwYXJhbSBzZWFyY2ggLSBzZWFyY2ggc3RyaW5nIHRvIHBhcnNlXG4qIEByZXR1cm5zIGEgcXVlcnkgb2JqZWN0XG4qL1xuZnVuY3Rpb24gcGFyc2VRdWVyeShzZWFyY2gpIHtcblx0Y29uc3QgcXVlcnkgPSB7fTtcblx0aWYgKHNlYXJjaCA9PT0gXCJcIiB8fCBzZWFyY2ggPT09IFwiP1wiKSByZXR1cm4gcXVlcnk7XG5cdGNvbnN0IHNlYXJjaFBhcmFtcyA9IChzZWFyY2hbMF0gPT09IFwiP1wiID8gc2VhcmNoLnNsaWNlKDEpIDogc2VhcmNoKS5zcGxpdChcIiZcIik7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgc2VhcmNoUGFyYW1zLmxlbmd0aDsgKytpKSB7XG5cdFx0Y29uc3Qgc2VhcmNoUGFyYW0gPSBzZWFyY2hQYXJhbXNbaV0ucmVwbGFjZShQTFVTX1JFLCBcIiBcIik7XG5cdFx0Y29uc3QgZXFQb3MgPSBzZWFyY2hQYXJhbS5pbmRleE9mKFwiPVwiKTtcblx0XHRjb25zdCBrZXkgPSBkZWNvZGUoZXFQb3MgPCAwID8gc2VhcmNoUGFyYW0gOiBzZWFyY2hQYXJhbS5zbGljZSgwLCBlcVBvcykpO1xuXHRcdGNvbnN0IHZhbHVlID0gZXFQb3MgPCAwID8gbnVsbCA6IGRlY29kZShzZWFyY2hQYXJhbS5zbGljZShlcVBvcyArIDEpKTtcblx0XHRpZiAoa2V5IGluIHF1ZXJ5KSB7XG5cdFx0XHRsZXQgY3VycmVudFZhbHVlID0gcXVlcnlba2V5XTtcblx0XHRcdGlmICghaXNBcnJheShjdXJyZW50VmFsdWUpKSBjdXJyZW50VmFsdWUgPSBxdWVyeVtrZXldID0gW2N1cnJlbnRWYWx1ZV07XG5cdFx0XHRjdXJyZW50VmFsdWUucHVzaCh2YWx1ZSk7XG5cdFx0fSBlbHNlIHF1ZXJ5W2tleV0gPSB2YWx1ZTtcblx0fVxuXHRyZXR1cm4gcXVlcnk7XG59XG4vKipcbiogU3RyaW5naWZpZXMgYSB7QGxpbmsgTG9jYXRpb25RdWVyeVJhd30gb2JqZWN0LiBMaWtlIGBVUkxTZWFyY2hQYXJhbXNgLCBpdFxuKiBkb2Vzbid0IHByZXBlbmQgYSBgP2BcbipcbiogQGludGVybmFsXG4qXG4qIEBwYXJhbSBxdWVyeSAtIHF1ZXJ5IG9iamVjdCB0byBzdHJpbmdpZnlcbiogQHJldHVybnMgc3RyaW5nIHZlcnNpb24gb2YgdGhlIHF1ZXJ5IHdpdGhvdXQgdGhlIGxlYWRpbmcgYD9gXG4qL1xuZnVuY3Rpb24gc3RyaW5naWZ5UXVlcnkocXVlcnkpIHtcblx0bGV0IHNlYXJjaCA9IFwiXCI7XG5cdGZvciAobGV0IGtleSBpbiBxdWVyeSkge1xuXHRcdGNvbnN0IHZhbHVlID0gcXVlcnlba2V5XTtcblx0XHRrZXkgPSBlbmNvZGVRdWVyeUtleShrZXkpO1xuXHRcdGlmICh2YWx1ZSA9PSBudWxsKSB7XG5cdFx0XHRpZiAodmFsdWUgIT09IHZvaWQgMCkgc2VhcmNoICs9IChzZWFyY2gubGVuZ3RoID8gXCImXCIgOiBcIlwiKSArIGtleTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHQoaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAoKHYpID0+IHYgJiYgZW5jb2RlUXVlcnlWYWx1ZSh2KSkgOiBbdmFsdWUgJiYgZW5jb2RlUXVlcnlWYWx1ZSh2YWx1ZSldKS5mb3JFYWNoKCh2YWx1ZSQxKSA9PiB7XG5cdFx0XHRpZiAodmFsdWUkMSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdHNlYXJjaCArPSAoc2VhcmNoLmxlbmd0aCA/IFwiJlwiIDogXCJcIikgKyBrZXk7XG5cdFx0XHRcdGlmICh2YWx1ZSQxICE9IG51bGwpIHNlYXJjaCArPSBcIj1cIiArIHZhbHVlJDE7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHNlYXJjaDtcbn1cbi8qKlxuKiBUcmFuc2Zvcm1zIGEge0BsaW5rIExvY2F0aW9uUXVlcnlSYXd9IGludG8gYSB7QGxpbmsgTG9jYXRpb25RdWVyeX0gYnkgY2FzdGluZ1xuKiBudW1iZXJzIGludG8gc3RyaW5ncywgcmVtb3Zpbmcga2V5cyB3aXRoIGFuIHVuZGVmaW5lZCB2YWx1ZSBhbmQgcmVwbGFjaW5nXG4qIHVuZGVmaW5lZCB3aXRoIG51bGwgaW4gYXJyYXlzXG4qXG4qIEBwYXJhbSBxdWVyeSAtIHF1ZXJ5IG9iamVjdCB0byBub3JtYWxpemVcbiogQHJldHVybnMgYSBub3JtYWxpemVkIHF1ZXJ5IG9iamVjdFxuKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZVF1ZXJ5KHF1ZXJ5KSB7XG5cdGNvbnN0IG5vcm1hbGl6ZWRRdWVyeSA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBxdWVyeSkge1xuXHRcdGNvbnN0IHZhbHVlID0gcXVlcnlba2V5XTtcblx0XHRpZiAodmFsdWUgIT09IHZvaWQgMCkgbm9ybWFsaXplZFF1ZXJ5W2tleV0gPSBpc0FycmF5KHZhbHVlKSA/IHZhbHVlLm1hcCgodikgPT4gdiA9PSBudWxsID8gbnVsbCA6IFwiXCIgKyB2KSA6IHZhbHVlID09IG51bGwgPyB2YWx1ZSA6IFwiXCIgKyB2YWx1ZTtcblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFF1ZXJ5O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW5qZWN0aW9uU3ltYm9scy50c1xuLyoqXG4qIFJvdXRlUmVjb3JkIGJlaW5nIHJlbmRlcmVkIGJ5IHRoZSBjbG9zZXN0IGFuY2VzdG9yIFJvdXRlciBWaWV3LiBVc2VkIGZvclxuKiBgb25CZWZvcmVSb3V0ZVVwZGF0ZWAgYW5kIGBvbkJlZm9yZVJvdXRlTGVhdmVgLiBydmxtIHN0YW5kcyBmb3IgUm91dGVyIFZpZXdcbiogTG9jYXRpb24gTWF0Y2hlZFxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCBtYXRjaGVkUm91dGVLZXkgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJyb3V0ZXIgdmlldyBsb2NhdGlvbiBtYXRjaGVkXCIgOiBcIlwiKTtcbi8qKlxuKiBBbGxvd3Mgb3ZlcnJpZGluZyB0aGUgcm91dGVyIHZpZXcgZGVwdGggdG8gY29udHJvbCB3aGljaCBjb21wb25lbnQgaW5cbiogYG1hdGNoZWRgIGlzIHJlbmRlcmVkLiBydmQgc3RhbmRzIGZvciBSb3V0ZXIgVmlldyBEZXB0aFxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCB2aWV3RGVwdGhLZXkgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJyb3V0ZXIgdmlldyBkZXB0aFwiIDogXCJcIik7XG4vKipcbiogQWxsb3dzIG92ZXJyaWRpbmcgdGhlIHJvdXRlciBpbnN0YW5jZSByZXR1cm5lZCBieSBgdXNlUm91dGVyYCBpbiB0ZXN0cy4gclxuKiBzdGFuZHMgZm9yIHJvdXRlclxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCByb3V0ZXJLZXkgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJyb3V0ZXJcIiA6IFwiXCIpO1xuLyoqXG4qIEFsbG93cyBvdmVycmlkaW5nIHRoZSBjdXJyZW50IHJvdXRlIHJldHVybmVkIGJ5IGB1c2VSb3V0ZWAgaW4gdGVzdHMuIHJsXG4qIHN0YW5kcyBmb3Igcm91dGUgbG9jYXRpb25cbipcbiogQGludGVybmFsXG4qL1xuY29uc3Qgcm91dGVMb2NhdGlvbktleSA9IFN5bWJvbChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBcInJvdXRlIGxvY2F0aW9uXCIgOiBcIlwiKTtcbi8qKlxuKiBBbGxvd3Mgb3ZlcnJpZGluZyB0aGUgY3VycmVudCByb3V0ZSB1c2VkIGJ5IHJvdXRlci12aWV3LiBJbnRlcm5hbGx5IHRoaXMgaXNcbiogdXNlZCB3aGVuIHRoZSBgcm91dGVgIHByb3AgaXMgcGFzc2VkLlxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCByb3V0ZXJWaWV3TG9jYXRpb25LZXkgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJyb3V0ZXIgdmlldyBsb2NhdGlvblwiIDogXCJcIik7XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9jYWxsYmFja3MudHNcbi8qKlxuKiBDcmVhdGUgYSBsaXN0IG9mIGNhbGxiYWNrcyB0aGF0IGNhbiBiZSByZXNldC4gVXNlZCB0byBjcmVhdGUgYmVmb3JlIGFuZCBhZnRlciBuYXZpZ2F0aW9uIGd1YXJkcyBsaXN0XG4qL1xuZnVuY3Rpb24gdXNlQ2FsbGJhY2tzKCkge1xuXHRsZXQgaGFuZGxlcnMgPSBbXTtcblx0ZnVuY3Rpb24gYWRkKGhhbmRsZXIpIHtcblx0XHRoYW5kbGVycy5wdXNoKGhhbmRsZXIpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjb25zdCBpID0gaGFuZGxlcnMuaW5kZXhPZihoYW5kbGVyKTtcblx0XHRcdGlmIChpID4gLTEpIGhhbmRsZXJzLnNwbGljZShpLCAxKTtcblx0XHR9O1xuXHR9XG5cdGZ1bmN0aW9uIHJlc2V0KCkge1xuXHRcdGhhbmRsZXJzID0gW107XG5cdH1cblx0cmV0dXJuIHtcblx0XHRhZGQsXG5cdFx0bGlzdDogKCkgPT4gaGFuZGxlcnMuc2xpY2UoKSxcblx0XHRyZXNldFxuXHR9O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbmF2aWdhdGlvbkd1YXJkcy50c1xuZnVuY3Rpb24gcmVnaXN0ZXJHdWFyZChyZWNvcmQsIG5hbWUsIGd1YXJkKSB7XG5cdGNvbnN0IHJlbW92ZUZyb21MaXN0ID0gKCkgPT4ge1xuXHRcdHJlY29yZFtuYW1lXS5kZWxldGUoZ3VhcmQpO1xuXHR9O1xuXHRvblVubW91bnRlZChyZW1vdmVGcm9tTGlzdCk7XG5cdG9uRGVhY3RpdmF0ZWQocmVtb3ZlRnJvbUxpc3QpO1xuXHRvbkFjdGl2YXRlZCgoKSA9PiB7XG5cdFx0cmVjb3JkW25hbWVdLmFkZChndWFyZCk7XG5cdH0pO1xuXHRyZWNvcmRbbmFtZV0uYWRkKGd1YXJkKTtcbn1cbi8qKlxuKiBBZGQgYSBuYXZpZ2F0aW9uIGd1YXJkIHRoYXQgdHJpZ2dlcnMgd2hlbmV2ZXIgdGhlIGNvbXBvbmVudCBmb3IgdGhlIGN1cnJlbnRcbiogbG9jYXRpb24gaXMgYWJvdXQgdG8gYmUgbGVmdC4gU2ltaWxhciB0byB7QGxpbmsgYmVmb3JlUm91dGVMZWF2ZX0gYnV0IGNhbiBiZVxuKiB1c2VkIGluIGFueSBjb21wb25lbnQuIFRoZSBndWFyZCBpcyByZW1vdmVkIHdoZW4gdGhlIGNvbXBvbmVudCBpcyB1bm1vdW50ZWQuXG4qXG4qIEBwYXJhbSBsZWF2ZUd1YXJkIC0ge0BsaW5rIE5hdmlnYXRpb25HdWFyZH1cbiovXG5mdW5jdGlvbiBvbkJlZm9yZVJvdXRlTGVhdmUobGVhdmVHdWFyZCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFnZXRDdXJyZW50SW5zdGFuY2UoKSkge1xuXHRcdHdhcm4kMShcImdldEN1cnJlbnRJbnN0YW5jZSgpIHJldHVybmVkIG51bGwuIG9uQmVmb3JlUm91dGVMZWF2ZSgpIG11c3QgYmUgY2FsbGVkIGF0IHRoZSB0b3Agb2YgYSBzZXR1cCBmdW5jdGlvblwiKTtcblx0XHRyZXR1cm47XG5cdH1cblx0Y29uc3QgYWN0aXZlUmVjb3JkID0gaW5qZWN0KG1hdGNoZWRSb3V0ZUtleSwge30pLnZhbHVlO1xuXHRpZiAoIWFjdGl2ZVJlY29yZCkge1xuXHRcdHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiB3YXJuJDEoXCJObyBhY3RpdmUgcm91dGUgcmVjb3JkIHdhcyBmb3VuZCB3aGVuIGNhbGxpbmcgYG9uQmVmb3JlUm91dGVMZWF2ZSgpYC4gTWFrZSBzdXJlIHlvdSBjYWxsIHRoaXMgZnVuY3Rpb24gaW5zaWRlIGEgY29tcG9uZW50IGNoaWxkIG9mIDxyb3V0ZXItdmlldz4uIE1heWJlIHlvdSBjYWxsZWQgaXQgaW5zaWRlIG9mIEFwcC52dWU/XCIpO1xuXHRcdHJldHVybjtcblx0fVxuXHRyZWdpc3Rlckd1YXJkKGFjdGl2ZVJlY29yZCwgXCJsZWF2ZUd1YXJkc1wiLCBsZWF2ZUd1YXJkKTtcbn1cbi8qKlxuKiBBZGQgYSBuYXZpZ2F0aW9uIGd1YXJkIHRoYXQgdHJpZ2dlcnMgd2hlbmV2ZXIgdGhlIGN1cnJlbnQgbG9jYXRpb24gaXMgYWJvdXRcbiogdG8gYmUgdXBkYXRlZC4gU2ltaWxhciB0byB7QGxpbmsgYmVmb3JlUm91dGVVcGRhdGV9IGJ1dCBjYW4gYmUgdXNlZCBpbiBhbnlcbiogY29tcG9uZW50LiBUaGUgZ3VhcmQgaXMgcmVtb3ZlZCB3aGVuIHRoZSBjb21wb25lbnQgaXMgdW5tb3VudGVkLlxuKlxuKiBAcGFyYW0gdXBkYXRlR3VhcmQgLSB7QGxpbmsgTmF2aWdhdGlvbkd1YXJkfVxuKi9cbmZ1bmN0aW9uIG9uQmVmb3JlUm91dGVVcGRhdGUodXBkYXRlR3VhcmQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhZ2V0Q3VycmVudEluc3RhbmNlKCkpIHtcblx0XHR3YXJuJDEoXCJnZXRDdXJyZW50SW5zdGFuY2UoKSByZXR1cm5lZCBudWxsLiBvbkJlZm9yZVJvdXRlVXBkYXRlKCkgbXVzdCBiZSBjYWxsZWQgYXQgdGhlIHRvcCBvZiBhIHNldHVwIGZ1bmN0aW9uXCIpO1xuXHRcdHJldHVybjtcblx0fVxuXHRjb25zdCBhY3RpdmVSZWNvcmQgPSBpbmplY3QobWF0Y2hlZFJvdXRlS2V5LCB7fSkudmFsdWU7XG5cdGlmICghYWN0aXZlUmVjb3JkKSB7XG5cdFx0cHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHdhcm4kMShcIk5vIGFjdGl2ZSByb3V0ZSByZWNvcmQgd2FzIGZvdW5kIHdoZW4gY2FsbGluZyBgb25CZWZvcmVSb3V0ZVVwZGF0ZSgpYC4gTWFrZSBzdXJlIHlvdSBjYWxsIHRoaXMgZnVuY3Rpb24gaW5zaWRlIGEgY29tcG9uZW50IGNoaWxkIG9mIDxyb3V0ZXItdmlldz4uIE1heWJlIHlvdSBjYWxsZWQgaXQgaW5zaWRlIG9mIEFwcC52dWU/XCIpO1xuXHRcdHJldHVybjtcblx0fVxuXHRyZWdpc3Rlckd1YXJkKGFjdGl2ZVJlY29yZCwgXCJ1cGRhdGVHdWFyZHNcIiwgdXBkYXRlR3VhcmQpO1xufVxuZnVuY3Rpb24gZ3VhcmRUb1Byb21pc2VGbihndWFyZCwgdG8sIGZyb20sIHJlY29yZCwgbmFtZSwgcnVuV2l0aENvbnRleHQgPSAoZm4pID0+IGZuKCkpIHtcblx0Y29uc3QgZW50ZXJDYWxsYmFja0FycmF5ID0gcmVjb3JkICYmIChyZWNvcmQuZW50ZXJDYWxsYmFja3NbbmFtZV0gPSByZWNvcmQuZW50ZXJDYWxsYmFja3NbbmFtZV0gfHwgW10pO1xuXHRyZXR1cm4gKCkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IG5leHQgPSAodmFsaWQpID0+IHtcblx0XHRcdGlmICh2YWxpZCA9PT0gZmFsc2UpIHJlamVjdChjcmVhdGVSb3V0ZXJFcnJvcihFcnJvclR5cGVzLk5BVklHQVRJT05fQUJPUlRFRCwge1xuXHRcdFx0XHRmcm9tLFxuXHRcdFx0XHR0b1xuXHRcdFx0fSkpO1xuXHRcdFx0ZWxzZSBpZiAodmFsaWQgaW5zdGFuY2VvZiBFcnJvcikgcmVqZWN0KHZhbGlkKTtcblx0XHRcdGVsc2UgaWYgKGlzUm91dGVMb2NhdGlvbih2YWxpZCkpIHJlamVjdChjcmVhdGVSb3V0ZXJFcnJvcihFcnJvclR5cGVzLk5BVklHQVRJT05fR1VBUkRfUkVESVJFQ1QsIHtcblx0XHRcdFx0ZnJvbTogdG8sXG5cdFx0XHRcdHRvOiB2YWxpZFxuXHRcdFx0fSkpO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGlmIChlbnRlckNhbGxiYWNrQXJyYXkgJiYgcmVjb3JkLmVudGVyQ2FsbGJhY2tzW25hbWVdID09PSBlbnRlckNhbGxiYWNrQXJyYXkgJiYgdHlwZW9mIHZhbGlkID09PSBcImZ1bmN0aW9uXCIpIGVudGVyQ2FsbGJhY2tBcnJheS5wdXNoKHZhbGlkKTtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0Y29uc3QgZ3VhcmRSZXR1cm4gPSBydW5XaXRoQ29udGV4dCgoKSA9PiBndWFyZC5jYWxsKHJlY29yZCAmJiByZWNvcmQuaW5zdGFuY2VzW25hbWVdLCB0bywgZnJvbSwgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gY2FuT25seUJlQ2FsbGVkT25jZShuZXh0LCB0bywgZnJvbSkgOiBuZXh0KSk7XG5cdFx0bGV0IGd1YXJkQ2FsbCA9IFByb21pc2UucmVzb2x2ZShndWFyZFJldHVybik7XG5cdFx0aWYgKGd1YXJkLmxlbmd0aCA8IDMpIGd1YXJkQ2FsbCA9IGd1YXJkQ2FsbC50aGVuKG5leHQpO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgZ3VhcmQubGVuZ3RoID4gMikge1xuXHRcdFx0Y29uc3QgbWVzc2FnZSA9IGBUaGUgXCJuZXh0XCIgY2FsbGJhY2sgd2FzIG5ldmVyIGNhbGxlZCBpbnNpZGUgb2YgJHtndWFyZC5uYW1lID8gXCJcXFwiXCIgKyBndWFyZC5uYW1lICsgXCJcXFwiXCIgOiBcIlwifTpcXG4ke2d1YXJkLnRvU3RyaW5nKCl9XFxuLiBJZiB5b3UgYXJlIHJldHVybmluZyBhIHZhbHVlIGluc3RlYWQgb2YgY2FsbGluZyBcIm5leHRcIiwgbWFrZSBzdXJlIHRvIHJlbW92ZSB0aGUgXCJuZXh0XCIgcGFyYW1ldGVyIGZyb20geW91ciBmdW5jdGlvbi5gO1xuXHRcdFx0aWYgKHR5cGVvZiBndWFyZFJldHVybiA9PT0gXCJvYmplY3RcIiAmJiBcInRoZW5cIiBpbiBndWFyZFJldHVybikgZ3VhcmRDYWxsID0gZ3VhcmRDYWxsLnRoZW4oKHJlc29sdmVkVmFsdWUpID0+IHtcblx0XHRcdFx0aWYgKCFuZXh0Ll9jYWxsZWQpIHtcblx0XHRcdFx0XHR3YXJuJDEobWVzc2FnZSk7XG5cdFx0XHRcdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJJbnZhbGlkIG5hdmlnYXRpb24gZ3VhcmRcIikpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiByZXNvbHZlZFZhbHVlO1xuXHRcdFx0fSk7XG5cdFx0XHRlbHNlIGlmIChndWFyZFJldHVybiAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdGlmICghbmV4dC5fY2FsbGVkKSB7XG5cdFx0XHRcdFx0d2FybiQxKG1lc3NhZ2UpO1xuXHRcdFx0XHRcdHJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwiSW52YWxpZCBuYXZpZ2F0aW9uIGd1YXJkXCIpKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdFx0Z3VhcmRDYWxsLmNhdGNoKChlcnIpID0+IHJlamVjdChlcnIpKTtcblx0fSk7XG59XG5mdW5jdGlvbiBjYW5Pbmx5QmVDYWxsZWRPbmNlKG5leHQsIHRvLCBmcm9tKSB7XG5cdGxldCBjYWxsZWQgPSAwO1xuXHRyZXR1cm4gZnVuY3Rpb24oKSB7XG5cdFx0aWYgKGNhbGxlZCsrID09PSAxKSB3YXJuJDEoYFRoZSBcIm5leHRcIiBjYWxsYmFjayB3YXMgY2FsbGVkIG1vcmUgdGhhbiBvbmNlIGluIG9uZSBuYXZpZ2F0aW9uIGd1YXJkIHdoZW4gZ29pbmcgZnJvbSBcIiR7ZnJvbS5mdWxsUGF0aH1cIiB0byBcIiR7dG8uZnVsbFBhdGh9XCIuIEl0IHNob3VsZCBiZSBjYWxsZWQgZXhhY3RseSBvbmUgdGltZSBpbiBlYWNoIG5hdmlnYXRpb24gZ3VhcmQuIFRoaXMgd2lsbCBmYWlsIGluIHByb2R1Y3Rpb24uYCk7XG5cdFx0bmV4dC5fY2FsbGVkID0gdHJ1ZTtcblx0XHRpZiAoY2FsbGVkID09PSAxKSBuZXh0LmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG5cdH07XG59XG5mdW5jdGlvbiBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyhtYXRjaGVkLCBndWFyZFR5cGUsIHRvLCBmcm9tLCBydW5XaXRoQ29udGV4dCA9IChmbikgPT4gZm4oKSkge1xuXHRjb25zdCBndWFyZHMgPSBbXTtcblx0Zm9yIChjb25zdCByZWNvcmQgb2YgbWF0Y2hlZCkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIXJlY29yZC5jb21wb25lbnRzICYmIHJlY29yZC5jaGlsZHJlbiAmJiAhcmVjb3JkLmNoaWxkcmVuLmxlbmd0aCkgd2FybiQxKGBSZWNvcmQgd2l0aCBwYXRoIFwiJHtyZWNvcmQucGF0aH1cIiBpcyBlaXRoZXIgbWlzc2luZyBhIFwiY29tcG9uZW50KHMpXCIgb3IgXCJjaGlsZHJlblwiIHByb3BlcnR5LmApO1xuXHRcdGZvciAoY29uc3QgbmFtZSBpbiByZWNvcmQuY29tcG9uZW50cykge1xuXHRcdFx0bGV0IHJhd0NvbXBvbmVudCA9IHJlY29yZC5jb21wb25lbnRzW25hbWVdO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAoIXJhd0NvbXBvbmVudCB8fCB0eXBlb2YgcmF3Q29tcG9uZW50ICE9PSBcIm9iamVjdFwiICYmIHR5cGVvZiByYXdDb21wb25lbnQgIT09IFwiZnVuY3Rpb25cIikge1xuXHRcdFx0XHRcdHdhcm4kMShgQ29tcG9uZW50IFwiJHtuYW1lfVwiIGluIHJlY29yZCB3aXRoIHBhdGggXCIke3JlY29yZC5wYXRofVwiIGlzIG5vdCBhIHZhbGlkIGNvbXBvbmVudC4gUmVjZWl2ZWQgXCIke1N0cmluZyhyYXdDb21wb25lbnQpfVwiLmApO1xuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcm91dGUgY29tcG9uZW50XCIpO1xuXHRcdFx0XHR9IGVsc2UgaWYgKFwidGhlblwiIGluIHJhd0NvbXBvbmVudCkge1xuXHRcdFx0XHRcdHdhcm4kMShgQ29tcG9uZW50IFwiJHtuYW1lfVwiIGluIHJlY29yZCB3aXRoIHBhdGggXCIke3JlY29yZC5wYXRofVwiIGlzIGEgUHJvbWlzZSBpbnN0ZWFkIG9mIGEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZS4gRGlkIHlvdSB3cml0ZSBcImltcG9ydCgnLi9NeVBhZ2UudnVlJylcIiBpbnN0ZWFkIG9mIFwiKCkgPT4gaW1wb3J0KCcuL015UGFnZS52dWUnKVwiID8gVGhpcyB3aWxsIGJyZWFrIGluIHByb2R1Y3Rpb24gaWYgbm90IGZpeGVkLmApO1xuXHRcdFx0XHRcdGNvbnN0IHByb21pc2UgPSByYXdDb21wb25lbnQ7XG5cdFx0XHRcdFx0cmF3Q29tcG9uZW50ID0gKCkgPT4gcHJvbWlzZTtcblx0XHRcdFx0fSBlbHNlIGlmIChyYXdDb21wb25lbnQuX19hc3luY0xvYWRlciAmJiAhcmF3Q29tcG9uZW50Ll9fd2FybmVkRGVmaW5lQXN5bmMpIHtcblx0XHRcdFx0XHRyYXdDb21wb25lbnQuX193YXJuZWREZWZpbmVBc3luYyA9IHRydWU7XG5cdFx0XHRcdFx0d2FybiQxKGBDb21wb25lbnQgXCIke25hbWV9XCIgaW4gcmVjb3JkIHdpdGggcGF0aCBcIiR7cmVjb3JkLnBhdGh9XCIgaXMgZGVmaW5lZCB1c2luZyBcImRlZmluZUFzeW5jQ29tcG9uZW50KClcIi4gV3JpdGUgXCIoKSA9PiBpbXBvcnQoJy4vTXlQYWdlLnZ1ZScpXCIgaW5zdGVhZCBvZiBcImRlZmluZUFzeW5jQ29tcG9uZW50KCgpID0+IGltcG9ydCgnLi9NeVBhZ2UudnVlJykpXCIuYCk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChndWFyZFR5cGUgIT09IFwiYmVmb3JlUm91dGVFbnRlclwiICYmICFyZWNvcmQuaW5zdGFuY2VzW25hbWVdKSBjb250aW51ZTtcblx0XHRcdGlmIChpc1JvdXRlQ29tcG9uZW50KHJhd0NvbXBvbmVudCkpIHtcblx0XHRcdFx0Y29uc3QgZ3VhcmQgPSAocmF3Q29tcG9uZW50Ll9fdmNjT3B0cyB8fCByYXdDb21wb25lbnQpW2d1YXJkVHlwZV07XG5cdFx0XHRcdGd1YXJkICYmIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tLCByZWNvcmQsIG5hbWUsIHJ1bldpdGhDb250ZXh0KSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsZXQgY29tcG9uZW50UHJvbWlzZSA9IHJhd0NvbXBvbmVudCgpO1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICEoXCJjYXRjaFwiIGluIGNvbXBvbmVudFByb21pc2UpKSB7XG5cdFx0XHRcdFx0d2FybiQxKGBDb21wb25lbnQgXCIke25hbWV9XCIgaW4gcmVjb3JkIHdpdGggcGF0aCBcIiR7cmVjb3JkLnBhdGh9XCIgaXMgYSBmdW5jdGlvbiB0aGF0IGRvZXMgbm90IHJldHVybiBhIFByb21pc2UuIElmIHlvdSB3ZXJlIHBhc3NpbmcgYSBmdW5jdGlvbmFsIGNvbXBvbmVudCwgbWFrZSBzdXJlIHRvIGFkZCBhIFwiZGlzcGxheU5hbWVcIiB0byB0aGUgY29tcG9uZW50LiBUaGlzIHdpbGwgYnJlYWsgaW4gcHJvZHVjdGlvbiBpZiBub3QgZml4ZWQuYCk7XG5cdFx0XHRcdFx0Y29tcG9uZW50UHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZShjb21wb25lbnRQcm9taXNlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRndWFyZHMucHVzaCgoKSA9PiBjb21wb25lbnRQcm9taXNlLnRoZW4oKHJlc29sdmVkKSA9PiB7XG5cdFx0XHRcdFx0aWYgKCFyZXNvbHZlZCkgdGhyb3cgbmV3IEVycm9yKGBDb3VsZG4ndCByZXNvbHZlIGNvbXBvbmVudCBcIiR7bmFtZX1cIiBhdCBcIiR7cmVjb3JkLnBhdGh9XCJgKTtcblx0XHRcdFx0XHRjb25zdCByZXNvbHZlZENvbXBvbmVudCA9IGlzRVNNb2R1bGUocmVzb2x2ZWQpID8gcmVzb2x2ZWQuZGVmYXVsdCA6IHJlc29sdmVkO1xuXHRcdFx0XHRcdHJlY29yZC5tb2RzW25hbWVdID0gcmVzb2x2ZWQ7XG5cdFx0XHRcdFx0cmVjb3JkLmNvbXBvbmVudHNbbmFtZV0gPSByZXNvbHZlZENvbXBvbmVudDtcblx0XHRcdFx0XHRjb25zdCBndWFyZCA9IChyZXNvbHZlZENvbXBvbmVudC5fX3ZjY09wdHMgfHwgcmVzb2x2ZWRDb21wb25lbnQpW2d1YXJkVHlwZV07XG5cdFx0XHRcdFx0cmV0dXJuIGd1YXJkICYmIGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tLCByZWNvcmQsIG5hbWUsIHJ1bldpdGhDb250ZXh0KSgpO1xuXHRcdFx0XHR9KSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdHJldHVybiBndWFyZHM7XG59XG4vKipcbiogRW5zdXJlcyBhIHJvdXRlIGlzIGxvYWRlZCwgc28gaXQgY2FuIGJlIHBhc3NlZCBhcyBvIHByb3AgdG8gYDxSb3V0ZXJWaWV3PmAuXG4qXG4qIEBwYXJhbSByb3V0ZSAtIHJlc29sdmVkIHJvdXRlIHRvIGxvYWRcbiovXG5mdW5jdGlvbiBsb2FkUm91dGVMb2NhdGlvbihyb3V0ZSkge1xuXHRyZXR1cm4gcm91dGUubWF0Y2hlZC5ldmVyeSgocmVjb3JkKSA9PiByZWNvcmQucmVkaXJlY3QpID8gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkNhbm5vdCBsb2FkIGEgcm91dGUgdGhhdCByZWRpcmVjdHMuXCIpKSA6IFByb21pc2UuYWxsKHJvdXRlLm1hdGNoZWQubWFwKChyZWNvcmQpID0+IHJlY29yZC5jb21wb25lbnRzICYmIFByb21pc2UuYWxsKE9iamVjdC5rZXlzKHJlY29yZC5jb21wb25lbnRzKS5yZWR1Y2UoKHByb21pc2VzLCBuYW1lKSA9PiB7XG5cdFx0Y29uc3QgcmF3Q29tcG9uZW50ID0gcmVjb3JkLmNvbXBvbmVudHNbbmFtZV07XG5cdFx0aWYgKHR5cGVvZiByYXdDb21wb25lbnQgPT09IFwiZnVuY3Rpb25cIiAmJiAhKFwiZGlzcGxheU5hbWVcIiBpbiByYXdDb21wb25lbnQpKSBwcm9taXNlcy5wdXNoKHJhd0NvbXBvbmVudCgpLnRoZW4oKHJlc29sdmVkKSA9PiB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihgQ291bGRuJ3QgcmVzb2x2ZSBjb21wb25lbnQgXCIke25hbWV9XCIgYXQgXCIke3JlY29yZC5wYXRofVwiLiBFbnN1cmUgeW91IHBhc3NlZCBhIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIHByb21pc2UuYCkpO1xuXHRcdFx0Y29uc3QgcmVzb2x2ZWRDb21wb25lbnQgPSBpc0VTTW9kdWxlKHJlc29sdmVkKSA/IHJlc29sdmVkLmRlZmF1bHQgOiByZXNvbHZlZDtcblx0XHRcdHJlY29yZC5tb2RzW25hbWVdID0gcmVzb2x2ZWQ7XG5cdFx0XHRyZWNvcmQuY29tcG9uZW50c1tuYW1lXSA9IHJlc29sdmVkQ29tcG9uZW50O1xuXHRcdH0pKTtcblx0XHRyZXR1cm4gcHJvbWlzZXM7XG5cdH0sIFtdKSkpKS50aGVuKCgpID0+IHJvdXRlKTtcbn1cbi8qKlxuKiBTcGxpdCB0aGUgbGVhdmluZywgdXBkYXRpbmcsIGFuZCBlbnRlcmluZyByZWNvcmRzLlxuKiBAaW50ZXJuYWxcbipcbiogQHBhcmFtICB0byAtIExvY2F0aW9uIHdlIGFyZSBuYXZpZ2F0aW5nIHRvXG4qIEBwYXJhbSBmcm9tIC0gTG9jYXRpb24gd2UgYXJlIG5hdmlnYXRpbmcgZnJvbVxuKi9cbmZ1bmN0aW9uIGV4dHJhY3RDaGFuZ2luZ1JlY29yZHModG8sIGZyb20pIHtcblx0Y29uc3QgbGVhdmluZ1JlY29yZHMgPSBbXTtcblx0Y29uc3QgdXBkYXRpbmdSZWNvcmRzID0gW107XG5cdGNvbnN0IGVudGVyaW5nUmVjb3JkcyA9IFtdO1xuXHRjb25zdCBsZW4gPSBNYXRoLm1heChmcm9tLm1hdGNoZWQubGVuZ3RoLCB0by5tYXRjaGVkLmxlbmd0aCk7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcblx0XHRjb25zdCByZWNvcmRGcm9tID0gZnJvbS5tYXRjaGVkW2ldO1xuXHRcdGlmIChyZWNvcmRGcm9tKSBpZiAodG8ubWF0Y2hlZC5maW5kKChyZWNvcmQpID0+IGlzU2FtZVJvdXRlUmVjb3JkKHJlY29yZCwgcmVjb3JkRnJvbSkpKSB1cGRhdGluZ1JlY29yZHMucHVzaChyZWNvcmRGcm9tKTtcblx0XHRlbHNlIGxlYXZpbmdSZWNvcmRzLnB1c2gocmVjb3JkRnJvbSk7XG5cdFx0Y29uc3QgcmVjb3JkVG8gPSB0by5tYXRjaGVkW2ldO1xuXHRcdGlmIChyZWNvcmRUbykge1xuXHRcdFx0aWYgKCFmcm9tLm1hdGNoZWQuZmluZCgocmVjb3JkKSA9PiBpc1NhbWVSb3V0ZVJlY29yZChyZWNvcmQsIHJlY29yZFRvKSkpIGVudGVyaW5nUmVjb3Jkcy5wdXNoKHJlY29yZFRvKTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIFtcblx0XHRsZWF2aW5nUmVjb3Jkcyxcblx0XHR1cGRhdGluZ1JlY29yZHMsXG5cdFx0ZW50ZXJpbmdSZWNvcmRzXG5cdF07XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9kZXZ0b29scy50c1xuLyoqXG4qIENvcGllcyBhIHJvdXRlIGxvY2F0aW9uIGFuZCByZW1vdmVzIGFueSBwcm9ibGVtYXRpYyBwcm9wZXJ0aWVzIHRoYXQgY2Fubm90IGJlIHNob3duIGluIGRldnRvb2xzIChlLmcuIFZ1ZSBpbnN0YW5jZXMpLlxuKlxuKiBAcGFyYW0gcm91dGVMb2NhdGlvbiAtIHJvdXRlTG9jYXRpb24gdG8gZm9ybWF0XG4qIEBwYXJhbSB0b29sdGlwIC0gb3B0aW9uYWwgdG9vbHRpcFxuKiBAcmV0dXJucyBhIGNvcHkgb2YgdGhlIHJvdXRlTG9jYXRpb25cbiovXG5mdW5jdGlvbiBmb3JtYXRSb3V0ZUxvY2F0aW9uKHJvdXRlTG9jYXRpb24sIHRvb2x0aXApIHtcblx0Y29uc3QgY29weSA9IGFzc2lnbih7fSwgcm91dGVMb2NhdGlvbiwgeyBtYXRjaGVkOiByb3V0ZUxvY2F0aW9uLm1hdGNoZWQubWFwKChtYXRjaGVkKSA9PiBvbWl0KG1hdGNoZWQsIFtcblx0XHRcImluc3RhbmNlc1wiLFxuXHRcdFwiY2hpbGRyZW5cIixcblx0XHRcImFsaWFzT2ZcIlxuXHRdKSkgfSk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBudWxsLFxuXHRcdHJlYWRPbmx5OiB0cnVlLFxuXHRcdGRpc3BsYXk6IHJvdXRlTG9jYXRpb24uZnVsbFBhdGgsXG5cdFx0dG9vbHRpcCxcblx0XHR2YWx1ZTogY29weVxuXHR9IH07XG59XG5mdW5jdGlvbiBmb3JtYXREaXNwbGF5KGRpc3BsYXkpIHtcblx0cmV0dXJuIHsgX2N1c3RvbTogeyBkaXNwbGF5IH0gfTtcbn1cbmxldCByb3V0ZXJJZCA9IDA7XG5mdW5jdGlvbiBhZGREZXZ0b29scyhhcHAsIHJvdXRlciwgbWF0Y2hlcikge1xuXHRpZiAocm91dGVyLl9faGFzRGV2dG9vbHMpIHJldHVybjtcblx0cm91dGVyLl9faGFzRGV2dG9vbHMgPSB0cnVlO1xuXHRjb25zdCBpZCA9IHJvdXRlcklkKys7XG5cdHNldHVwRGV2dG9vbHNQbHVnaW4oe1xuXHRcdGlkOiBcIm9yZy52dWVqcy5yb3V0ZXJcIiArIChpZCA/IFwiLlwiICsgaWQgOiBcIlwiKSxcblx0XHRsYWJlbDogXCJWdWUgUm91dGVyXCIsXG5cdFx0cGFja2FnZU5hbWU6IFwidnVlLXJvdXRlclwiLFxuXHRcdGhvbWVwYWdlOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZ1wiLFxuXHRcdGxvZ286IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2xvZ28ucG5nXCIsXG5cdFx0Y29tcG9uZW50U3RhdGVUeXBlczogW1wiUm91dGluZ1wiXSxcblx0XHRhcHBcblx0fSwgKGFwaSkgPT4ge1xuXHRcdGlmICh0eXBlb2YgYXBpLm5vdyAhPT0gXCJmdW5jdGlvblwiKSB3YXJuJDEoXCJbVnVlIFJvdXRlcl06IFlvdSBzZWVtIHRvIGJlIHVzaW5nIGFuIG91dGRhdGVkIHZlcnNpb24gb2YgVnVlIERldnRvb2xzLiBBcmUgeW91IHN0aWxsIHVzaW5nIHRoZSBCZXRhIHJlbGVhc2UgaW5zdGVhZCBvZiB0aGUgc3RhYmxlIG9uZT8gWW91IGNhbiBmaW5kIHRoZSBsaW5rcyBhdCBodHRwczovL2RldnRvb2xzLnZ1ZWpzLm9yZy9ndWlkZS9pbnN0YWxsYXRpb24uaHRtbC5cIik7XG5cdFx0YXBpLm9uLmluc3BlY3RDb21wb25lbnQoKHBheWxvYWQsIGN0eCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuaW5zdGFuY2VEYXRhKSBwYXlsb2FkLmluc3RhbmNlRGF0YS5zdGF0ZS5wdXNoKHtcblx0XHRcdFx0dHlwZTogXCJSb3V0aW5nXCIsXG5cdFx0XHRcdGtleTogXCIkcm91dGVcIixcblx0XHRcdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdFx0XHR2YWx1ZTogZm9ybWF0Um91dGVMb2NhdGlvbihyb3V0ZXIuY3VycmVudFJvdXRlLnZhbHVlLCBcIkN1cnJlbnQgUm91dGVcIilcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdGFwaS5vbi52aXNpdENvbXBvbmVudFRyZWUoKHsgdHJlZU5vZGU6IG5vZGUsIGNvbXBvbmVudEluc3RhbmNlIH0pID0+IHtcblx0XHRcdGlmIChjb21wb25lbnRJbnN0YW5jZS5fX3Zydl9kZXZ0b29scykge1xuXHRcdFx0XHRjb25zdCBpbmZvID0gY29tcG9uZW50SW5zdGFuY2UuX192cnZfZGV2dG9vbHM7XG5cdFx0XHRcdG5vZGUudGFncy5wdXNoKHtcblx0XHRcdFx0XHRsYWJlbDogKGluZm8ubmFtZSA/IGAke2luZm8ubmFtZS50b1N0cmluZygpfTogYCA6IFwiXCIpICsgaW5mby5wYXRoLFxuXHRcdFx0XHRcdHRleHRDb2xvcjogMCxcblx0XHRcdFx0XHR0b29sdGlwOiBcIlRoaXMgY29tcG9uZW50IGlzIHJlbmRlcmVkIGJ5ICZsdDtyb3V0ZXItdmlldyZndDtcIixcblx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3I6IFBJTktfNTAwXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGlzQXJyYXkoY29tcG9uZW50SW5zdGFuY2UuX192cmxfZGV2dG9vbHMpKSB7XG5cdFx0XHRcdGNvbXBvbmVudEluc3RhbmNlLl9fZGV2dG9vbHNBcGkgPSBhcGk7XG5cdFx0XHRcdGNvbXBvbmVudEluc3RhbmNlLl9fdnJsX2RldnRvb2xzLmZvckVhY2goKGRldnRvb2xzRGF0YSkgPT4ge1xuXHRcdFx0XHRcdGxldCBsYWJlbCA9IGRldnRvb2xzRGF0YS5yb3V0ZS5wYXRoO1xuXHRcdFx0XHRcdGxldCBiYWNrZ3JvdW5kQ29sb3IgPSBPUkFOR0VfNDAwO1xuXHRcdFx0XHRcdGxldCB0b29sdGlwID0gXCJcIjtcblx0XHRcdFx0XHRsZXQgdGV4dENvbG9yID0gMDtcblx0XHRcdFx0XHRpZiAoZGV2dG9vbHNEYXRhLmVycm9yKSB7XG5cdFx0XHRcdFx0XHRsYWJlbCA9IGRldnRvb2xzRGF0YS5lcnJvcjtcblx0XHRcdFx0XHRcdGJhY2tncm91bmRDb2xvciA9IFJFRF8xMDA7XG5cdFx0XHRcdFx0XHR0ZXh0Q29sb3IgPSBSRURfNzAwO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAoZGV2dG9vbHNEYXRhLmlzRXhhY3RBY3RpdmUpIHtcblx0XHRcdFx0XHRcdGJhY2tncm91bmRDb2xvciA9IExJTUVfNTAwO1xuXHRcdFx0XHRcdFx0dG9vbHRpcCA9IFwiVGhpcyBpcyBleGFjdGx5IGFjdGl2ZVwiO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAoZGV2dG9vbHNEYXRhLmlzQWN0aXZlKSB7XG5cdFx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3IgPSBCTFVFXzYwMDtcblx0XHRcdFx0XHRcdHRvb2x0aXAgPSBcIlRoaXMgbGluayBpcyBhY3RpdmVcIjtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0bm9kZS50YWdzLnB1c2goe1xuXHRcdFx0XHRcdFx0bGFiZWwsXG5cdFx0XHRcdFx0XHR0ZXh0Q29sb3IsXG5cdFx0XHRcdFx0XHR0b29sdGlwLFxuXHRcdFx0XHRcdFx0YmFja2dyb3VuZENvbG9yXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHdhdGNoKHJvdXRlci5jdXJyZW50Um91dGUsICgpID0+IHtcblx0XHRcdHJlZnJlc2hSb3V0ZXNWaWV3KCk7XG5cdFx0XHRhcGkubm90aWZ5Q29tcG9uZW50VXBkYXRlKCk7XG5cdFx0XHRhcGkuc2VuZEluc3BlY3RvclRyZWUocm91dGVySW5zcGVjdG9ySWQpO1xuXHRcdFx0YXBpLnNlbmRJbnNwZWN0b3JTdGF0ZShyb3V0ZXJJbnNwZWN0b3JJZCk7XG5cdFx0fSk7XG5cdFx0Y29uc3QgbmF2aWdhdGlvbnNMYXllcklkID0gXCJyb3V0ZXI6bmF2aWdhdGlvbnM6XCIgKyBpZDtcblx0XHRhcGkuYWRkVGltZWxpbmVMYXllcih7XG5cdFx0XHRpZDogbmF2aWdhdGlvbnNMYXllcklkLFxuXHRcdFx0bGFiZWw6IGBSb3V0ZXIke2lkID8gXCIgXCIgKyBpZCA6IFwiXCJ9IE5hdmlnYXRpb25zYCxcblx0XHRcdGNvbG9yOiA0MjM3NTA4XG5cdFx0fSk7XG5cdFx0cm91dGVyLm9uRXJyb3IoKGVycm9yLCB0bykgPT4ge1xuXHRcdFx0YXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdFx0XHRsYXllcklkOiBuYXZpZ2F0aW9uc0xheWVySWQsXG5cdFx0XHRcdGV2ZW50OiB7XG5cdFx0XHRcdFx0dGl0bGU6IFwiRXJyb3IgZHVyaW5nIE5hdmlnYXRpb25cIixcblx0XHRcdFx0XHRzdWJ0aXRsZTogdG8uZnVsbFBhdGgsXG5cdFx0XHRcdFx0bG9nVHlwZTogXCJlcnJvclwiLFxuXHRcdFx0XHRcdHRpbWU6IGFwaS5ub3coKSxcblx0XHRcdFx0XHRkYXRhOiB7IGVycm9yIH0sXG5cdFx0XHRcdFx0Z3JvdXBJZDogdG8ubWV0YS5fX25hdmlnYXRpb25JZFxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRsZXQgbmF2aWdhdGlvbklkID0gMDtcblx0XHRyb3V0ZXIuYmVmb3JlRWFjaCgodG8sIGZyb20pID0+IHtcblx0XHRcdGNvbnN0IGRhdGEgPSB7XG5cdFx0XHRcdGd1YXJkOiBmb3JtYXREaXNwbGF5KFwiYmVmb3JlRWFjaFwiKSxcblx0XHRcdFx0ZnJvbTogZm9ybWF0Um91dGVMb2NhdGlvbihmcm9tLCBcIkN1cnJlbnQgTG9jYXRpb24gZHVyaW5nIHRoaXMgbmF2aWdhdGlvblwiKSxcblx0XHRcdFx0dG86IGZvcm1hdFJvdXRlTG9jYXRpb24odG8sIFwiVGFyZ2V0IGxvY2F0aW9uXCIpXG5cdFx0XHR9O1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHRvLm1ldGEsIFwiX19uYXZpZ2F0aW9uSWRcIiwgeyB2YWx1ZTogbmF2aWdhdGlvbklkKysgfSk7XG5cdFx0XHRhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IG5hdmlnYXRpb25zTGF5ZXJJZCxcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aW1lOiBhcGkubm93KCksXG5cdFx0XHRcdFx0dGl0bGU6IFwiU3RhcnQgb2YgbmF2aWdhdGlvblwiLFxuXHRcdFx0XHRcdHN1YnRpdGxlOiB0by5mdWxsUGF0aCxcblx0XHRcdFx0XHRkYXRhLFxuXHRcdFx0XHRcdGdyb3VwSWQ6IHRvLm1ldGEuX19uYXZpZ2F0aW9uSWRcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0cm91dGVyLmFmdGVyRWFjaCgodG8sIGZyb20sIGZhaWx1cmUpID0+IHtcblx0XHRcdGNvbnN0IGRhdGEgPSB7IGd1YXJkOiBmb3JtYXREaXNwbGF5KFwiYWZ0ZXJFYWNoXCIpIH07XG5cdFx0XHRpZiAoZmFpbHVyZSkge1xuXHRcdFx0XHRkYXRhLmZhaWx1cmUgPSB7IF9jdXN0b206IHtcblx0XHRcdFx0XHR0eXBlOiBFcnJvcixcblx0XHRcdFx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRcdFx0XHRkaXNwbGF5OiBmYWlsdXJlID8gZmFpbHVyZS5tZXNzYWdlIDogXCJcIixcblx0XHRcdFx0XHR0b29sdGlwOiBcIk5hdmlnYXRpb24gRmFpbHVyZVwiLFxuXHRcdFx0XHRcdHZhbHVlOiBmYWlsdXJlXG5cdFx0XHRcdH0gfTtcblx0XHRcdFx0ZGF0YS5zdGF0dXMgPSBmb3JtYXREaXNwbGF5KFwi4p2MXCIpO1xuXHRcdFx0fSBlbHNlIGRhdGEuc3RhdHVzID0gZm9ybWF0RGlzcGxheShcIuKchVwiKTtcblx0XHRcdGRhdGEuZnJvbSA9IGZvcm1hdFJvdXRlTG9jYXRpb24oZnJvbSwgXCJDdXJyZW50IExvY2F0aW9uIGR1cmluZyB0aGlzIG5hdmlnYXRpb25cIik7XG5cdFx0XHRkYXRhLnRvID0gZm9ybWF0Um91dGVMb2NhdGlvbih0bywgXCJUYXJnZXQgbG9jYXRpb25cIik7XG5cdFx0XHRhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IG5hdmlnYXRpb25zTGF5ZXJJZCxcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aXRsZTogXCJFbmQgb2YgbmF2aWdhdGlvblwiLFxuXHRcdFx0XHRcdHN1YnRpdGxlOiB0by5mdWxsUGF0aCxcblx0XHRcdFx0XHR0aW1lOiBhcGkubm93KCksXG5cdFx0XHRcdFx0ZGF0YSxcblx0XHRcdFx0XHRsb2dUeXBlOiBmYWlsdXJlID8gXCJ3YXJuaW5nXCIgOiBcImRlZmF1bHRcIixcblx0XHRcdFx0XHRncm91cElkOiB0by5tZXRhLl9fbmF2aWdhdGlvbklkXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdC8qKlxuXHRcdCogSW5zcGVjdG9yIG9mIEV4aXN0aW5nIHJvdXRlc1xuXHRcdCovXG5cdFx0Y29uc3Qgcm91dGVySW5zcGVjdG9ySWQgPSBcInJvdXRlci1pbnNwZWN0b3I6XCIgKyBpZDtcblx0XHRhcGkuYWRkSW5zcGVjdG9yKHtcblx0XHRcdGlkOiByb3V0ZXJJbnNwZWN0b3JJZCxcblx0XHRcdGxhYmVsOiBcIlJvdXRlc1wiICsgKGlkID8gXCIgXCIgKyBpZCA6IFwiXCIpLFxuXHRcdFx0aWNvbjogXCJib29rXCIsXG5cdFx0XHR0cmVlRmlsdGVyUGxhY2Vob2xkZXI6IFwiU2VhcmNoIHJvdXRlc1wiXG5cdFx0fSk7XG5cdFx0ZnVuY3Rpb24gcmVmcmVzaFJvdXRlc1ZpZXcoKSB7XG5cdFx0XHRpZiAoIWFjdGl2ZVJvdXRlc1BheWxvYWQpIHJldHVybjtcblx0XHRcdGNvbnN0IHBheWxvYWQgPSBhY3RpdmVSb3V0ZXNQYXlsb2FkO1xuXHRcdFx0bGV0IHJvdXRlcyA9IG1hdGNoZXIuZ2V0Um91dGVzKCkuZmlsdGVyKChyb3V0ZSkgPT4gIXJvdXRlLnBhcmVudCB8fCAhcm91dGUucGFyZW50LnJlY29yZC5jb21wb25lbnRzKTtcblx0XHRcdHJvdXRlcy5mb3JFYWNoKHJlc2V0TWF0Y2hTdGF0ZU9uUm91dGVSZWNvcmQpO1xuXHRcdFx0aWYgKHBheWxvYWQuZmlsdGVyKSByb3V0ZXMgPSByb3V0ZXMuZmlsdGVyKChyb3V0ZSkgPT4gaXNSb3V0ZU1hdGNoaW5nKHJvdXRlLCBwYXlsb2FkLmZpbHRlci50b0xvd2VyQ2FzZSgpKSk7XG5cdFx0XHRyb3V0ZXMuZm9yRWFjaCgocm91dGUpID0+IG1hcmtSb3V0ZVJlY29yZEFjdGl2ZShyb3V0ZSwgcm91dGVyLmN1cnJlbnRSb3V0ZS52YWx1ZSkpO1xuXHRcdFx0cGF5bG9hZC5yb290Tm9kZXMgPSByb3V0ZXMubWFwKGZvcm1hdFJvdXRlUmVjb3JkRm9ySW5zcGVjdG9yKTtcblx0XHR9XG5cdFx0bGV0IGFjdGl2ZVJvdXRlc1BheWxvYWQ7XG5cdFx0YXBpLm9uLmdldEluc3BlY3RvclRyZWUoKHBheWxvYWQpID0+IHtcblx0XHRcdGFjdGl2ZVJvdXRlc1BheWxvYWQgPSBwYXlsb2FkO1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gcm91dGVySW5zcGVjdG9ySWQpIHJlZnJlc2hSb3V0ZXNWaWV3KCk7XG5cdFx0fSk7XG5cdFx0LyoqXG5cdFx0KiBEaXNwbGF5IGluZm9ybWF0aW9uIGFib3V0IHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgcm91dGUgcmVjb3JkXG5cdFx0Ki9cblx0XHRhcGkub24uZ2V0SW5zcGVjdG9yU3RhdGUoKHBheWxvYWQpID0+IHtcblx0XHRcdGlmIChwYXlsb2FkLmFwcCA9PT0gYXBwICYmIHBheWxvYWQuaW5zcGVjdG9ySWQgPT09IHJvdXRlckluc3BlY3RvcklkKSB7XG5cdFx0XHRcdGNvbnN0IHJvdXRlID0gbWF0Y2hlci5nZXRSb3V0ZXMoKS5maW5kKChyb3V0ZSQxKSA9PiByb3V0ZSQxLnJlY29yZC5fX3ZkX2lkID09PSBwYXlsb2FkLm5vZGVJZCk7XG5cdFx0XHRcdGlmIChyb3V0ZSkgcGF5bG9hZC5zdGF0ZSA9IHsgb3B0aW9uczogZm9ybWF0Um91dGVSZWNvcmRNYXRjaGVyRm9yU3RhdGVJbnNwZWN0b3Iocm91dGUpIH07XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0YXBpLnNlbmRJbnNwZWN0b3JUcmVlKHJvdXRlckluc3BlY3RvcklkKTtcblx0XHRhcGkuc2VuZEluc3BlY3RvclN0YXRlKHJvdXRlckluc3BlY3RvcklkKTtcblx0fSk7XG59XG5mdW5jdGlvbiBtb2RpZmllckZvcktleShrZXkpIHtcblx0aWYgKGtleS5vcHRpb25hbCkgcmV0dXJuIGtleS5yZXBlYXRhYmxlID8gXCIqXCIgOiBcIj9cIjtcblx0ZWxzZSByZXR1cm4ga2V5LnJlcGVhdGFibGUgPyBcIitcIiA6IFwiXCI7XG59XG5mdW5jdGlvbiBmb3JtYXRSb3V0ZVJlY29yZE1hdGNoZXJGb3JTdGF0ZUluc3BlY3Rvcihyb3V0ZSkge1xuXHRjb25zdCB7IHJlY29yZCB9ID0gcm91dGU7XG5cdGNvbnN0IGZpZWxkcyA9IFt7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJwYXRoXCIsXG5cdFx0dmFsdWU6IHJlY29yZC5wYXRoXG5cdH1dO1xuXHRpZiAocmVjb3JkLm5hbWUgIT0gbnVsbCkgZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwibmFtZVwiLFxuXHRcdHZhbHVlOiByZWNvcmQubmFtZVxuXHR9KTtcblx0ZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwicmVnZXhwXCIsXG5cdFx0dmFsdWU6IHJvdXRlLnJlXG5cdH0pO1xuXHRpZiAocm91dGUua2V5cy5sZW5ndGgpIGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcImtleXNcIixcblx0XHR2YWx1ZTogeyBfY3VzdG9tOiB7XG5cdFx0XHR0eXBlOiBudWxsLFxuXHRcdFx0cmVhZE9ubHk6IHRydWUsXG5cdFx0XHRkaXNwbGF5OiByb3V0ZS5rZXlzLm1hcCgoa2V5KSA9PiBgJHtrZXkubmFtZX0ke21vZGlmaWVyRm9yS2V5KGtleSl9YCkuam9pbihcIiBcIiksXG5cdFx0XHR0b29sdGlwOiBcIlBhcmFtIGtleXNcIixcblx0XHRcdHZhbHVlOiByb3V0ZS5rZXlzXG5cdFx0fSB9XG5cdH0pO1xuXHRpZiAocmVjb3JkLnJlZGlyZWN0ICE9IG51bGwpIGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcInJlZGlyZWN0XCIsXG5cdFx0dmFsdWU6IHJlY29yZC5yZWRpcmVjdFxuXHR9KTtcblx0aWYgKHJvdXRlLmFsaWFzLmxlbmd0aCkgZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwiYWxpYXNlc1wiLFxuXHRcdHZhbHVlOiByb3V0ZS5hbGlhcy5tYXAoKGFsaWFzKSA9PiBhbGlhcy5yZWNvcmQucGF0aClcblx0fSk7XG5cdGlmIChPYmplY3Qua2V5cyhyb3V0ZS5yZWNvcmQubWV0YSkubGVuZ3RoKSBmaWVsZHMucHVzaCh7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJtZXRhXCIsXG5cdFx0dmFsdWU6IHJvdXRlLnJlY29yZC5tZXRhXG5cdH0pO1xuXHRmaWVsZHMucHVzaCh7XG5cdFx0a2V5OiBcInNjb3JlXCIsXG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdHZhbHVlOiB7IF9jdXN0b206IHtcblx0XHRcdHR5cGU6IG51bGwsXG5cdFx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRcdGRpc3BsYXk6IHJvdXRlLnNjb3JlLm1hcCgoc2NvcmUpID0+IHNjb3JlLmpvaW4oXCIsIFwiKSkuam9pbihcIiB8IFwiKSxcblx0XHRcdHRvb2x0aXA6IFwiU2NvcmUgdXNlZCB0byBzb3J0IHJvdXRlc1wiLFxuXHRcdFx0dmFsdWU6IHJvdXRlLnNjb3JlXG5cdFx0fSB9XG5cdH0pO1xuXHRyZXR1cm4gZmllbGRzO1xufVxuLyoqXG4qIEV4dHJhY3RlZCBmcm9tIHRhaWx3aW5kIHBhbGV0dGVcbiovXG5jb25zdCBQSU5LXzUwMCA9IDE1NDg1MDgxO1xuY29uc3QgQkxVRV82MDAgPSAyNDUwNDExO1xuY29uc3QgTElNRV81MDAgPSA4NzAyOTk4O1xuY29uc3QgQ1lBTl80MDAgPSAyMjgyNDc4O1xuY29uc3QgT1JBTkdFXzQwMCA9IDE2NDg2OTcyO1xuY29uc3QgREFSSyA9IDY3MTA4ODY7XG5jb25zdCBSRURfMTAwID0gMTY3MDQyMjY7XG5jb25zdCBSRURfNzAwID0gMTIxMzEzNTY7XG5mdW5jdGlvbiBmb3JtYXRSb3V0ZVJlY29yZEZvckluc3BlY3Rvcihyb3V0ZSkge1xuXHRjb25zdCB0YWdzID0gW107XG5cdGNvbnN0IHsgcmVjb3JkIH0gPSByb3V0ZTtcblx0aWYgKHJlY29yZC5uYW1lICE9IG51bGwpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IFN0cmluZyhyZWNvcmQubmFtZSksXG5cdFx0dGV4dENvbG9yOiAwLFxuXHRcdGJhY2tncm91bmRDb2xvcjogQ1lBTl80MDBcblx0fSk7XG5cdGlmIChyZWNvcmQuYWxpYXNPZikgdGFncy5wdXNoKHtcblx0XHRsYWJlbDogXCJhbGlhc1wiLFxuXHRcdHRleHRDb2xvcjogMCxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IE9SQU5HRV80MDBcblx0fSk7XG5cdGlmIChyb3V0ZS5fX3ZkX21hdGNoKSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiBcIm1hdGNoZXNcIixcblx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBQSU5LXzUwMFxuXHR9KTtcblx0aWYgKHJvdXRlLl9fdmRfZXhhY3RBY3RpdmUpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IFwiZXhhY3RcIixcblx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBMSU1FXzUwMFxuXHR9KTtcblx0aWYgKHJvdXRlLl9fdmRfYWN0aXZlKSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiBcImFjdGl2ZVwiLFxuXHRcdHRleHRDb2xvcjogMCxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IEJMVUVfNjAwXG5cdH0pO1xuXHRpZiAocmVjb3JkLnJlZGlyZWN0KSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiB0eXBlb2YgcmVjb3JkLnJlZGlyZWN0ID09PSBcInN0cmluZ1wiID8gYHJlZGlyZWN0OiAke3JlY29yZC5yZWRpcmVjdH1gIDogXCJyZWRpcmVjdHNcIixcblx0XHR0ZXh0Q29sb3I6IDE2Nzc3MjE1LFxuXHRcdGJhY2tncm91bmRDb2xvcjogREFSS1xuXHR9KTtcblx0bGV0IGlkID0gcmVjb3JkLl9fdmRfaWQ7XG5cdGlmIChpZCA9PSBudWxsKSB7XG5cdFx0aWQgPSBTdHJpbmcocm91dGVSZWNvcmRJZCsrKTtcblx0XHRyZWNvcmQuX192ZF9pZCA9IGlkO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0aWQsXG5cdFx0bGFiZWw6IHJlY29yZC5wYXRoLFxuXHRcdHRhZ3MsXG5cdFx0Y2hpbGRyZW46IHJvdXRlLmNoaWxkcmVuLm1hcChmb3JtYXRSb3V0ZVJlY29yZEZvckluc3BlY3Rvcilcblx0fTtcbn1cbmxldCByb3V0ZVJlY29yZElkID0gMDtcbmNvbnN0IEVYVFJBQ1RfUkVHRVhQX1JFID0gL15cXC8oLiopXFwvKFthLXpdKikkLztcbmZ1bmN0aW9uIG1hcmtSb3V0ZVJlY29yZEFjdGl2ZShyb3V0ZSwgY3VycmVudFJvdXRlKSB7XG5cdGNvbnN0IGlzRXhhY3RBY3RpdmUgPSBjdXJyZW50Um91dGUubWF0Y2hlZC5sZW5ndGggJiYgaXNTYW1lUm91dGVSZWNvcmQoY3VycmVudFJvdXRlLm1hdGNoZWRbY3VycmVudFJvdXRlLm1hdGNoZWQubGVuZ3RoIC0gMV0sIHJvdXRlLnJlY29yZCk7XG5cdHJvdXRlLl9fdmRfZXhhY3RBY3RpdmUgPSByb3V0ZS5fX3ZkX2FjdGl2ZSA9IGlzRXhhY3RBY3RpdmU7XG5cdGlmICghaXNFeGFjdEFjdGl2ZSkgcm91dGUuX192ZF9hY3RpdmUgPSBjdXJyZW50Um91dGUubWF0Y2hlZC5zb21lKChtYXRjaCkgPT4gaXNTYW1lUm91dGVSZWNvcmQobWF0Y2gsIHJvdXRlLnJlY29yZCkpO1xuXHRyb3V0ZS5jaGlsZHJlbi5mb3JFYWNoKChjaGlsZFJvdXRlKSA9PiBtYXJrUm91dGVSZWNvcmRBY3RpdmUoY2hpbGRSb3V0ZSwgY3VycmVudFJvdXRlKSk7XG59XG5mdW5jdGlvbiByZXNldE1hdGNoU3RhdGVPblJvdXRlUmVjb3JkKHJvdXRlKSB7XG5cdHJvdXRlLl9fdmRfbWF0Y2ggPSBmYWxzZTtcblx0cm91dGUuY2hpbGRyZW4uZm9yRWFjaChyZXNldE1hdGNoU3RhdGVPblJvdXRlUmVjb3JkKTtcbn1cbmZ1bmN0aW9uIGlzUm91dGVNYXRjaGluZyhyb3V0ZSwgZmlsdGVyKSB7XG5cdGNvbnN0IGZvdW5kID0gU3RyaW5nKHJvdXRlLnJlKS5tYXRjaChFWFRSQUNUX1JFR0VYUF9SRSk7XG5cdHJvdXRlLl9fdmRfbWF0Y2ggPSBmYWxzZTtcblx0aWYgKCFmb3VuZCB8fCBmb3VuZC5sZW5ndGggPCAzKSByZXR1cm4gZmFsc2U7XG5cdGlmIChuZXcgUmVnRXhwKGZvdW5kWzFdLnJlcGxhY2UoL1xcJCQvLCBcIlwiKSwgZm91bmRbMl0pLnRlc3QoZmlsdGVyKSkge1xuXHRcdHJvdXRlLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkKSA9PiBpc1JvdXRlTWF0Y2hpbmcoY2hpbGQsIGZpbHRlcikpO1xuXHRcdGlmIChyb3V0ZS5yZWNvcmQucGF0aCAhPT0gXCIvXCIgfHwgZmlsdGVyID09PSBcIi9cIikge1xuXHRcdFx0cm91dGUuX192ZF9tYXRjaCA9IHJvdXRlLnJlLnRlc3QoZmlsdGVyKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0Y29uc3QgcGF0aCA9IHJvdXRlLnJlY29yZC5wYXRoLnRvTG93ZXJDYXNlKCk7XG5cdGNvbnN0IGRlY29kZWRQYXRoID0gZGVjb2RlKHBhdGgpO1xuXHRpZiAoIWZpbHRlci5zdGFydHNXaXRoKFwiL1wiKSAmJiAoZGVjb2RlZFBhdGguaW5jbHVkZXMoZmlsdGVyKSB8fCBwYXRoLmluY2x1ZGVzKGZpbHRlcikpKSByZXR1cm4gdHJ1ZTtcblx0aWYgKGRlY29kZWRQYXRoLnN0YXJ0c1dpdGgoZmlsdGVyKSB8fCBwYXRoLnN0YXJ0c1dpdGgoZmlsdGVyKSkgcmV0dXJuIHRydWU7XG5cdGlmIChyb3V0ZS5yZWNvcmQubmFtZSAmJiBTdHJpbmcocm91dGUucmVjb3JkLm5hbWUpLmluY2x1ZGVzKGZpbHRlcikpIHJldHVybiB0cnVlO1xuXHRyZXR1cm4gcm91dGUuY2hpbGRyZW4uc29tZSgoY2hpbGQpID0+IGlzUm91dGVNYXRjaGluZyhjaGlsZCwgZmlsdGVyKSk7XG59XG5mdW5jdGlvbiBvbWl0KG9iaiwga2V5cykge1xuXHRjb25zdCByZXQgPSB7fTtcblx0Zm9yIChjb25zdCBrZXkgaW4gb2JqKSBpZiAoIWtleXMuaW5jbHVkZXMoa2V5KSkgcmV0W2tleV0gPSBvYmpba2V5XTtcblx0cmV0dXJuIHJldDtcbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc0Jyb3dzZXIgYXMgJCwgU1RBUlQgYXMgQSwgc3RyaW5naWZ5VVJMIGFzIEIsIGNvbXB1dGVTY3JvbGxQb3NpdGlvbiBhcyBDLCBzY3JvbGxUb1Bvc2l0aW9uIGFzIEQsIHNhdmVTY3JvbGxQb3NpdGlvbiBhcyBFLCBpc1NhbWVSb3V0ZUxvY2F0aW9uIGFzIEYsIGVuY29kZVBhdGggYXMgRywgZGVjb2RlIGFzIEgsIGlzU2FtZVJvdXRlTG9jYXRpb25QYXJhbXMgYXMgSSwgYXNzaWduIGFzIEosIHdhcm4kMSBhcyBLLCBpc1NhbWVSb3V0ZVJlY29yZCBhcyBMLCBub3JtYWxpemVCYXNlIGFzIE0sIE5FV19zdHJpbmdpZnlVUkwgYXMgTiwgTmF2aWdhdGlvbkRpcmVjdGlvbiBhcyBPLCBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEIGFzIFAsIG5vb3AgYXMgUSwgcGFyc2VVUkwgYXMgUiwgaXNSb3V0ZU5hbWUgYXMgUywgZ2V0U2Nyb2xsS2V5IGFzIFQsIGVuY29kZUhhc2ggYXMgVSwgc3RyaXBCYXNlIGFzIFYsIGVuY29kZVBhcmFtIGFzIFcsIGlzQXJyYXkgYXMgWCwgaWRlbnRpdHlGbiBhcyBZLCBtZXJnZU9wdGlvbnMgYXMgWiwgRXJyb3JUeXBlcyBhcyBfLCBsb2FkUm91dGVMb2NhdGlvbiBhcyBhLCBpc05hdmlnYXRpb25GYWlsdXJlIGFzIGIsIHVzZUNhbGxiYWNrcyBhcyBjLCByb3V0ZXJLZXkgYXMgZCwgcm91dGVyVmlld0xvY2F0aW9uS2V5IGFzIGYsIHN0cmluZ2lmeVF1ZXJ5IGFzIGcsIHBhcnNlUXVlcnkgYXMgaCwgZ3VhcmRUb1Byb21pc2VGbiBhcyBpLCBjcmVhdGVIcmVmIGFzIGosIE5hdmlnYXRpb25UeXBlIGFzIGssIG1hdGNoZWRSb3V0ZUtleSBhcyBsLCBub3JtYWxpemVRdWVyeSBhcyBtLCBleHRyYWN0Q2hhbmdpbmdSZWNvcmRzIGFzIG4sIG9uQmVmb3JlUm91dGVMZWF2ZSBhcyBvLCB2aWV3RGVwdGhLZXkgYXMgcCwgYXBwbHlUb1BhcmFtcyBhcyBxLCBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyBhcyByLCBvbkJlZm9yZVJvdXRlVXBkYXRlIGFzIHMsIGFkZERldnRvb2xzIGFzIHQsIHJvdXRlTG9jYXRpb25LZXkgYXMgdSwgTmF2aWdhdGlvbkZhaWx1cmVUeXBlIGFzIHYsIGdldFNhdmVkU2Nyb2xsUG9zaXRpb24gYXMgdywgaXNSb3V0ZUxvY2F0aW9uIGFzIHgsIGNyZWF0ZVJvdXRlckVycm9yIGFzIHksIHJlc29sdmVSZWxhdGl2ZVBhdGggYXMgeiB9OyIsIi8qIVxuICogdnVlLXJvdXRlciB2NC42LjRcbiAqIChjKSAyMDI1IEVkdWFyZG8gU2FuIE1hcnRpbiBNb3JvdGVcbiAqIEBsaWNlbnNlIE1JVFxuICovXG5pbXBvcnQgeyAkIGFzIGlzQnJvd3NlciwgQSBhcyBTVEFSVCwgQiBhcyBzdHJpbmdpZnlVUkwsIEMgYXMgY29tcHV0ZVNjcm9sbFBvc2l0aW9uLCBEIGFzIHNjcm9sbFRvUG9zaXRpb24sIEUgYXMgc2F2ZVNjcm9sbFBvc2l0aW9uLCBGIGFzIGlzU2FtZVJvdXRlTG9jYXRpb24sIEggYXMgZGVjb2RlLCBJIGFzIGlzU2FtZVJvdXRlTG9jYXRpb25QYXJhbXMsIEogYXMgYXNzaWduLCBLIGFzIHdhcm4kMSwgTCBhcyBpc1NhbWVSb3V0ZVJlY29yZCwgTSBhcyBub3JtYWxpemVCYXNlLCBPIGFzIE5hdmlnYXRpb25EaXJlY3Rpb24sIFAgYXMgU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCwgUSBhcyBub29wLCBSIGFzIHBhcnNlVVJMLCBTIGFzIGlzUm91dGVOYW1lLCBUIGFzIGdldFNjcm9sbEtleSwgVSBhcyBlbmNvZGVIYXNoLCBWIGFzIHN0cmlwQmFzZSwgVyBhcyBlbmNvZGVQYXJhbSwgWCBhcyBpc0FycmF5LCBaIGFzIG1lcmdlT3B0aW9ucywgXyBhcyBFcnJvclR5cGVzLCBhIGFzIGxvYWRSb3V0ZUxvY2F0aW9uLCBiIGFzIGlzTmF2aWdhdGlvbkZhaWx1cmUsIGMgYXMgdXNlQ2FsbGJhY2tzLCBkIGFzIHJvdXRlcktleSwgZiBhcyByb3V0ZXJWaWV3TG9jYXRpb25LZXksIGcgYXMgc3RyaW5naWZ5UXVlcnksIGggYXMgcGFyc2VRdWVyeSwgaSBhcyBndWFyZFRvUHJvbWlzZUZuLCBqIGFzIGNyZWF0ZUhyZWYsIGsgYXMgTmF2aWdhdGlvblR5cGUsIGwgYXMgbWF0Y2hlZFJvdXRlS2V5LCBtIGFzIG5vcm1hbGl6ZVF1ZXJ5LCBuIGFzIGV4dHJhY3RDaGFuZ2luZ1JlY29yZHMsIG8gYXMgb25CZWZvcmVSb3V0ZUxlYXZlLCBwIGFzIHZpZXdEZXB0aEtleSwgcSBhcyBhcHBseVRvUGFyYW1zLCByIGFzIGV4dHJhY3RDb21wb25lbnRzR3VhcmRzLCBzIGFzIG9uQmVmb3JlUm91dGVVcGRhdGUsIHQgYXMgYWRkRGV2dG9vbHMsIHUgYXMgcm91dGVMb2NhdGlvbktleSwgdiBhcyBOYXZpZ2F0aW9uRmFpbHVyZVR5cGUsIHcgYXMgZ2V0U2F2ZWRTY3JvbGxQb3NpdGlvbiwgeCBhcyBpc1JvdXRlTG9jYXRpb24sIHkgYXMgY3JlYXRlUm91dGVyRXJyb3IgfSBmcm9tIFwiLi9kZXZ0b29scy1FV044MWlPbC5tanNcIjtcbmltcG9ydCB7IGNvbXB1dGVkLCBkZWZpbmVDb21wb25lbnQsIGdldEN1cnJlbnRJbnN0YW5jZSwgaCwgaW5qZWN0LCBuZXh0VGljaywgcHJvdmlkZSwgcmVhY3RpdmUsIHJlZiwgc2hhbGxvd1JlYWN0aXZlLCBzaGFsbG93UmVmLCB1bnJlZiwgd2F0Y2gsIHdhdGNoRWZmZWN0IH0gZnJvbSBcInZ1ZVwiO1xuXG4vLyNyZWdpb24gc3JjL2hpc3RvcnkvaHRtbDUudHNcbmxldCBjcmVhdGVCYXNlTG9jYXRpb24gPSAoKSA9PiBsb2NhdGlvbi5wcm90b2NvbCArIFwiLy9cIiArIGxvY2F0aW9uLmhvc3Q7XG4vKipcbiogQ3JlYXRlcyBhIG5vcm1hbGl6ZWQgaGlzdG9yeSBsb2NhdGlvbiBmcm9tIGEgd2luZG93LmxvY2F0aW9uIG9iamVjdFxuKiBAcGFyYW0gYmFzZSAtIFRoZSBiYXNlIHBhdGhcbiogQHBhcmFtIGxvY2F0aW9uIC0gVGhlIHdpbmRvdy5sb2NhdGlvbiBvYmplY3RcbiovXG5mdW5jdGlvbiBjcmVhdGVDdXJyZW50TG9jYXRpb24oYmFzZSwgbG9jYXRpb24kMSkge1xuXHRjb25zdCB7IHBhdGhuYW1lLCBzZWFyY2gsIGhhc2ggfSA9IGxvY2F0aW9uJDE7XG5cdGNvbnN0IGhhc2hQb3MgPSBiYXNlLmluZGV4T2YoXCIjXCIpO1xuXHRpZiAoaGFzaFBvcyA+IC0xKSB7XG5cdFx0bGV0IHNsaWNlUG9zID0gaGFzaC5pbmNsdWRlcyhiYXNlLnNsaWNlKGhhc2hQb3MpKSA/IGJhc2Uuc2xpY2UoaGFzaFBvcykubGVuZ3RoIDogMTtcblx0XHRsZXQgcGF0aEZyb21IYXNoID0gaGFzaC5zbGljZShzbGljZVBvcyk7XG5cdFx0aWYgKHBhdGhGcm9tSGFzaFswXSAhPT0gXCIvXCIpIHBhdGhGcm9tSGFzaCA9IFwiL1wiICsgcGF0aEZyb21IYXNoO1xuXHRcdHJldHVybiBzdHJpcEJhc2UocGF0aEZyb21IYXNoLCBcIlwiKTtcblx0fVxuXHRyZXR1cm4gc3RyaXBCYXNlKHBhdGhuYW1lLCBiYXNlKSArIHNlYXJjaCArIGhhc2g7XG59XG5mdW5jdGlvbiB1c2VIaXN0b3J5TGlzdGVuZXJzKGJhc2UsIGhpc3RvcnlTdGF0ZSwgY3VycmVudExvY2F0aW9uLCByZXBsYWNlKSB7XG5cdGxldCBsaXN0ZW5lcnMgPSBbXTtcblx0bGV0IHRlYXJkb3ducyA9IFtdO1xuXHRsZXQgcGF1c2VTdGF0ZSA9IG51bGw7XG5cdGNvbnN0IHBvcFN0YXRlSGFuZGxlciA9ICh7IHN0YXRlIH0pID0+IHtcblx0XHRjb25zdCB0byA9IGNyZWF0ZUN1cnJlbnRMb2NhdGlvbihiYXNlLCBsb2NhdGlvbik7XG5cdFx0Y29uc3QgZnJvbSA9IGN1cnJlbnRMb2NhdGlvbi52YWx1ZTtcblx0XHRjb25zdCBmcm9tU3RhdGUgPSBoaXN0b3J5U3RhdGUudmFsdWU7XG5cdFx0bGV0IGRlbHRhID0gMDtcblx0XHRpZiAoc3RhdGUpIHtcblx0XHRcdGN1cnJlbnRMb2NhdGlvbi52YWx1ZSA9IHRvO1xuXHRcdFx0aGlzdG9yeVN0YXRlLnZhbHVlID0gc3RhdGU7XG5cdFx0XHRpZiAocGF1c2VTdGF0ZSAmJiBwYXVzZVN0YXRlID09PSBmcm9tKSB7XG5cdFx0XHRcdHBhdXNlU3RhdGUgPSBudWxsO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRkZWx0YSA9IGZyb21TdGF0ZSA/IHN0YXRlLnBvc2l0aW9uIC0gZnJvbVN0YXRlLnBvc2l0aW9uIDogMDtcblx0XHR9IGVsc2UgcmVwbGFjZSh0byk7XG5cdFx0bGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRsaXN0ZW5lcihjdXJyZW50TG9jYXRpb24udmFsdWUsIGZyb20sIHtcblx0XHRcdFx0ZGVsdGEsXG5cdFx0XHRcdHR5cGU6IE5hdmlnYXRpb25UeXBlLnBvcCxcblx0XHRcdFx0ZGlyZWN0aW9uOiBkZWx0YSA/IGRlbHRhID4gMCA/IE5hdmlnYXRpb25EaXJlY3Rpb24uZm9yd2FyZCA6IE5hdmlnYXRpb25EaXJlY3Rpb24uYmFjayA6IE5hdmlnYXRpb25EaXJlY3Rpb24udW5rbm93blxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH07XG5cdGZ1bmN0aW9uIHBhdXNlTGlzdGVuZXJzKCkge1xuXHRcdHBhdXNlU3RhdGUgPSBjdXJyZW50TG9jYXRpb24udmFsdWU7XG5cdH1cblx0ZnVuY3Rpb24gbGlzdGVuKGNhbGxiYWNrKSB7XG5cdFx0bGlzdGVuZXJzLnB1c2goY2FsbGJhY2spO1xuXHRcdGNvbnN0IHRlYXJkb3duID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgaW5kZXggPSBsaXN0ZW5lcnMuaW5kZXhPZihjYWxsYmFjayk7XG5cdFx0XHRpZiAoaW5kZXggPiAtMSkgbGlzdGVuZXJzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0fTtcblx0XHR0ZWFyZG93bnMucHVzaCh0ZWFyZG93bik7XG5cdFx0cmV0dXJuIHRlYXJkb3duO1xuXHR9XG5cdGZ1bmN0aW9uIGJlZm9yZVVubG9hZExpc3RlbmVyKCkge1xuXHRcdGlmIChkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09IFwiaGlkZGVuXCIpIHtcblx0XHRcdGNvbnN0IHsgaGlzdG9yeTogaGlzdG9yeSQxIH0gPSB3aW5kb3c7XG5cdFx0XHRpZiAoIWhpc3RvcnkkMS5zdGF0ZSkgcmV0dXJuO1xuXHRcdFx0aGlzdG9yeSQxLnJlcGxhY2VTdGF0ZShhc3NpZ24oe30sIGhpc3RvcnkkMS5zdGF0ZSwgeyBzY3JvbGw6IGNvbXB1dGVTY3JvbGxQb3NpdGlvbigpIH0pLCBcIlwiKTtcblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gZGVzdHJveSgpIHtcblx0XHRmb3IgKGNvbnN0IHRlYXJkb3duIG9mIHRlYXJkb3ducykgdGVhcmRvd24oKTtcblx0XHR0ZWFyZG93bnMgPSBbXTtcblx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIHBvcFN0YXRlSGFuZGxlcik7XG5cdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwYWdlaGlkZVwiLCBiZWZvcmVVbmxvYWRMaXN0ZW5lcik7XG5cdFx0ZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgYmVmb3JlVW5sb2FkTGlzdGVuZXIpO1xuXHR9XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicG9wc3RhdGVcIiwgcG9wU3RhdGVIYW5kbGVyKTtcblx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwYWdlaGlkZVwiLCBiZWZvcmVVbmxvYWRMaXN0ZW5lcik7XG5cdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGJlZm9yZVVubG9hZExpc3RlbmVyKTtcblx0cmV0dXJuIHtcblx0XHRwYXVzZUxpc3RlbmVycyxcblx0XHRsaXN0ZW4sXG5cdFx0ZGVzdHJveVxuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYSBzdGF0ZSBvYmplY3RcbiovXG5mdW5jdGlvbiBidWlsZFN0YXRlKGJhY2ssIGN1cnJlbnQsIGZvcndhcmQsIHJlcGxhY2VkID0gZmFsc2UsIGNvbXB1dGVTY3JvbGwgPSBmYWxzZSkge1xuXHRyZXR1cm4ge1xuXHRcdGJhY2ssXG5cdFx0Y3VycmVudCxcblx0XHRmb3J3YXJkLFxuXHRcdHJlcGxhY2VkLFxuXHRcdHBvc2l0aW9uOiB3aW5kb3cuaGlzdG9yeS5sZW5ndGgsXG5cdFx0c2Nyb2xsOiBjb21wdXRlU2Nyb2xsID8gY29tcHV0ZVNjcm9sbFBvc2l0aW9uKCkgOiBudWxsXG5cdH07XG59XG5mdW5jdGlvbiB1c2VIaXN0b3J5U3RhdGVOYXZpZ2F0aW9uKGJhc2UpIHtcblx0Y29uc3QgeyBoaXN0b3J5OiBoaXN0b3J5JDEsIGxvY2F0aW9uOiBsb2NhdGlvbiQxIH0gPSB3aW5kb3c7XG5cdGNvbnN0IGN1cnJlbnRMb2NhdGlvbiA9IHsgdmFsdWU6IGNyZWF0ZUN1cnJlbnRMb2NhdGlvbihiYXNlLCBsb2NhdGlvbiQxKSB9O1xuXHRjb25zdCBoaXN0b3J5U3RhdGUgPSB7IHZhbHVlOiBoaXN0b3J5JDEuc3RhdGUgfTtcblx0aWYgKCFoaXN0b3J5U3RhdGUudmFsdWUpIGNoYW5nZUxvY2F0aW9uKGN1cnJlbnRMb2NhdGlvbi52YWx1ZSwge1xuXHRcdGJhY2s6IG51bGwsXG5cdFx0Y3VycmVudDogY3VycmVudExvY2F0aW9uLnZhbHVlLFxuXHRcdGZvcndhcmQ6IG51bGwsXG5cdFx0cG9zaXRpb246IGhpc3RvcnkkMS5sZW5ndGggLSAxLFxuXHRcdHJlcGxhY2VkOiB0cnVlLFxuXHRcdHNjcm9sbDogbnVsbFxuXHR9LCB0cnVlKTtcblx0ZnVuY3Rpb24gY2hhbmdlTG9jYXRpb24odG8sIHN0YXRlLCByZXBsYWNlJDEpIHtcblx0XHQvKipcblx0XHQqIGlmIGEgYmFzZSB0YWcgaXMgcHJvdmlkZWQsIGFuZCB3ZSBhcmUgb24gYSBub3JtYWwgZG9tYWluLCB3ZSBoYXZlIHRvXG5cdFx0KiByZXNwZWN0IHRoZSBwcm92aWRlZCBgYmFzZWAgYXR0cmlidXRlIGJlY2F1c2UgcHVzaFN0YXRlKCkgd2lsbCB1c2UgaXQgYW5kXG5cdFx0KiBwb3RlbnRpYWxseSBlcmFzZSBhbnl0aGluZyBiZWZvcmUgdGhlIGAjYCBsaWtlIGF0XG5cdFx0KiBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyL2lzc3Vlcy82ODUgd2hlcmUgYSBiYXNlIG9mXG5cdFx0KiBgL2ZvbGRlci8jYCBidXQgYSBiYXNlIG9mIGAvYCB3b3VsZCBlcmFzZSB0aGUgYC9mb2xkZXIvYCBzZWN0aW9uLiBJZlxuXHRcdCogdGhlcmUgaXMgbm8gaG9zdCwgdGhlIGA8YmFzZT5gIHRhZyBtYWtlcyBubyBzZW5zZSBhbmQgaWYgdGhlcmUgaXNuJ3QgYVxuXHRcdCogYmFzZSB0YWcgd2UgY2FuIGp1c3QgdXNlIGV2ZXJ5dGhpbmcgYWZ0ZXIgdGhlIGAjYC5cblx0XHQqL1xuXHRcdGNvbnN0IGhhc2hJbmRleCA9IGJhc2UuaW5kZXhPZihcIiNcIik7XG5cdFx0Y29uc3QgdXJsID0gaGFzaEluZGV4ID4gLTEgPyAobG9jYXRpb24kMS5ob3N0ICYmIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJiYXNlXCIpID8gYmFzZSA6IGJhc2Uuc2xpY2UoaGFzaEluZGV4KSkgKyB0byA6IGNyZWF0ZUJhc2VMb2NhdGlvbigpICsgYmFzZSArIHRvO1xuXHRcdHRyeSB7XG5cdFx0XHRoaXN0b3J5JDFbcmVwbGFjZSQxID8gXCJyZXBsYWNlU3RhdGVcIiA6IFwicHVzaFN0YXRlXCJdKHN0YXRlLCBcIlwiLCB1cmwpO1xuXHRcdFx0aGlzdG9yeVN0YXRlLnZhbHVlID0gc3RhdGU7XG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB3YXJuJDEoXCJFcnJvciB3aXRoIHB1c2gvcmVwbGFjZSBTdGF0ZVwiLCBlcnIpO1xuXHRcdFx0ZWxzZSBjb25zb2xlLmVycm9yKGVycik7XG5cdFx0XHRsb2NhdGlvbiQxW3JlcGxhY2UkMSA/IFwicmVwbGFjZVwiIDogXCJhc3NpZ25cIl0odXJsKTtcblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gcmVwbGFjZSh0bywgZGF0YSkge1xuXHRcdGNoYW5nZUxvY2F0aW9uKHRvLCBhc3NpZ24oe30sIGhpc3RvcnkkMS5zdGF0ZSwgYnVpbGRTdGF0ZShoaXN0b3J5U3RhdGUudmFsdWUuYmFjaywgdG8sIGhpc3RvcnlTdGF0ZS52YWx1ZS5mb3J3YXJkLCB0cnVlKSwgZGF0YSwgeyBwb3NpdGlvbjogaGlzdG9yeVN0YXRlLnZhbHVlLnBvc2l0aW9uIH0pLCB0cnVlKTtcblx0XHRjdXJyZW50TG9jYXRpb24udmFsdWUgPSB0bztcblx0fVxuXHRmdW5jdGlvbiBwdXNoKHRvLCBkYXRhKSB7XG5cdFx0Y29uc3QgY3VycmVudFN0YXRlID0gYXNzaWduKHt9LCBoaXN0b3J5U3RhdGUudmFsdWUsIGhpc3RvcnkkMS5zdGF0ZSwge1xuXHRcdFx0Zm9yd2FyZDogdG8sXG5cdFx0XHRzY3JvbGw6IGNvbXB1dGVTY3JvbGxQb3NpdGlvbigpXG5cdFx0fSk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhaGlzdG9yeSQxLnN0YXRlKSB3YXJuJDEoXCJoaXN0b3J5LnN0YXRlIHNlZW1zIHRvIGhhdmUgYmVlbiBtYW51YWxseSByZXBsYWNlZCB3aXRob3V0IHByZXNlcnZpbmcgdGhlIG5lY2Vzc2FyeSB2YWx1ZXMuIE1ha2Ugc3VyZSB0byBwcmVzZXJ2ZSBleGlzdGluZyBoaXN0b3J5IHN0YXRlIGlmIHlvdSBhcmUgbWFudWFsbHkgY2FsbGluZyBoaXN0b3J5LnJlcGxhY2VTdGF0ZTpcXG5cXG5oaXN0b3J5LnJlcGxhY2VTdGF0ZShoaXN0b3J5LnN0YXRlLCAnJywgdXJsKVxcblxcbllvdSBjYW4gZmluZCBtb3JlIGluZm9ybWF0aW9uIGF0IGh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9taWdyYXRpb24vI1VzYWdlLW9mLWhpc3Rvcnktc3RhdGVcIik7XG5cdFx0Y2hhbmdlTG9jYXRpb24oY3VycmVudFN0YXRlLmN1cnJlbnQsIGN1cnJlbnRTdGF0ZSwgdHJ1ZSk7XG5cdFx0Y2hhbmdlTG9jYXRpb24odG8sIGFzc2lnbih7fSwgYnVpbGRTdGF0ZShjdXJyZW50TG9jYXRpb24udmFsdWUsIHRvLCBudWxsKSwgeyBwb3NpdGlvbjogY3VycmVudFN0YXRlLnBvc2l0aW9uICsgMSB9LCBkYXRhKSwgZmFsc2UpO1xuXHRcdGN1cnJlbnRMb2NhdGlvbi52YWx1ZSA9IHRvO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0bG9jYXRpb246IGN1cnJlbnRMb2NhdGlvbixcblx0XHRzdGF0ZTogaGlzdG9yeVN0YXRlLFxuXHRcdHB1c2gsXG5cdFx0cmVwbGFjZVxuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYW4gSFRNTDUgaGlzdG9yeS4gTW9zdCBjb21tb24gaGlzdG9yeSBmb3Igc2luZ2xlIHBhZ2UgYXBwbGljYXRpb25zLlxuKlxuKiBAcGFyYW0gYmFzZSAtXG4qL1xuZnVuY3Rpb24gY3JlYXRlV2ViSGlzdG9yeShiYXNlKSB7XG5cdGJhc2UgPSBub3JtYWxpemVCYXNlKGJhc2UpO1xuXHRjb25zdCBoaXN0b3J5TmF2aWdhdGlvbiA9IHVzZUhpc3RvcnlTdGF0ZU5hdmlnYXRpb24oYmFzZSk7XG5cdGNvbnN0IGhpc3RvcnlMaXN0ZW5lcnMgPSB1c2VIaXN0b3J5TGlzdGVuZXJzKGJhc2UsIGhpc3RvcnlOYXZpZ2F0aW9uLnN0YXRlLCBoaXN0b3J5TmF2aWdhdGlvbi5sb2NhdGlvbiwgaGlzdG9yeU5hdmlnYXRpb24ucmVwbGFjZSk7XG5cdGZ1bmN0aW9uIGdvKGRlbHRhLCB0cmlnZ2VyTGlzdGVuZXJzID0gdHJ1ZSkge1xuXHRcdGlmICghdHJpZ2dlckxpc3RlbmVycykgaGlzdG9yeUxpc3RlbmVycy5wYXVzZUxpc3RlbmVycygpO1xuXHRcdGhpc3RvcnkuZ28oZGVsdGEpO1xuXHR9XG5cdGNvbnN0IHJvdXRlckhpc3RvcnkgPSBhc3NpZ24oe1xuXHRcdGxvY2F0aW9uOiBcIlwiLFxuXHRcdGJhc2UsXG5cdFx0Z28sXG5cdFx0Y3JlYXRlSHJlZjogY3JlYXRlSHJlZi5iaW5kKG51bGwsIGJhc2UpXG5cdH0sIGhpc3RvcnlOYXZpZ2F0aW9uLCBoaXN0b3J5TGlzdGVuZXJzKTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwibG9jYXRpb25cIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBoaXN0b3J5TmF2aWdhdGlvbi5sb2NhdGlvbi52YWx1ZVxuXHR9KTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwic3RhdGVcIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBoaXN0b3J5TmF2aWdhdGlvbi5zdGF0ZS52YWx1ZVxuXHR9KTtcblx0cmV0dXJuIHJvdXRlckhpc3Rvcnk7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9oaXN0b3J5L21lbW9yeS50c1xuLyoqXG4qIENyZWF0ZXMgYW4gaW4tbWVtb3J5IGJhc2VkIGhpc3RvcnkuIFRoZSBtYWluIHB1cnBvc2Ugb2YgdGhpcyBoaXN0b3J5IGlzIHRvIGhhbmRsZSBTU1IuIEl0IHN0YXJ0cyBpbiBhIHNwZWNpYWwgbG9jYXRpb24gdGhhdCBpcyBub3doZXJlLlxuKiBJdCdzIHVwIHRvIHRoZSB1c2VyIHRvIHJlcGxhY2UgdGhhdCBsb2NhdGlvbiB3aXRoIHRoZSBzdGFydGVyIGxvY2F0aW9uIGJ5IGVpdGhlciBjYWxsaW5nIGByb3V0ZXIucHVzaGAgb3IgYHJvdXRlci5yZXBsYWNlYC5cbipcbiogQHBhcmFtIGJhc2UgLSBCYXNlIGFwcGxpZWQgdG8gYWxsIHVybHMsIGRlZmF1bHRzIHRvICcvJ1xuKiBAcmV0dXJucyBhIGhpc3Rvcnkgb2JqZWN0IHRoYXQgY2FuIGJlIHBhc3NlZCB0byB0aGUgcm91dGVyIGNvbnN0cnVjdG9yXG4qL1xuZnVuY3Rpb24gY3JlYXRlTWVtb3J5SGlzdG9yeShiYXNlID0gXCJcIikge1xuXHRsZXQgbGlzdGVuZXJzID0gW107XG5cdGxldCBxdWV1ZSA9IFtbU1RBUlQsIHt9XV07XG5cdGxldCBwb3NpdGlvbiA9IDA7XG5cdGJhc2UgPSBub3JtYWxpemVCYXNlKGJhc2UpO1xuXHRmdW5jdGlvbiBzZXRMb2NhdGlvbihsb2NhdGlvbiQxLCBzdGF0ZSA9IHt9KSB7XG5cdFx0cG9zaXRpb24rKztcblx0XHRpZiAocG9zaXRpb24gIT09IHF1ZXVlLmxlbmd0aCkgcXVldWUuc3BsaWNlKHBvc2l0aW9uKTtcblx0XHRxdWV1ZS5wdXNoKFtsb2NhdGlvbiQxLCBzdGF0ZV0pO1xuXHR9XG5cdGZ1bmN0aW9uIHRyaWdnZXJMaXN0ZW5lcnModG8sIGZyb20sIHsgZGlyZWN0aW9uLCBkZWx0YSB9KSB7XG5cdFx0Y29uc3QgaW5mbyA9IHtcblx0XHRcdGRpcmVjdGlvbixcblx0XHRcdGRlbHRhLFxuXHRcdFx0dHlwZTogTmF2aWdhdGlvblR5cGUucG9wXG5cdFx0fTtcblx0XHRmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIGxpc3RlbmVycykgY2FsbGJhY2sodG8sIGZyb20sIGluZm8pO1xuXHR9XG5cdGNvbnN0IHJvdXRlckhpc3RvcnkgPSB7XG5cdFx0bG9jYXRpb246IFNUQVJULFxuXHRcdHN0YXRlOiB7fSxcblx0XHRiYXNlLFxuXHRcdGNyZWF0ZUhyZWY6IGNyZWF0ZUhyZWYuYmluZChudWxsLCBiYXNlKSxcblx0XHRyZXBsYWNlKHRvLCBzdGF0ZSkge1xuXHRcdFx0cXVldWUuc3BsaWNlKHBvc2l0aW9uLS0sIDEpO1xuXHRcdFx0c2V0TG9jYXRpb24odG8sIHN0YXRlKTtcblx0XHR9LFxuXHRcdHB1c2godG8sIHN0YXRlKSB7XG5cdFx0XHRzZXRMb2NhdGlvbih0bywgc3RhdGUpO1xuXHRcdH0sXG5cdFx0bGlzdGVuKGNhbGxiYWNrKSB7XG5cdFx0XHRsaXN0ZW5lcnMucHVzaChjYWxsYmFjayk7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBpbmRleCA9IGxpc3RlbmVycy5pbmRleE9mKGNhbGxiYWNrKTtcblx0XHRcdFx0aWYgKGluZGV4ID4gLTEpIGxpc3RlbmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdGRlc3Ryb3koKSB7XG5cdFx0XHRsaXN0ZW5lcnMgPSBbXTtcblx0XHRcdHF1ZXVlID0gW1tTVEFSVCwge31dXTtcblx0XHRcdHBvc2l0aW9uID0gMDtcblx0XHR9LFxuXHRcdGdvKGRlbHRhLCBzaG91bGRUcmlnZ2VyID0gdHJ1ZSkge1xuXHRcdFx0Y29uc3QgZnJvbSA9IHRoaXMubG9jYXRpb247XG5cdFx0XHRjb25zdCBkaXJlY3Rpb24gPSBkZWx0YSA8IDAgPyBOYXZpZ2F0aW9uRGlyZWN0aW9uLmJhY2sgOiBOYXZpZ2F0aW9uRGlyZWN0aW9uLmZvcndhcmQ7XG5cdFx0XHRwb3NpdGlvbiA9IE1hdGgubWF4KDAsIE1hdGgubWluKHBvc2l0aW9uICsgZGVsdGEsIHF1ZXVlLmxlbmd0aCAtIDEpKTtcblx0XHRcdGlmIChzaG91bGRUcmlnZ2VyKSB0cmlnZ2VyTGlzdGVuZXJzKHRoaXMubG9jYXRpb24sIGZyb20sIHtcblx0XHRcdFx0ZGlyZWN0aW9uLFxuXHRcdFx0XHRkZWx0YVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkocm91dGVySGlzdG9yeSwgXCJsb2NhdGlvblwiLCB7XG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRnZXQ6ICgpID0+IHF1ZXVlW3Bvc2l0aW9uXVswXVxuXHR9KTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwic3RhdGVcIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBxdWV1ZVtwb3NpdGlvbl1bMV1cblx0fSk7XG5cdHJldHVybiByb3V0ZXJIaXN0b3J5O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaGlzdG9yeS9oYXNoLnRzXG4vKipcbiogQ3JlYXRlcyBhIGhhc2ggaGlzdG9yeS4gVXNlZnVsIGZvciB3ZWIgYXBwbGljYXRpb25zIHdpdGggbm8gaG9zdCAoZS5nLiBgZmlsZTovL2ApIG9yIHdoZW4gY29uZmlndXJpbmcgYSBzZXJ2ZXIgdG9cbiogaGFuZGxlIGFueSBVUkwgaXMgbm90IHBvc3NpYmxlLlxuKlxuKiBAcGFyYW0gYmFzZSAtIG9wdGlvbmFsIGJhc2UgdG8gcHJvdmlkZS4gRGVmYXVsdHMgdG8gYGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoYCBJZiB0aGVyZSBpcyBhIGA8YmFzZT5gIHRhZ1xuKiBpbiB0aGUgYGhlYWRgLCBpdHMgdmFsdWUgd2lsbCBiZSBpZ25vcmVkIGluIGZhdm9yIG9mIHRoaXMgcGFyYW1ldGVyICoqYnV0IG5vdGUgaXQgYWZmZWN0cyBhbGwgdGhlIGhpc3RvcnkucHVzaFN0YXRlKClcbiogY2FsbHMqKiwgbWVhbmluZyB0aGF0IGlmIHlvdSB1c2UgYSBgPGJhc2U+YCB0YWcsIGl0J3MgYGhyZWZgIHZhbHVlICoqaGFzIHRvIG1hdGNoIHRoaXMgcGFyYW1ldGVyKiogKGlnbm9yaW5nIGFueXRoaW5nXG4qIGFmdGVyIHRoZSBgI2ApLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGBqc1xuKiAvLyBhdCBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlclxuKiBjcmVhdGVXZWJIYXNoSGlzdG9yeSgpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlciNgXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCcvZm9sZGVyLycpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlci8jYFxuKiAvLyBpZiB0aGUgYCNgIGlzIHByb3ZpZGVkIGluIHRoZSBiYXNlLCBpdCB3b24ndCBiZSBhZGRlZCBieSBgY3JlYXRlV2ViSGFzaEhpc3RvcnlgXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCcvZm9sZGVyLyMvYXBwLycpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlci8jL2FwcC9gXG4qIC8vIHlvdSBzaG91bGQgYXZvaWQgZG9pbmcgdGhpcyBiZWNhdXNlIGl0IGNoYW5nZXMgdGhlIG9yaWdpbmFsIHVybCBhbmQgYnJlYWtzIGNvcHlpbmcgdXJsc1xuKiBjcmVhdGVXZWJIYXNoSGlzdG9yeSgnL290aGVyLWZvbGRlci8nKSAvLyBnaXZlcyBhIHVybCBvZiBgaHR0cHM6Ly9leGFtcGxlLmNvbS9vdGhlci1mb2xkZXIvI2BcbipcbiogLy8gYXQgZmlsZTovLy91c3IvZXRjL2ZvbGRlci9pbmRleC5odG1sXG4qIC8vIGZvciBsb2NhdGlvbnMgd2l0aCBubyBgaG9zdGAsIHRoZSBiYXNlIGlzIGlnbm9yZWRcbiogY3JlYXRlV2ViSGFzaEhpc3RvcnkoJy9pQW1JZ25vcmVkJykgLy8gZ2l2ZXMgYSB1cmwgb2YgYGZpbGU6Ly8vdXNyL2V0Yy9mb2xkZXIvaW5kZXguaHRtbCNgXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KGJhc2UpIHtcblx0YmFzZSA9IGxvY2F0aW9uLmhvc3QgPyBiYXNlIHx8IGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoIDogXCJcIjtcblx0aWYgKCFiYXNlLmluY2x1ZGVzKFwiI1wiKSkgYmFzZSArPSBcIiNcIjtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhYmFzZS5lbmRzV2l0aChcIiMvXCIpICYmICFiYXNlLmVuZHNXaXRoKFwiI1wiKSkgd2FybiQxKGBBIGhhc2ggYmFzZSBtdXN0IGVuZCB3aXRoIGEgXCIjXCI6XFxuXCIke2Jhc2V9XCIgc2hvdWxkIGJlIFwiJHtiYXNlLnJlcGxhY2UoLyMuKiQvLCBcIiNcIil9XCIuYCk7XG5cdHJldHVybiBjcmVhdGVXZWJIaXN0b3J5KGJhc2UpO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWF0Y2hlci9wYXRoVG9rZW5pemVyLnRzXG5sZXQgVG9rZW5UeXBlID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKFRva2VuVHlwZSQxKSB7XG5cdFRva2VuVHlwZSQxW1Rva2VuVHlwZSQxW1wiU3RhdGljXCJdID0gMF0gPSBcIlN0YXRpY1wiO1xuXHRUb2tlblR5cGUkMVtUb2tlblR5cGUkMVtcIlBhcmFtXCJdID0gMV0gPSBcIlBhcmFtXCI7XG5cdFRva2VuVHlwZSQxW1Rva2VuVHlwZSQxW1wiR3JvdXBcIl0gPSAyXSA9IFwiR3JvdXBcIjtcblx0cmV0dXJuIFRva2VuVHlwZSQxO1xufSh7fSk7XG52YXIgVG9rZW5pemVyU3RhdGUgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oVG9rZW5pemVyU3RhdGUkMSkge1xuXHRUb2tlbml6ZXJTdGF0ZSQxW1Rva2VuaXplclN0YXRlJDFbXCJTdGF0aWNcIl0gPSAwXSA9IFwiU3RhdGljXCI7XG5cdFRva2VuaXplclN0YXRlJDFbVG9rZW5pemVyU3RhdGUkMVtcIlBhcmFtXCJdID0gMV0gPSBcIlBhcmFtXCI7XG5cdFRva2VuaXplclN0YXRlJDFbVG9rZW5pemVyU3RhdGUkMVtcIlBhcmFtUmVnRXhwXCJdID0gMl0gPSBcIlBhcmFtUmVnRXhwXCI7XG5cdFRva2VuaXplclN0YXRlJDFbVG9rZW5pemVyU3RhdGUkMVtcIlBhcmFtUmVnRXhwRW5kXCJdID0gM10gPSBcIlBhcmFtUmVnRXhwRW5kXCI7XG5cdFRva2VuaXplclN0YXRlJDFbVG9rZW5pemVyU3RhdGUkMVtcIkVzY2FwZU5leHRcIl0gPSA0XSA9IFwiRXNjYXBlTmV4dFwiO1xuXHRyZXR1cm4gVG9rZW5pemVyU3RhdGUkMTtcbn0oVG9rZW5pemVyU3RhdGUgfHwge30pO1xuY29uc3QgUk9PVF9UT0tFTiA9IHtcblx0dHlwZTogVG9rZW5UeXBlLlN0YXRpYyxcblx0dmFsdWU6IFwiXCJcbn07XG5jb25zdCBWQUxJRF9QQVJBTV9SRSA9IC9bYS16QS1aMC05X10vO1xuZnVuY3Rpb24gdG9rZW5pemVQYXRoKHBhdGgpIHtcblx0aWYgKCFwYXRoKSByZXR1cm4gW1tdXTtcblx0aWYgKHBhdGggPT09IFwiL1wiKSByZXR1cm4gW1tST09UX1RPS0VOXV07XG5cdGlmICghcGF0aC5zdGFydHNXaXRoKFwiL1wiKSkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IGBSb3V0ZSBwYXRocyBzaG91bGQgc3RhcnQgd2l0aCBhIFwiL1wiOiBcIiR7cGF0aH1cIiBzaG91bGQgYmUgXCIvJHtwYXRofVwiLmAgOiBgSW52YWxpZCBwYXRoIFwiJHtwYXRofVwiYCk7XG5cdGZ1bmN0aW9uIGNyYXNoKG1lc3NhZ2UpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEVSUiAoJHtzdGF0ZX0pL1wiJHtidWZmZXJ9XCI6ICR7bWVzc2FnZX1gKTtcblx0fVxuXHRsZXQgc3RhdGUgPSBUb2tlbml6ZXJTdGF0ZS5TdGF0aWM7XG5cdGxldCBwcmV2aW91c1N0YXRlID0gc3RhdGU7XG5cdGNvbnN0IHRva2VucyA9IFtdO1xuXHRsZXQgc2VnbWVudDtcblx0ZnVuY3Rpb24gZmluYWxpemVTZWdtZW50KCkge1xuXHRcdGlmIChzZWdtZW50KSB0b2tlbnMucHVzaChzZWdtZW50KTtcblx0XHRzZWdtZW50ID0gW107XG5cdH1cblx0bGV0IGkgPSAwO1xuXHRsZXQgY2hhcjtcblx0bGV0IGJ1ZmZlciA9IFwiXCI7XG5cdGxldCBjdXN0b21SZSA9IFwiXCI7XG5cdGZ1bmN0aW9uIGNvbnN1bWVCdWZmZXIoKSB7XG5cdFx0aWYgKCFidWZmZXIpIHJldHVybjtcblx0XHRpZiAoc3RhdGUgPT09IFRva2VuaXplclN0YXRlLlN0YXRpYykgc2VnbWVudC5wdXNoKHtcblx0XHRcdHR5cGU6IFRva2VuVHlwZS5TdGF0aWMsXG5cdFx0XHR2YWx1ZTogYnVmZmVyXG5cdFx0fSk7XG5cdFx0ZWxzZSBpZiAoc3RhdGUgPT09IFRva2VuaXplclN0YXRlLlBhcmFtIHx8IHN0YXRlID09PSBUb2tlbml6ZXJTdGF0ZS5QYXJhbVJlZ0V4cCB8fCBzdGF0ZSA9PT0gVG9rZW5pemVyU3RhdGUuUGFyYW1SZWdFeHBFbmQpIHtcblx0XHRcdGlmIChzZWdtZW50Lmxlbmd0aCA+IDEgJiYgKGNoYXIgPT09IFwiKlwiIHx8IGNoYXIgPT09IFwiK1wiKSkgY3Jhc2goYEEgcmVwZWF0YWJsZSBwYXJhbSAoJHtidWZmZXJ9KSBtdXN0IGJlIGFsb25lIGluIGl0cyBzZWdtZW50LiBlZzogJy86aWRzKy5gKTtcblx0XHRcdHNlZ21lbnQucHVzaCh7XG5cdFx0XHRcdHR5cGU6IFRva2VuVHlwZS5QYXJhbSxcblx0XHRcdFx0dmFsdWU6IGJ1ZmZlcixcblx0XHRcdFx0cmVnZXhwOiBjdXN0b21SZSxcblx0XHRcdFx0cmVwZWF0YWJsZTogY2hhciA9PT0gXCIqXCIgfHwgY2hhciA9PT0gXCIrXCIsXG5cdFx0XHRcdG9wdGlvbmFsOiBjaGFyID09PSBcIipcIiB8fCBjaGFyID09PSBcIj9cIlxuXHRcdFx0fSk7XG5cdFx0fSBlbHNlIGNyYXNoKFwiSW52YWxpZCBzdGF0ZSB0byBjb25zdW1lIGJ1ZmZlclwiKTtcblx0XHRidWZmZXIgPSBcIlwiO1xuXHR9XG5cdGZ1bmN0aW9uIGFkZENoYXJUb0J1ZmZlcigpIHtcblx0XHRidWZmZXIgKz0gY2hhcjtcblx0fVxuXHR3aGlsZSAoaSA8IHBhdGgubGVuZ3RoKSB7XG5cdFx0Y2hhciA9IHBhdGhbaSsrXTtcblx0XHRpZiAoY2hhciA9PT0gXCJcXFxcXCIgJiYgc3RhdGUgIT09IFRva2VuaXplclN0YXRlLlBhcmFtUmVnRXhwKSB7XG5cdFx0XHRwcmV2aW91c1N0YXRlID0gc3RhdGU7XG5cdFx0XHRzdGF0ZSA9IFRva2VuaXplclN0YXRlLkVzY2FwZU5leHQ7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0c3dpdGNoIChzdGF0ZSkge1xuXHRcdFx0Y2FzZSBUb2tlbml6ZXJTdGF0ZS5TdGF0aWM6XG5cdFx0XHRcdGlmIChjaGFyID09PSBcIi9cIikge1xuXHRcdFx0XHRcdGlmIChidWZmZXIpIGNvbnN1bWVCdWZmZXIoKTtcblx0XHRcdFx0XHRmaW5hbGl6ZVNlZ21lbnQoKTtcblx0XHRcdFx0fSBlbHNlIGlmIChjaGFyID09PSBcIjpcIikge1xuXHRcdFx0XHRcdGNvbnN1bWVCdWZmZXIoKTtcblx0XHRcdFx0XHRzdGF0ZSA9IFRva2VuaXplclN0YXRlLlBhcmFtO1xuXHRcdFx0XHR9IGVsc2UgYWRkQ2hhclRvQnVmZmVyKCk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSBUb2tlbml6ZXJTdGF0ZS5Fc2NhcGVOZXh0OlxuXHRcdFx0XHRhZGRDaGFyVG9CdWZmZXIoKTtcblx0XHRcdFx0c3RhdGUgPSBwcmV2aW91c1N0YXRlO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgVG9rZW5pemVyU3RhdGUuUGFyYW06XG5cdFx0XHRcdGlmIChjaGFyID09PSBcIihcIikgc3RhdGUgPSBUb2tlbml6ZXJTdGF0ZS5QYXJhbVJlZ0V4cDtcblx0XHRcdFx0ZWxzZSBpZiAoVkFMSURfUEFSQU1fUkUudGVzdChjaGFyKSkgYWRkQ2hhclRvQnVmZmVyKCk7XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGNvbnN1bWVCdWZmZXIoKTtcblx0XHRcdFx0XHRzdGF0ZSA9IFRva2VuaXplclN0YXRlLlN0YXRpYztcblx0XHRcdFx0XHRpZiAoY2hhciAhPT0gXCIqXCIgJiYgY2hhciAhPT0gXCI/XCIgJiYgY2hhciAhPT0gXCIrXCIpIGktLTtcblx0XHRcdFx0fVxuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgVG9rZW5pemVyU3RhdGUuUGFyYW1SZWdFeHA6XG5cdFx0XHRcdGlmIChjaGFyID09PSBcIilcIikgaWYgKGN1c3RvbVJlW2N1c3RvbVJlLmxlbmd0aCAtIDFdID09IFwiXFxcXFwiKSBjdXN0b21SZSA9IGN1c3RvbVJlLnNsaWNlKDAsIC0xKSArIGNoYXI7XG5cdFx0XHRcdGVsc2Ugc3RhdGUgPSBUb2tlbml6ZXJTdGF0ZS5QYXJhbVJlZ0V4cEVuZDtcblx0XHRcdFx0ZWxzZSBjdXN0b21SZSArPSBjaGFyO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgVG9rZW5pemVyU3RhdGUuUGFyYW1SZWdFeHBFbmQ6XG5cdFx0XHRcdGNvbnN1bWVCdWZmZXIoKTtcblx0XHRcdFx0c3RhdGUgPSBUb2tlbml6ZXJTdGF0ZS5TdGF0aWM7XG5cdFx0XHRcdGlmIChjaGFyICE9PSBcIipcIiAmJiBjaGFyICE9PSBcIj9cIiAmJiBjaGFyICE9PSBcIitcIikgaS0tO1xuXHRcdFx0XHRjdXN0b21SZSA9IFwiXCI7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0Y3Jhc2goXCJVbmtub3duIHN0YXRlXCIpO1xuXHRcdFx0XHRicmVhaztcblx0XHR9XG5cdH1cblx0aWYgKHN0YXRlID09PSBUb2tlbml6ZXJTdGF0ZS5QYXJhbVJlZ0V4cCkgY3Jhc2goYFVuZmluaXNoZWQgY3VzdG9tIFJlZ0V4cCBmb3IgcGFyYW0gXCIke2J1ZmZlcn1cImApO1xuXHRjb25zdW1lQnVmZmVyKCk7XG5cdGZpbmFsaXplU2VnbWVudCgpO1xuXHRyZXR1cm4gdG9rZW5zO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWF0Y2hlci9wYXRoUGFyc2VyUmFua2VyLnRzXG5jb25zdCBCQVNFX1BBUkFNX1BBVFRFUk4gPSBcIlteL10rP1wiO1xuY29uc3QgQkFTRV9QQVRIX1BBUlNFUl9PUFRJT05TID0ge1xuXHRzZW5zaXRpdmU6IGZhbHNlLFxuXHRzdHJpY3Q6IGZhbHNlLFxuXHRzdGFydDogdHJ1ZSxcblx0ZW5kOiB0cnVlXG59O1xudmFyIFBhdGhTY29yZSA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihQYXRoU2NvcmUkMSkge1xuXHRQYXRoU2NvcmUkMVtQYXRoU2NvcmUkMVtcIl9tdWx0aXBsaWVyXCJdID0gMTBdID0gXCJfbXVsdGlwbGllclwiO1xuXHRQYXRoU2NvcmUkMVtQYXRoU2NvcmUkMVtcIlJvb3RcIl0gPSA5MF0gPSBcIlJvb3RcIjtcblx0UGF0aFNjb3JlJDFbUGF0aFNjb3JlJDFbXCJTZWdtZW50XCJdID0gNDBdID0gXCJTZWdtZW50XCI7XG5cdFBhdGhTY29yZSQxW1BhdGhTY29yZSQxW1wiU3ViU2VnbWVudFwiXSA9IDMwXSA9IFwiU3ViU2VnbWVudFwiO1xuXHRQYXRoU2NvcmUkMVtQYXRoU2NvcmUkMVtcIlN0YXRpY1wiXSA9IDQwXSA9IFwiU3RhdGljXCI7XG5cdFBhdGhTY29yZSQxW1BhdGhTY29yZSQxW1wiRHluYW1pY1wiXSA9IDIwXSA9IFwiRHluYW1pY1wiO1xuXHRQYXRoU2NvcmUkMVtQYXRoU2NvcmUkMVtcIkJvbnVzQ3VzdG9tUmVnRXhwXCJdID0gMTBdID0gXCJCb251c0N1c3RvbVJlZ0V4cFwiO1xuXHRQYXRoU2NvcmUkMVtQYXRoU2NvcmUkMVtcIkJvbnVzV2lsZGNhcmRcIl0gPSAtNTBdID0gXCJCb251c1dpbGRjYXJkXCI7XG5cdFBhdGhTY29yZSQxW1BhdGhTY29yZSQxW1wiQm9udXNSZXBlYXRhYmxlXCJdID0gLTIwXSA9IFwiQm9udXNSZXBlYXRhYmxlXCI7XG5cdFBhdGhTY29yZSQxW1BhdGhTY29yZSQxW1wiQm9udXNPcHRpb25hbFwiXSA9IC04XSA9IFwiQm9udXNPcHRpb25hbFwiO1xuXHRQYXRoU2NvcmUkMVtQYXRoU2NvcmUkMVtcIkJvbnVzU3RyaWN0XCJdID0gLjcwMDAwMDAwMDAwMDAwMDFdID0gXCJCb251c1N0cmljdFwiO1xuXHRQYXRoU2NvcmUkMVtQYXRoU2NvcmUkMVtcIkJvbnVzQ2FzZVNlbnNpdGl2ZVwiXSA9IC4yNV0gPSBcIkJvbnVzQ2FzZVNlbnNpdGl2ZVwiO1xuXHRyZXR1cm4gUGF0aFNjb3JlJDE7XG59KFBhdGhTY29yZSB8fCB7fSk7XG5jb25zdCBSRUdFWF9DSEFSU19SRSA9IC9bLisqP14ke30oKVtcXF0vXFxcXF0vZztcbi8qKlxuKiBDcmVhdGVzIGEgcGF0aCBwYXJzZXIgZnJvbSBhbiBhcnJheSBvZiBTZWdtZW50cyAoYSBzZWdtZW50IGlzIGFuIGFycmF5IG9mIFRva2VucylcbipcbiogQHBhcmFtIHNlZ21lbnRzIC0gYXJyYXkgb2Ygc2VnbWVudHMgcmV0dXJuZWQgYnkgdG9rZW5pemVQYXRoXG4qIEBwYXJhbSBleHRyYU9wdGlvbnMgLSBvcHRpb25hbCBvcHRpb25zIGZvciB0aGUgcmVnZXhwXG4qIEByZXR1cm5zIGEgUGF0aFBhcnNlclxuKi9cbmZ1bmN0aW9uIHRva2Vuc1RvUGFyc2VyKHNlZ21lbnRzLCBleHRyYU9wdGlvbnMpIHtcblx0Y29uc3Qgb3B0aW9ucyA9IGFzc2lnbih7fSwgQkFTRV9QQVRIX1BBUlNFUl9PUFRJT05TLCBleHRyYU9wdGlvbnMpO1xuXHRjb25zdCBzY29yZSA9IFtdO1xuXHRsZXQgcGF0dGVybiA9IG9wdGlvbnMuc3RhcnQgPyBcIl5cIiA6IFwiXCI7XG5cdGNvbnN0IGtleXMgPSBbXTtcblx0Zm9yIChjb25zdCBzZWdtZW50IG9mIHNlZ21lbnRzKSB7XG5cdFx0Y29uc3Qgc2VnbWVudFNjb3JlcyA9IHNlZ21lbnQubGVuZ3RoID8gW10gOiBbUGF0aFNjb3JlLlJvb3RdO1xuXHRcdGlmIChvcHRpb25zLnN0cmljdCAmJiAhc2VnbWVudC5sZW5ndGgpIHBhdHRlcm4gKz0gXCIvXCI7XG5cdFx0Zm9yIChsZXQgdG9rZW5JbmRleCA9IDA7IHRva2VuSW5kZXggPCBzZWdtZW50Lmxlbmd0aDsgdG9rZW5JbmRleCsrKSB7XG5cdFx0XHRjb25zdCB0b2tlbiA9IHNlZ21lbnRbdG9rZW5JbmRleF07XG5cdFx0XHRsZXQgc3ViU2VnbWVudFNjb3JlID0gUGF0aFNjb3JlLlNlZ21lbnQgKyAob3B0aW9ucy5zZW5zaXRpdmUgPyBQYXRoU2NvcmUuQm9udXNDYXNlU2Vuc2l0aXZlIDogMCk7XG5cdFx0XHRpZiAodG9rZW4udHlwZSA9PT0gVG9rZW5UeXBlLlN0YXRpYykge1xuXHRcdFx0XHRpZiAoIXRva2VuSW5kZXgpIHBhdHRlcm4gKz0gXCIvXCI7XG5cdFx0XHRcdHBhdHRlcm4gKz0gdG9rZW4udmFsdWUucmVwbGFjZShSRUdFWF9DSEFSU19SRSwgXCJcXFxcJCZcIik7XG5cdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSBQYXRoU2NvcmUuU3RhdGljO1xuXHRcdFx0fSBlbHNlIGlmICh0b2tlbi50eXBlID09PSBUb2tlblR5cGUuUGFyYW0pIHtcblx0XHRcdFx0Y29uc3QgeyB2YWx1ZSwgcmVwZWF0YWJsZSwgb3B0aW9uYWwsIHJlZ2V4cCB9ID0gdG9rZW47XG5cdFx0XHRcdGtleXMucHVzaCh7XG5cdFx0XHRcdFx0bmFtZTogdmFsdWUsXG5cdFx0XHRcdFx0cmVwZWF0YWJsZSxcblx0XHRcdFx0XHRvcHRpb25hbFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0Y29uc3QgcmUkMSA9IHJlZ2V4cCA/IHJlZ2V4cCA6IEJBU0VfUEFSQU1fUEFUVEVSTjtcblx0XHRcdFx0aWYgKHJlJDEgIT09IEJBU0VfUEFSQU1fUEFUVEVSTikge1xuXHRcdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSBQYXRoU2NvcmUuQm9udXNDdXN0b21SZWdFeHA7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdGAke3JlJDF9YDtcblx0XHRcdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBjdXN0b20gUmVnRXhwIGZvciBwYXJhbSBcIiR7dmFsdWV9XCIgKCR7cmUkMX0pOiBgICsgZXJyLm1lc3NhZ2UpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRsZXQgc3ViUGF0dGVybiA9IHJlcGVhdGFibGUgPyBgKCg/OiR7cmUkMX0pKD86Lyg/OiR7cmUkMX0pKSopYCA6IGAoJHtyZSQxfSlgO1xuXHRcdFx0XHRpZiAoIXRva2VuSW5kZXgpIHN1YlBhdHRlcm4gPSBvcHRpb25hbCAmJiBzZWdtZW50Lmxlbmd0aCA8IDIgPyBgKD86LyR7c3ViUGF0dGVybn0pYCA6IFwiL1wiICsgc3ViUGF0dGVybjtcblx0XHRcdFx0aWYgKG9wdGlvbmFsKSBzdWJQYXR0ZXJuICs9IFwiP1wiO1xuXHRcdFx0XHRwYXR0ZXJuICs9IHN1YlBhdHRlcm47XG5cdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSBQYXRoU2NvcmUuRHluYW1pYztcblx0XHRcdFx0aWYgKG9wdGlvbmFsKSBzdWJTZWdtZW50U2NvcmUgKz0gUGF0aFNjb3JlLkJvbnVzT3B0aW9uYWw7XG5cdFx0XHRcdGlmIChyZXBlYXRhYmxlKSBzdWJTZWdtZW50U2NvcmUgKz0gUGF0aFNjb3JlLkJvbnVzUmVwZWF0YWJsZTtcblx0XHRcdFx0aWYgKHJlJDEgPT09IFwiLipcIikgc3ViU2VnbWVudFNjb3JlICs9IFBhdGhTY29yZS5Cb251c1dpbGRjYXJkO1xuXHRcdFx0fVxuXHRcdFx0c2VnbWVudFNjb3Jlcy5wdXNoKHN1YlNlZ21lbnRTY29yZSk7XG5cdFx0fVxuXHRcdHNjb3JlLnB1c2goc2VnbWVudFNjb3Jlcyk7XG5cdH1cblx0aWYgKG9wdGlvbnMuc3RyaWN0ICYmIG9wdGlvbnMuZW5kKSB7XG5cdFx0Y29uc3QgaSA9IHNjb3JlLmxlbmd0aCAtIDE7XG5cdFx0c2NvcmVbaV1bc2NvcmVbaV0ubGVuZ3RoIC0gMV0gKz0gUGF0aFNjb3JlLkJvbnVzU3RyaWN0O1xuXHR9XG5cdGlmICghb3B0aW9ucy5zdHJpY3QpIHBhdHRlcm4gKz0gXCIvP1wiO1xuXHRpZiAob3B0aW9ucy5lbmQpIHBhdHRlcm4gKz0gXCIkXCI7XG5cdGVsc2UgaWYgKG9wdGlvbnMuc3RyaWN0ICYmICFwYXR0ZXJuLmVuZHNXaXRoKFwiL1wiKSkgcGF0dGVybiArPSBcIig/Oi98JClcIjtcblx0Y29uc3QgcmUgPSBuZXcgUmVnRXhwKHBhdHRlcm4sIG9wdGlvbnMuc2Vuc2l0aXZlID8gXCJcIiA6IFwiaVwiKTtcblx0ZnVuY3Rpb24gcGFyc2UocGF0aCkge1xuXHRcdGNvbnN0IG1hdGNoID0gcGF0aC5tYXRjaChyZSk7XG5cdFx0Y29uc3QgcGFyYW1zID0ge307XG5cdFx0aWYgKCFtYXRjaCkgcmV0dXJuIG51bGw7XG5cdFx0Zm9yIChsZXQgaSA9IDE7IGkgPCBtYXRjaC5sZW5ndGg7IGkrKykge1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBtYXRjaFtpXSB8fCBcIlwiO1xuXHRcdFx0Y29uc3Qga2V5ID0ga2V5c1tpIC0gMV07XG5cdFx0XHRwYXJhbXNba2V5Lm5hbWVdID0gdmFsdWUgJiYga2V5LnJlcGVhdGFibGUgPyB2YWx1ZS5zcGxpdChcIi9cIikgOiB2YWx1ZTtcblx0XHR9XG5cdFx0cmV0dXJuIHBhcmFtcztcblx0fVxuXHRmdW5jdGlvbiBzdHJpbmdpZnkocGFyYW1zKSB7XG5cdFx0bGV0IHBhdGggPSBcIlwiO1xuXHRcdGxldCBhdm9pZER1cGxpY2F0ZWRTbGFzaCA9IGZhbHNlO1xuXHRcdGZvciAoY29uc3Qgc2VnbWVudCBvZiBzZWdtZW50cykge1xuXHRcdFx0aWYgKCFhdm9pZER1cGxpY2F0ZWRTbGFzaCB8fCAhcGF0aC5lbmRzV2l0aChcIi9cIikpIHBhdGggKz0gXCIvXCI7XG5cdFx0XHRhdm9pZER1cGxpY2F0ZWRTbGFzaCA9IGZhbHNlO1xuXHRcdFx0Zm9yIChjb25zdCB0b2tlbiBvZiBzZWdtZW50KSBpZiAodG9rZW4udHlwZSA9PT0gVG9rZW5UeXBlLlN0YXRpYykgcGF0aCArPSB0b2tlbi52YWx1ZTtcblx0XHRcdGVsc2UgaWYgKHRva2VuLnR5cGUgPT09IFRva2VuVHlwZS5QYXJhbSkge1xuXHRcdFx0XHRjb25zdCB7IHZhbHVlLCByZXBlYXRhYmxlLCBvcHRpb25hbCB9ID0gdG9rZW47XG5cdFx0XHRcdGNvbnN0IHBhcmFtID0gdmFsdWUgaW4gcGFyYW1zID8gcGFyYW1zW3ZhbHVlXSA6IFwiXCI7XG5cdFx0XHRcdGlmIChpc0FycmF5KHBhcmFtKSAmJiAhcmVwZWF0YWJsZSkgdGhyb3cgbmV3IEVycm9yKGBQcm92aWRlZCBwYXJhbSBcIiR7dmFsdWV9XCIgaXMgYW4gYXJyYXkgYnV0IGl0IGlzIG5vdCByZXBlYXRhYmxlICgqIG9yICsgbW9kaWZpZXJzKWApO1xuXHRcdFx0XHRjb25zdCB0ZXh0ID0gaXNBcnJheShwYXJhbSkgPyBwYXJhbS5qb2luKFwiL1wiKSA6IHBhcmFtO1xuXHRcdFx0XHRpZiAoIXRleHQpIGlmIChvcHRpb25hbCkge1xuXHRcdFx0XHRcdGlmIChzZWdtZW50Lmxlbmd0aCA8IDIpIGlmIChwYXRoLmVuZHNXaXRoKFwiL1wiKSkgcGF0aCA9IHBhdGguc2xpY2UoMCwgLTEpO1xuXHRcdFx0XHRcdGVsc2UgYXZvaWREdXBsaWNhdGVkU2xhc2ggPSB0cnVlO1xuXHRcdFx0XHR9IGVsc2UgdGhyb3cgbmV3IEVycm9yKGBNaXNzaW5nIHJlcXVpcmVkIHBhcmFtIFwiJHt2YWx1ZX1cImApO1xuXHRcdFx0XHRwYXRoICs9IHRleHQ7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBwYXRoIHx8IFwiL1wiO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0cmUsXG5cdFx0c2NvcmUsXG5cdFx0a2V5cyxcblx0XHRwYXJzZSxcblx0XHRzdHJpbmdpZnlcblx0fTtcbn1cbi8qKlxuKiBDb21wYXJlcyBhbiBhcnJheSBvZiBudW1iZXJzIGFzIHVzZWQgaW4gUGF0aFBhcnNlci5zY29yZSBhbmQgcmV0dXJucyBhXG4qIG51bWJlci4gVGhpcyBmdW5jdGlvbiBjYW4gYmUgdXNlZCB0byBgc29ydGAgYW4gYXJyYXlcbipcbiogQHBhcmFtIGEgLSBmaXJzdCBhcnJheSBvZiBudW1iZXJzXG4qIEBwYXJhbSBiIC0gc2Vjb25kIGFycmF5IG9mIG51bWJlcnNcbiogQHJldHVybnMgMCBpZiBib3RoIGFyZSBlcXVhbCwgPCAwIGlmIGEgc2hvdWxkIGJlIHNvcnRlZCBmaXJzdCwgPiAwIGlmIGJcbiogc2hvdWxkIGJlIHNvcnRlZCBmaXJzdFxuKi9cbmZ1bmN0aW9uIGNvbXBhcmVTY29yZUFycmF5KGEsIGIpIHtcblx0bGV0IGkgPSAwO1xuXHR3aGlsZSAoaSA8IGEubGVuZ3RoICYmIGkgPCBiLmxlbmd0aCkge1xuXHRcdGNvbnN0IGRpZmYgPSBiW2ldIC0gYVtpXTtcblx0XHRpZiAoZGlmZikgcmV0dXJuIGRpZmY7XG5cdFx0aSsrO1xuXHR9XG5cdGlmIChhLmxlbmd0aCA8IGIubGVuZ3RoKSByZXR1cm4gYS5sZW5ndGggPT09IDEgJiYgYVswXSA9PT0gUGF0aFNjb3JlLlN0YXRpYyArIFBhdGhTY29yZS5TZWdtZW50ID8gLTEgOiAxO1xuXHRlbHNlIGlmIChhLmxlbmd0aCA+IGIubGVuZ3RoKSByZXR1cm4gYi5sZW5ndGggPT09IDEgJiYgYlswXSA9PT0gUGF0aFNjb3JlLlN0YXRpYyArIFBhdGhTY29yZS5TZWdtZW50ID8gMSA6IC0xO1xuXHRyZXR1cm4gMDtcbn1cbi8qKlxuKiBDb21wYXJlIGZ1bmN0aW9uIHRoYXQgY2FuIGJlIHVzZWQgd2l0aCBgc29ydGAgdG8gc29ydCBhbiBhcnJheSBvZiBQYXRoUGFyc2VyXG4qXG4qIEBwYXJhbSBhIC0gZmlyc3QgUGF0aFBhcnNlclxuKiBAcGFyYW0gYiAtIHNlY29uZCBQYXRoUGFyc2VyXG4qIEByZXR1cm5zIDAgaWYgYm90aCBhcmUgZXF1YWwsIDwgMCBpZiBhIHNob3VsZCBiZSBzb3J0ZWQgZmlyc3QsID4gMCBpZiBiXG4qL1xuZnVuY3Rpb24gY29tcGFyZVBhdGhQYXJzZXJTY29yZShhLCBiKSB7XG5cdGxldCBpID0gMDtcblx0Y29uc3QgYVNjb3JlID0gYS5zY29yZTtcblx0Y29uc3QgYlNjb3JlID0gYi5zY29yZTtcblx0d2hpbGUgKGkgPCBhU2NvcmUubGVuZ3RoICYmIGkgPCBiU2NvcmUubGVuZ3RoKSB7XG5cdFx0Y29uc3QgY29tcCA9IGNvbXBhcmVTY29yZUFycmF5KGFTY29yZVtpXSwgYlNjb3JlW2ldKTtcblx0XHRpZiAoY29tcCkgcmV0dXJuIGNvbXA7XG5cdFx0aSsrO1xuXHR9XG5cdGlmIChNYXRoLmFicyhiU2NvcmUubGVuZ3RoIC0gYVNjb3JlLmxlbmd0aCkgPT09IDEpIHtcblx0XHRpZiAoaXNMYXN0U2NvcmVOZWdhdGl2ZShhU2NvcmUpKSByZXR1cm4gMTtcblx0XHRpZiAoaXNMYXN0U2NvcmVOZWdhdGl2ZShiU2NvcmUpKSByZXR1cm4gLTE7XG5cdH1cblx0cmV0dXJuIGJTY29yZS5sZW5ndGggLSBhU2NvcmUubGVuZ3RoO1xufVxuLyoqXG4qIFRoaXMgYWxsb3dzIGRldGVjdGluZyBzcGxhdHMgYXQgdGhlIGVuZCBvZiBhIHBhdGg6IC9ob21lLzppZCguKikqXG4qXG4qIEBwYXJhbSBzY29yZSAtIHNjb3JlIHRvIGNoZWNrXG4qIEByZXR1cm5zIHRydWUgaWYgdGhlIGxhc3QgZW50cnkgaXMgbmVnYXRpdmVcbiovXG5mdW5jdGlvbiBpc0xhc3RTY29yZU5lZ2F0aXZlKHNjb3JlKSB7XG5cdGNvbnN0IGxhc3QgPSBzY29yZVtzY29yZS5sZW5ndGggLSAxXTtcblx0cmV0dXJuIHNjb3JlLmxlbmd0aCA+IDAgJiYgbGFzdFtsYXN0Lmxlbmd0aCAtIDFdIDwgMDtcbn1cbmNvbnN0IFBBVEhfUEFSU0VSX09QVElPTlNfREVGQVVMVFMgPSB7XG5cdHN0cmljdDogZmFsc2UsXG5cdGVuZDogdHJ1ZSxcblx0c2Vuc2l0aXZlOiBmYWxzZVxufTtcblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21hdGNoZXIvcGF0aE1hdGNoZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlUmVjb3JkTWF0Y2hlcihyZWNvcmQsIHBhcmVudCwgb3B0aW9ucykge1xuXHRjb25zdCBwYXJzZXIgPSB0b2tlbnNUb1BhcnNlcih0b2tlbml6ZVBhdGgocmVjb3JkLnBhdGgpLCBvcHRpb25zKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGNvbnN0IGV4aXN0aW5nS2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0Zm9yIChjb25zdCBrZXkgb2YgcGFyc2VyLmtleXMpIHtcblx0XHRcdGlmIChleGlzdGluZ0tleXMuaGFzKGtleS5uYW1lKSkgd2FybiQxKGBGb3VuZCBkdXBsaWNhdGVkIHBhcmFtcyB3aXRoIG5hbWUgXCIke2tleS5uYW1lfVwiIGZvciBwYXRoIFwiJHtyZWNvcmQucGF0aH1cIi4gT25seSB0aGUgbGFzdCBvbmUgd2lsbCBiZSBhdmFpbGFibGUgb24gXCIkcm91dGUucGFyYW1zXCIuYCk7XG5cdFx0XHRleGlzdGluZ0tleXMuYWRkKGtleS5uYW1lKTtcblx0XHR9XG5cdH1cblx0Y29uc3QgbWF0Y2hlciA9IGFzc2lnbihwYXJzZXIsIHtcblx0XHRyZWNvcmQsXG5cdFx0cGFyZW50LFxuXHRcdGNoaWxkcmVuOiBbXSxcblx0XHRhbGlhczogW11cblx0fSk7XG5cdGlmIChwYXJlbnQpIHtcblx0XHRpZiAoIW1hdGNoZXIucmVjb3JkLmFsaWFzT2YgPT09ICFwYXJlbnQucmVjb3JkLmFsaWFzT2YpIHBhcmVudC5jaGlsZHJlbi5wdXNoKG1hdGNoZXIpO1xuXHR9XG5cdHJldHVybiBtYXRjaGVyO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWF0Y2hlci9pbmRleC50c1xuLyoqXG4qIENyZWF0ZXMgYSBSb3V0ZXIgTWF0Y2hlci5cbipcbiogQGludGVybmFsXG4qIEBwYXJhbSByb3V0ZXMgLSBhcnJheSBvZiBpbml0aWFsIHJvdXRlc1xuKiBAcGFyYW0gZ2xvYmFsT3B0aW9ucyAtIGdsb2JhbCByb3V0ZSBvcHRpb25zXG4qL1xuZnVuY3Rpb24gY3JlYXRlUm91dGVyTWF0Y2hlcihyb3V0ZXMsIGdsb2JhbE9wdGlvbnMpIHtcblx0Y29uc3QgbWF0Y2hlcnMgPSBbXTtcblx0Y29uc3QgbWF0Y2hlck1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGdsb2JhbE9wdGlvbnMgPSBtZXJnZU9wdGlvbnMoUEFUSF9QQVJTRVJfT1BUSU9OU19ERUZBVUxUUywgZ2xvYmFsT3B0aW9ucyk7XG5cdGZ1bmN0aW9uIGdldFJlY29yZE1hdGNoZXIobmFtZSkge1xuXHRcdHJldHVybiBtYXRjaGVyTWFwLmdldChuYW1lKTtcblx0fVxuXHRmdW5jdGlvbiBhZGRSb3V0ZShyZWNvcmQsIHBhcmVudCwgb3JpZ2luYWxSZWNvcmQpIHtcblx0XHRjb25zdCBpc1Jvb3RBZGQgPSAhb3JpZ2luYWxSZWNvcmQ7XG5cdFx0Y29uc3QgbWFpbk5vcm1hbGl6ZWRSZWNvcmQgPSBub3JtYWxpemVSb3V0ZVJlY29yZChyZWNvcmQpO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNoZWNrQ2hpbGRNaXNzaW5nTmFtZVdpdGhFbXB0eVBhdGgobWFpbk5vcm1hbGl6ZWRSZWNvcmQsIHBhcmVudCk7XG5cdFx0bWFpbk5vcm1hbGl6ZWRSZWNvcmQuYWxpYXNPZiA9IG9yaWdpbmFsUmVjb3JkICYmIG9yaWdpbmFsUmVjb3JkLnJlY29yZDtcblx0XHRjb25zdCBvcHRpb25zID0gbWVyZ2VPcHRpb25zKGdsb2JhbE9wdGlvbnMsIHJlY29yZCk7XG5cdFx0Y29uc3Qgbm9ybWFsaXplZFJlY29yZHMgPSBbbWFpbk5vcm1hbGl6ZWRSZWNvcmRdO1xuXHRcdGlmIChcImFsaWFzXCIgaW4gcmVjb3JkKSB7XG5cdFx0XHRjb25zdCBhbGlhc2VzID0gdHlwZW9mIHJlY29yZC5hbGlhcyA9PT0gXCJzdHJpbmdcIiA/IFtyZWNvcmQuYWxpYXNdIDogcmVjb3JkLmFsaWFzO1xuXHRcdFx0Zm9yIChjb25zdCBhbGlhcyBvZiBhbGlhc2VzKSBub3JtYWxpemVkUmVjb3Jkcy5wdXNoKG5vcm1hbGl6ZVJvdXRlUmVjb3JkKGFzc2lnbih7fSwgbWFpbk5vcm1hbGl6ZWRSZWNvcmQsIHtcblx0XHRcdFx0Y29tcG9uZW50czogb3JpZ2luYWxSZWNvcmQgPyBvcmlnaW5hbFJlY29yZC5yZWNvcmQuY29tcG9uZW50cyA6IG1haW5Ob3JtYWxpemVkUmVjb3JkLmNvbXBvbmVudHMsXG5cdFx0XHRcdHBhdGg6IGFsaWFzLFxuXHRcdFx0XHRhbGlhc09mOiBvcmlnaW5hbFJlY29yZCA/IG9yaWdpbmFsUmVjb3JkLnJlY29yZCA6IG1haW5Ob3JtYWxpemVkUmVjb3JkXG5cdFx0XHR9KSkpO1xuXHRcdH1cblx0XHRsZXQgbWF0Y2hlcjtcblx0XHRsZXQgb3JpZ2luYWxNYXRjaGVyO1xuXHRcdGZvciAoY29uc3Qgbm9ybWFsaXplZFJlY29yZCBvZiBub3JtYWxpemVkUmVjb3Jkcykge1xuXHRcdFx0Y29uc3QgeyBwYXRoIH0gPSBub3JtYWxpemVkUmVjb3JkO1xuXHRcdFx0aWYgKHBhcmVudCAmJiBwYXRoWzBdICE9PSBcIi9cIikge1xuXHRcdFx0XHRjb25zdCBwYXJlbnRQYXRoID0gcGFyZW50LnJlY29yZC5wYXRoO1xuXHRcdFx0XHRjb25zdCBjb25uZWN0aW5nU2xhc2ggPSBwYXJlbnRQYXRoW3BhcmVudFBhdGgubGVuZ3RoIC0gMV0gPT09IFwiL1wiID8gXCJcIiA6IFwiL1wiO1xuXHRcdFx0XHRub3JtYWxpemVkUmVjb3JkLnBhdGggPSBwYXJlbnQucmVjb3JkLnBhdGggKyAocGF0aCAmJiBjb25uZWN0aW5nU2xhc2ggKyBwYXRoKTtcblx0XHRcdH1cblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgbm9ybWFsaXplZFJlY29yZC5wYXRoID09PSBcIipcIikgdGhyb3cgbmV3IEVycm9yKFwiQ2F0Y2ggYWxsIHJvdXRlcyAoXFxcIipcXFwiKSBtdXN0IG5vdyBiZSBkZWZpbmVkIHVzaW5nIGEgcGFyYW0gd2l0aCBhIGN1c3RvbSByZWdleHAuXFxuU2VlIG1vcmUgYXQgaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL21pZ3JhdGlvbi8jUmVtb3ZlZC1zdGFyLW9yLWNhdGNoLWFsbC1yb3V0ZXMuXCIpO1xuXHRcdFx0bWF0Y2hlciA9IGNyZWF0ZVJvdXRlUmVjb3JkTWF0Y2hlcihub3JtYWxpemVkUmVjb3JkLCBwYXJlbnQsIG9wdGlvbnMpO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBwYXJlbnQgJiYgcGF0aFswXSA9PT0gXCIvXCIpIGNoZWNrTWlzc2luZ1BhcmFtc0luQWJzb2x1dGVQYXRoKG1hdGNoZXIsIHBhcmVudCk7XG5cdFx0XHRpZiAob3JpZ2luYWxSZWNvcmQpIHtcblx0XHRcdFx0b3JpZ2luYWxSZWNvcmQuYWxpYXMucHVzaChtYXRjaGVyKTtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY2hlY2tTYW1lUGFyYW1zKG9yaWdpbmFsUmVjb3JkLCBtYXRjaGVyKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdG9yaWdpbmFsTWF0Y2hlciA9IG9yaWdpbmFsTWF0Y2hlciB8fCBtYXRjaGVyO1xuXHRcdFx0XHRpZiAob3JpZ2luYWxNYXRjaGVyICE9PSBtYXRjaGVyKSBvcmlnaW5hbE1hdGNoZXIuYWxpYXMucHVzaChtYXRjaGVyKTtcblx0XHRcdFx0aWYgKGlzUm9vdEFkZCAmJiByZWNvcmQubmFtZSAmJiAhaXNBbGlhc1JlY29yZChtYXRjaGVyKSkge1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNoZWNrU2FtZU5hbWVBc0FuY2VzdG9yKHJlY29yZCwgcGFyZW50KTtcblx0XHRcdFx0XHRyZW1vdmVSb3V0ZShyZWNvcmQubmFtZSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChpc01hdGNoYWJsZShtYXRjaGVyKSkgaW5zZXJ0TWF0Y2hlcihtYXRjaGVyKTtcblx0XHRcdGlmIChtYWluTm9ybWFsaXplZFJlY29yZC5jaGlsZHJlbikge1xuXHRcdFx0XHRjb25zdCBjaGlsZHJlbiA9IG1haW5Ob3JtYWxpemVkUmVjb3JkLmNoaWxkcmVuO1xuXHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSBhZGRSb3V0ZShjaGlsZHJlbltpXSwgbWF0Y2hlciwgb3JpZ2luYWxSZWNvcmQgJiYgb3JpZ2luYWxSZWNvcmQuY2hpbGRyZW5baV0pO1xuXHRcdFx0fVxuXHRcdFx0b3JpZ2luYWxSZWNvcmQgPSBvcmlnaW5hbFJlY29yZCB8fCBtYXRjaGVyO1xuXHRcdH1cblx0XHRyZXR1cm4gb3JpZ2luYWxNYXRjaGVyID8gKCkgPT4ge1xuXHRcdFx0cmVtb3ZlUm91dGUob3JpZ2luYWxNYXRjaGVyKTtcblx0XHR9IDogbm9vcDtcblx0fVxuXHRmdW5jdGlvbiByZW1vdmVSb3V0ZShtYXRjaGVyUmVmKSB7XG5cdFx0aWYgKGlzUm91dGVOYW1lKG1hdGNoZXJSZWYpKSB7XG5cdFx0XHRjb25zdCBtYXRjaGVyID0gbWF0Y2hlck1hcC5nZXQobWF0Y2hlclJlZik7XG5cdFx0XHRpZiAobWF0Y2hlcikge1xuXHRcdFx0XHRtYXRjaGVyTWFwLmRlbGV0ZShtYXRjaGVyUmVmKTtcblx0XHRcdFx0bWF0Y2hlcnMuc3BsaWNlKG1hdGNoZXJzLmluZGV4T2YobWF0Y2hlciksIDEpO1xuXHRcdFx0XHRtYXRjaGVyLmNoaWxkcmVuLmZvckVhY2gocmVtb3ZlUm91dGUpO1xuXHRcdFx0XHRtYXRjaGVyLmFsaWFzLmZvckVhY2gocmVtb3ZlUm91dGUpO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBpbmRleCA9IG1hdGNoZXJzLmluZGV4T2YobWF0Y2hlclJlZik7XG5cdFx0XHRpZiAoaW5kZXggPiAtMSkge1xuXHRcdFx0XHRtYXRjaGVycy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0XHRpZiAobWF0Y2hlclJlZi5yZWNvcmQubmFtZSkgbWF0Y2hlck1hcC5kZWxldGUobWF0Y2hlclJlZi5yZWNvcmQubmFtZSk7XG5cdFx0XHRcdG1hdGNoZXJSZWYuY2hpbGRyZW4uZm9yRWFjaChyZW1vdmVSb3V0ZSk7XG5cdFx0XHRcdG1hdGNoZXJSZWYuYWxpYXMuZm9yRWFjaChyZW1vdmVSb3V0ZSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIGdldFJvdXRlcygpIHtcblx0XHRyZXR1cm4gbWF0Y2hlcnM7XG5cdH1cblx0ZnVuY3Rpb24gaW5zZXJ0TWF0Y2hlcihtYXRjaGVyKSB7XG5cdFx0Y29uc3QgaW5kZXggPSBmaW5kSW5zZXJ0aW9uSW5kZXgobWF0Y2hlciwgbWF0Y2hlcnMpO1xuXHRcdG1hdGNoZXJzLnNwbGljZShpbmRleCwgMCwgbWF0Y2hlcik7XG5cdFx0aWYgKG1hdGNoZXIucmVjb3JkLm5hbWUgJiYgIWlzQWxpYXNSZWNvcmQobWF0Y2hlcikpIG1hdGNoZXJNYXAuc2V0KG1hdGNoZXIucmVjb3JkLm5hbWUsIG1hdGNoZXIpO1xuXHR9XG5cdGZ1bmN0aW9uIHJlc29sdmUobG9jYXRpb24kMSwgY3VycmVudExvY2F0aW9uKSB7XG5cdFx0bGV0IG1hdGNoZXI7XG5cdFx0bGV0IHBhcmFtcyA9IHt9O1xuXHRcdGxldCBwYXRoO1xuXHRcdGxldCBuYW1lO1xuXHRcdGlmIChcIm5hbWVcIiBpbiBsb2NhdGlvbiQxICYmIGxvY2F0aW9uJDEubmFtZSkge1xuXHRcdFx0bWF0Y2hlciA9IG1hdGNoZXJNYXAuZ2V0KGxvY2F0aW9uJDEubmFtZSk7XG5cdFx0XHRpZiAoIW1hdGNoZXIpIHRocm93IGNyZWF0ZVJvdXRlckVycm9yKEVycm9yVHlwZXMuTUFUQ0hFUl9OT1RfRk9VTkQsIHsgbG9jYXRpb246IGxvY2F0aW9uJDEgfSk7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRcdGNvbnN0IGludmFsaWRQYXJhbXMgPSBPYmplY3Qua2V5cyhsb2NhdGlvbiQxLnBhcmFtcyB8fCB7fSkuZmlsdGVyKChwYXJhbU5hbWUpID0+ICFtYXRjaGVyLmtleXMuZmluZCgoaykgPT4gay5uYW1lID09PSBwYXJhbU5hbWUpKTtcblx0XHRcdFx0aWYgKGludmFsaWRQYXJhbXMubGVuZ3RoKSB3YXJuJDEoYERpc2NhcmRlZCBpbnZhbGlkIHBhcmFtKHMpIFwiJHtpbnZhbGlkUGFyYW1zLmpvaW4oXCJcXFwiLCBcXFwiXCIpfVwiIHdoZW4gbmF2aWdhdGluZy4gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvYmxvYi9tYWluL3BhY2thZ2VzL3JvdXRlci9DSEFOR0VMT0cubWQjNDE0LTIwMjItMDgtMjIgZm9yIG1vcmUgZGV0YWlscy5gKTtcblx0XHRcdH1cblx0XHRcdG5hbWUgPSBtYXRjaGVyLnJlY29yZC5uYW1lO1xuXHRcdFx0cGFyYW1zID0gYXNzaWduKHBpY2tQYXJhbXMoY3VycmVudExvY2F0aW9uLnBhcmFtcywgbWF0Y2hlci5rZXlzLmZpbHRlcigoaykgPT4gIWsub3B0aW9uYWwpLmNvbmNhdChtYXRjaGVyLnBhcmVudCA/IG1hdGNoZXIucGFyZW50LmtleXMuZmlsdGVyKChrKSA9PiBrLm9wdGlvbmFsKSA6IFtdKS5tYXAoKGspID0+IGsubmFtZSkpLCBsb2NhdGlvbiQxLnBhcmFtcyAmJiBwaWNrUGFyYW1zKGxvY2F0aW9uJDEucGFyYW1zLCBtYXRjaGVyLmtleXMubWFwKChrKSA9PiBrLm5hbWUpKSk7XG5cdFx0XHRwYXRoID0gbWF0Y2hlci5zdHJpbmdpZnkocGFyYW1zKTtcblx0XHR9IGVsc2UgaWYgKGxvY2F0aW9uJDEucGF0aCAhPSBudWxsKSB7XG5cdFx0XHRwYXRoID0gbG9jYXRpb24kMS5wYXRoO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhcGF0aC5zdGFydHNXaXRoKFwiL1wiKSkgd2FybiQxKGBUaGUgTWF0Y2hlciBjYW5ub3QgcmVzb2x2ZSByZWxhdGl2ZSBwYXRocyBidXQgcmVjZWl2ZWQgXCIke3BhdGh9XCIuIFVubGVzcyB5b3UgZGlyZWN0bHkgY2FsbGVkIFxcYG1hdGNoZXIucmVzb2x2ZShcIiR7cGF0aH1cIilcXGAsIHRoaXMgaXMgcHJvYmFibHkgYSBidWcgaW4gdnVlLXJvdXRlci4gUGxlYXNlIG9wZW4gYW4gaXNzdWUgYXQgaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL3JvdXRlci9pc3N1ZXMvbmV3L2Nob29zZS5gKTtcblx0XHRcdG1hdGNoZXIgPSBtYXRjaGVycy5maW5kKChtKSA9PiBtLnJlLnRlc3QocGF0aCkpO1xuXHRcdFx0aWYgKG1hdGNoZXIpIHtcblx0XHRcdFx0cGFyYW1zID0gbWF0Y2hlci5wYXJzZShwYXRoKTtcblx0XHRcdFx0bmFtZSA9IG1hdGNoZXIucmVjb3JkLm5hbWU7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdG1hdGNoZXIgPSBjdXJyZW50TG9jYXRpb24ubmFtZSA/IG1hdGNoZXJNYXAuZ2V0KGN1cnJlbnRMb2NhdGlvbi5uYW1lKSA6IG1hdGNoZXJzLmZpbmQoKG0pID0+IG0ucmUudGVzdChjdXJyZW50TG9jYXRpb24ucGF0aCkpO1xuXHRcdFx0aWYgKCFtYXRjaGVyKSB0aHJvdyBjcmVhdGVSb3V0ZXJFcnJvcihFcnJvclR5cGVzLk1BVENIRVJfTk9UX0ZPVU5ELCB7XG5cdFx0XHRcdGxvY2F0aW9uOiBsb2NhdGlvbiQxLFxuXHRcdFx0XHRjdXJyZW50TG9jYXRpb25cblx0XHRcdH0pO1xuXHRcdFx0bmFtZSA9IG1hdGNoZXIucmVjb3JkLm5hbWU7XG5cdFx0XHRwYXJhbXMgPSBhc3NpZ24oe30sIGN1cnJlbnRMb2NhdGlvbi5wYXJhbXMsIGxvY2F0aW9uJDEucGFyYW1zKTtcblx0XHRcdHBhdGggPSBtYXRjaGVyLnN0cmluZ2lmeShwYXJhbXMpO1xuXHRcdH1cblx0XHRjb25zdCBtYXRjaGVkID0gW107XG5cdFx0bGV0IHBhcmVudE1hdGNoZXIgPSBtYXRjaGVyO1xuXHRcdHdoaWxlIChwYXJlbnRNYXRjaGVyKSB7XG5cdFx0XHRtYXRjaGVkLnVuc2hpZnQocGFyZW50TWF0Y2hlci5yZWNvcmQpO1xuXHRcdFx0cGFyZW50TWF0Y2hlciA9IHBhcmVudE1hdGNoZXIucGFyZW50O1xuXHRcdH1cblx0XHRyZXR1cm4ge1xuXHRcdFx0bmFtZSxcblx0XHRcdHBhdGgsXG5cdFx0XHRwYXJhbXMsXG5cdFx0XHRtYXRjaGVkLFxuXHRcdFx0bWV0YTogbWVyZ2VNZXRhRmllbGRzKG1hdGNoZWQpXG5cdFx0fTtcblx0fVxuXHRyb3V0ZXMuZm9yRWFjaCgocm91dGUpID0+IGFkZFJvdXRlKHJvdXRlKSk7XG5cdGZ1bmN0aW9uIGNsZWFyUm91dGVzKCkge1xuXHRcdG1hdGNoZXJzLmxlbmd0aCA9IDA7XG5cdFx0bWF0Y2hlck1hcC5jbGVhcigpO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0YWRkUm91dGUsXG5cdFx0cmVzb2x2ZSxcblx0XHRyZW1vdmVSb3V0ZSxcblx0XHRjbGVhclJvdXRlcyxcblx0XHRnZXRSb3V0ZXMsXG5cdFx0Z2V0UmVjb3JkTWF0Y2hlclxuXHR9O1xufVxuLyoqXG4qIFBpY2tzIGFuIG9iamVjdCBwYXJhbSB0byBjb250YWluIG9ubHkgc3BlY2lmaWVkIGtleXMuXG4qXG4qIEBwYXJhbSBwYXJhbXMgLSBwYXJhbXMgb2JqZWN0IHRvIHBpY2sgZnJvbVxuKiBAcGFyYW0ga2V5cyAtIGtleXMgdG8gcGlja1xuKi9cbmZ1bmN0aW9uIHBpY2tQYXJhbXMocGFyYW1zLCBrZXlzKSB7XG5cdGNvbnN0IG5ld1BhcmFtcyA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBvZiBrZXlzKSBpZiAoa2V5IGluIHBhcmFtcykgbmV3UGFyYW1zW2tleV0gPSBwYXJhbXNba2V5XTtcblx0cmV0dXJuIG5ld1BhcmFtcztcbn1cbi8qKlxuKiBOb3JtYWxpemVzIGEgUm91dGVSZWNvcmRSYXcuIENyZWF0ZXMgYSBjb3B5XG4qXG4qIEBwYXJhbSByZWNvcmRcbiogQHJldHVybnMgdGhlIG5vcm1hbGl6ZWQgdmVyc2lvblxuKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJvdXRlUmVjb3JkKHJlY29yZCkge1xuXHRjb25zdCBub3JtYWxpemVkID0ge1xuXHRcdHBhdGg6IHJlY29yZC5wYXRoLFxuXHRcdHJlZGlyZWN0OiByZWNvcmQucmVkaXJlY3QsXG5cdFx0bmFtZTogcmVjb3JkLm5hbWUsXG5cdFx0bWV0YTogcmVjb3JkLm1ldGEgfHwge30sXG5cdFx0YWxpYXNPZjogcmVjb3JkLmFsaWFzT2YsXG5cdFx0YmVmb3JlRW50ZXI6IHJlY29yZC5iZWZvcmVFbnRlcixcblx0XHRwcm9wczogbm9ybWFsaXplUmVjb3JkUHJvcHMocmVjb3JkKSxcblx0XHRjaGlsZHJlbjogcmVjb3JkLmNoaWxkcmVuIHx8IFtdLFxuXHRcdGluc3RhbmNlczoge30sXG5cdFx0bGVhdmVHdWFyZHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG5cdFx0dXBkYXRlR3VhcmRzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuXHRcdGVudGVyQ2FsbGJhY2tzOiB7fSxcblx0XHRjb21wb25lbnRzOiBcImNvbXBvbmVudHNcIiBpbiByZWNvcmQgPyByZWNvcmQuY29tcG9uZW50cyB8fCBudWxsIDogcmVjb3JkLmNvbXBvbmVudCAmJiB7IGRlZmF1bHQ6IHJlY29yZC5jb21wb25lbnQgfVxuXHR9O1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkobm9ybWFsaXplZCwgXCJtb2RzXCIsIHsgdmFsdWU6IHt9IH0pO1xuXHRyZXR1cm4gbm9ybWFsaXplZDtcbn1cbi8qKlxuKiBOb3JtYWxpemUgdGhlIG9wdGlvbmFsIGBwcm9wc2AgaW4gYSByZWNvcmQgdG8gYWx3YXlzIGJlIGFuIG9iamVjdCBzaW1pbGFyIHRvXG4qIGNvbXBvbmVudHMuIEFsc28gYWNjZXB0IGEgYm9vbGVhbiBmb3IgY29tcG9uZW50cy5cbiogQHBhcmFtIHJlY29yZFxuKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJlY29yZFByb3BzKHJlY29yZCkge1xuXHRjb25zdCBwcm9wc09iamVjdCA9IHt9O1xuXHRjb25zdCBwcm9wcyA9IHJlY29yZC5wcm9wcyB8fCBmYWxzZTtcblx0aWYgKFwiY29tcG9uZW50XCIgaW4gcmVjb3JkKSBwcm9wc09iamVjdC5kZWZhdWx0ID0gcHJvcHM7XG5cdGVsc2UgZm9yIChjb25zdCBuYW1lIGluIHJlY29yZC5jb21wb25lbnRzKSBwcm9wc09iamVjdFtuYW1lXSA9IHR5cGVvZiBwcm9wcyA9PT0gXCJvYmplY3RcIiA/IHByb3BzW25hbWVdIDogcHJvcHM7XG5cdHJldHVybiBwcm9wc09iamVjdDtcbn1cbi8qKlxuKiBDaGVja3MgaWYgYSByZWNvcmQgb3IgYW55IG9mIGl0cyBwYXJlbnQgaXMgYW4gYWxpYXNcbiogQHBhcmFtIHJlY29yZFxuKi9cbmZ1bmN0aW9uIGlzQWxpYXNSZWNvcmQocmVjb3JkKSB7XG5cdHdoaWxlIChyZWNvcmQpIHtcblx0XHRpZiAocmVjb3JkLnJlY29yZC5hbGlhc09mKSByZXR1cm4gdHJ1ZTtcblx0XHRyZWNvcmQgPSByZWNvcmQucGFyZW50O1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn1cbi8qKlxuKiBNZXJnZSBtZXRhIGZpZWxkcyBvZiBhbiBhcnJheSBvZiByZWNvcmRzXG4qXG4qIEBwYXJhbSBtYXRjaGVkIC0gYXJyYXkgb2YgbWF0Y2hlZCByZWNvcmRzXG4qL1xuZnVuY3Rpb24gbWVyZ2VNZXRhRmllbGRzKG1hdGNoZWQpIHtcblx0cmV0dXJuIG1hdGNoZWQucmVkdWNlKChtZXRhLCByZWNvcmQpID0+IGFzc2lnbihtZXRhLCByZWNvcmQubWV0YSksIHt9KTtcbn1cbmZ1bmN0aW9uIGlzU2FtZVBhcmFtKGEsIGIpIHtcblx0cmV0dXJuIGEubmFtZSA9PT0gYi5uYW1lICYmIGEub3B0aW9uYWwgPT09IGIub3B0aW9uYWwgJiYgYS5yZXBlYXRhYmxlID09PSBiLnJlcGVhdGFibGU7XG59XG4vKipcbiogQ2hlY2sgaWYgYSBwYXRoIGFuZCBpdHMgYWxpYXMgaGF2ZSB0aGUgc2FtZSByZXF1aXJlZCBwYXJhbXNcbipcbiogQHBhcmFtIGEgLSBvcmlnaW5hbCByZWNvcmRcbiogQHBhcmFtIGIgLSBhbGlhcyByZWNvcmRcbiovXG5mdW5jdGlvbiBjaGVja1NhbWVQYXJhbXMoYSwgYikge1xuXHRmb3IgKGNvbnN0IGtleSBvZiBhLmtleXMpIGlmICgha2V5Lm9wdGlvbmFsICYmICFiLmtleXMuZmluZChpc1NhbWVQYXJhbS5iaW5kKG51bGwsIGtleSkpKSByZXR1cm4gd2FybiQxKGBBbGlhcyBcIiR7Yi5yZWNvcmQucGF0aH1cIiBhbmQgdGhlIG9yaWdpbmFsIHJlY29yZDogXCIke2EucmVjb3JkLnBhdGh9XCIgbXVzdCBoYXZlIHRoZSBleGFjdCBzYW1lIHBhcmFtIG5hbWVkIFwiJHtrZXkubmFtZX1cImApO1xuXHRmb3IgKGNvbnN0IGtleSBvZiBiLmtleXMpIGlmICgha2V5Lm9wdGlvbmFsICYmICFhLmtleXMuZmluZChpc1NhbWVQYXJhbS5iaW5kKG51bGwsIGtleSkpKSByZXR1cm4gd2FybiQxKGBBbGlhcyBcIiR7Yi5yZWNvcmQucGF0aH1cIiBhbmQgdGhlIG9yaWdpbmFsIHJlY29yZDogXCIke2EucmVjb3JkLnBhdGh9XCIgbXVzdCBoYXZlIHRoZSBleGFjdCBzYW1lIHBhcmFtIG5hbWVkIFwiJHtrZXkubmFtZX1cImApO1xufVxuLyoqXG4qIEEgcm91dGUgd2l0aCBhIG5hbWUgYW5kIGEgY2hpbGQgd2l0aCBhbiBlbXB0eSBwYXRoIHdpdGhvdXQgYSBuYW1lIHNob3VsZCB3YXJuIHdoZW4gYWRkaW5nIHRoZSByb3V0ZVxuKlxuKiBAcGFyYW0gbWFpbk5vcm1hbGl6ZWRSZWNvcmQgLSBSb3V0ZVJlY29yZE5vcm1hbGl6ZWRcbiogQHBhcmFtIHBhcmVudCAtIFJvdXRlUmVjb3JkTWF0Y2hlclxuKi9cbmZ1bmN0aW9uIGNoZWNrQ2hpbGRNaXNzaW5nTmFtZVdpdGhFbXB0eVBhdGgobWFpbk5vcm1hbGl6ZWRSZWNvcmQsIHBhcmVudCkge1xuXHRpZiAocGFyZW50ICYmIHBhcmVudC5yZWNvcmQubmFtZSAmJiAhbWFpbk5vcm1hbGl6ZWRSZWNvcmQubmFtZSAmJiAhbWFpbk5vcm1hbGl6ZWRSZWNvcmQucGF0aCkgd2FybiQxKGBUaGUgcm91dGUgbmFtZWQgXCIke1N0cmluZyhwYXJlbnQucmVjb3JkLm5hbWUpfVwiIGhhcyBhIGNoaWxkIHdpdGhvdXQgYSBuYW1lIGFuZCBhbiBlbXB0eSBwYXRoLiBVc2luZyB0aGF0IG5hbWUgd29uJ3QgcmVuZGVyIHRoZSBlbXB0eSBwYXRoIGNoaWxkIHNvIHlvdSBwcm9iYWJseSB3YW50IHRvIG1vdmUgdGhlIG5hbWUgdG8gdGhlIGNoaWxkIGluc3RlYWQuIElmIHRoaXMgaXMgaW50ZW50aW9uYWwsIGFkZCBhIG5hbWUgdG8gdGhlIGNoaWxkIHJvdXRlIHRvIHJlbW92ZSB0aGUgd2FybmluZy5gKTtcbn1cbmZ1bmN0aW9uIGNoZWNrU2FtZU5hbWVBc0FuY2VzdG9yKHJlY29yZCwgcGFyZW50KSB7XG5cdGZvciAobGV0IGFuY2VzdG9yID0gcGFyZW50OyBhbmNlc3RvcjsgYW5jZXN0b3IgPSBhbmNlc3Rvci5wYXJlbnQpIGlmIChhbmNlc3Rvci5yZWNvcmQubmFtZSA9PT0gcmVjb3JkLm5hbWUpIHRocm93IG5ldyBFcnJvcihgQSByb3V0ZSBuYW1lZCBcIiR7U3RyaW5nKHJlY29yZC5uYW1lKX1cIiBoYXMgYmVlbiBhZGRlZCBhcyBhICR7cGFyZW50ID09PSBhbmNlc3RvciA/IFwiY2hpbGRcIiA6IFwiZGVzY2VuZGFudFwifSBvZiBhIHJvdXRlIHdpdGggdGhlIHNhbWUgbmFtZS4gUm91dGUgbmFtZXMgbXVzdCBiZSB1bmlxdWUgYW5kIGEgbmVzdGVkIHJvdXRlIGNhbm5vdCB1c2UgdGhlIHNhbWUgbmFtZSBhcyBhbiBhbmNlc3Rvci5gKTtcbn1cbmZ1bmN0aW9uIGNoZWNrTWlzc2luZ1BhcmFtc0luQWJzb2x1dGVQYXRoKHJlY29yZCwgcGFyZW50KSB7XG5cdGZvciAoY29uc3Qga2V5IG9mIHBhcmVudC5rZXlzKSBpZiAoIXJlY29yZC5rZXlzLmZpbmQoaXNTYW1lUGFyYW0uYmluZChudWxsLCBrZXkpKSkgcmV0dXJuIHdhcm4kMShgQWJzb2x1dGUgcGF0aCBcIiR7cmVjb3JkLnJlY29yZC5wYXRofVwiIG11c3QgaGF2ZSB0aGUgZXhhY3Qgc2FtZSBwYXJhbSBuYW1lZCBcIiR7a2V5Lm5hbWV9XCIgYXMgaXRzIHBhcmVudCBcIiR7cGFyZW50LnJlY29yZC5wYXRofVwiLmApO1xufVxuLyoqXG4qIFBlcmZvcm1zIGEgYmluYXJ5IHNlYXJjaCB0byBmaW5kIHRoZSBjb3JyZWN0IGluc2VydGlvbiBpbmRleCBmb3IgYSBuZXcgbWF0Y2hlci5cbipcbiogTWF0Y2hlcnMgYXJlIHByaW1hcmlseSBzb3J0ZWQgYnkgdGhlaXIgc2NvcmUuIElmIHNjb3JlcyBhcmUgdGllZCB0aGVuIHdlIGFsc28gY29uc2lkZXIgcGFyZW50L2NoaWxkIHJlbGF0aW9uc2hpcHMsXG4qIHdpdGggZGVzY2VuZGFudHMgY29taW5nIGJlZm9yZSBhbmNlc3RvcnMuIElmIHRoZXJlJ3Mgc3RpbGwgYSB0aWUsIG5ldyByb3V0ZXMgYXJlIGluc2VydGVkIGFmdGVyIGV4aXN0aW5nIHJvdXRlcy5cbipcbiogQHBhcmFtIG1hdGNoZXIgLSBuZXcgbWF0Y2hlciB0byBiZSBpbnNlcnRlZFxuKiBAcGFyYW0gbWF0Y2hlcnMgLSBleGlzdGluZyBtYXRjaGVyc1xuKi9cbmZ1bmN0aW9uIGZpbmRJbnNlcnRpb25JbmRleChtYXRjaGVyLCBtYXRjaGVycykge1xuXHRsZXQgbG93ZXIgPSAwO1xuXHRsZXQgdXBwZXIgPSBtYXRjaGVycy5sZW5ndGg7XG5cdHdoaWxlIChsb3dlciAhPT0gdXBwZXIpIHtcblx0XHRjb25zdCBtaWQgPSBsb3dlciArIHVwcGVyID4+IDE7XG5cdFx0aWYgKGNvbXBhcmVQYXRoUGFyc2VyU2NvcmUobWF0Y2hlciwgbWF0Y2hlcnNbbWlkXSkgPCAwKSB1cHBlciA9IG1pZDtcblx0XHRlbHNlIGxvd2VyID0gbWlkICsgMTtcblx0fVxuXHRjb25zdCBpbnNlcnRpb25BbmNlc3RvciA9IGdldEluc2VydGlvbkFuY2VzdG9yKG1hdGNoZXIpO1xuXHRpZiAoaW5zZXJ0aW9uQW5jZXN0b3IpIHtcblx0XHR1cHBlciA9IG1hdGNoZXJzLmxhc3RJbmRleE9mKGluc2VydGlvbkFuY2VzdG9yLCB1cHBlciAtIDEpO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgdXBwZXIgPCAwKSB3YXJuJDEoYEZpbmRpbmcgYW5jZXN0b3Igcm91dGUgXCIke2luc2VydGlvbkFuY2VzdG9yLnJlY29yZC5wYXRofVwiIGZhaWxlZCBmb3IgXCIke21hdGNoZXIucmVjb3JkLnBhdGh9XCJgKTtcblx0fVxuXHRyZXR1cm4gdXBwZXI7XG59XG5mdW5jdGlvbiBnZXRJbnNlcnRpb25BbmNlc3RvcihtYXRjaGVyKSB7XG5cdGxldCBhbmNlc3RvciA9IG1hdGNoZXI7XG5cdHdoaWxlIChhbmNlc3RvciA9IGFuY2VzdG9yLnBhcmVudCkgaWYgKGlzTWF0Y2hhYmxlKGFuY2VzdG9yKSAmJiBjb21wYXJlUGF0aFBhcnNlclNjb3JlKG1hdGNoZXIsIGFuY2VzdG9yKSA9PT0gMCkgcmV0dXJuIGFuY2VzdG9yO1xufVxuLyoqXG4qIENoZWNrcyBpZiBhIG1hdGNoZXIgY2FuIGJlIHJlYWNoYWJsZS4gVGhpcyBtZWFucyBpZiBpdCdzIHBvc3NpYmxlIHRvIHJlYWNoIGl0IGFzIGEgcm91dGUuIEZvciBleGFtcGxlLCByb3V0ZXMgd2l0aG91dFxuKiBhIGNvbXBvbmVudCwgb3IgbmFtZSwgb3IgcmVkaXJlY3QsIGFyZSBqdXN0IHVzZWQgdG8gZ3JvdXAgb3RoZXIgcm91dGVzLlxuKiBAcGFyYW0gbWF0Y2hlclxuKiBAcGFyYW0gbWF0Y2hlci5yZWNvcmQgcmVjb3JkIG9mIHRoZSBtYXRjaGVyXG4qIEByZXR1cm5zXG4qL1xuZnVuY3Rpb24gaXNNYXRjaGFibGUoeyByZWNvcmQgfSkge1xuXHRyZXR1cm4gISEocmVjb3JkLm5hbWUgfHwgcmVjb3JkLmNvbXBvbmVudHMgJiYgT2JqZWN0LmtleXMocmVjb3JkLmNvbXBvbmVudHMpLmxlbmd0aCB8fCByZWNvcmQucmVkaXJlY3QpO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvUm91dGVyTGluay50c1xuLyoqXG4qIFJldHVybnMgdGhlIGludGVybmFsIGJlaGF2aW9yIG9mIGEge0BsaW5rIFJvdXRlckxpbmt9IHdpdGhvdXQgdGhlIHJlbmRlcmluZyBwYXJ0LlxuKlxuKiBAcGFyYW0gcHJvcHMgLSBhIGB0b2AgbG9jYXRpb24gYW5kIGFuIG9wdGlvbmFsIGByZXBsYWNlYCBmbGFnXG4qL1xuZnVuY3Rpb24gdXNlTGluayhwcm9wcykge1xuXHRjb25zdCByb3V0ZXIgPSBpbmplY3Qocm91dGVyS2V5KTtcblx0Y29uc3QgY3VycmVudFJvdXRlID0gaW5qZWN0KHJvdXRlTG9jYXRpb25LZXkpO1xuXHRsZXQgaGFzUHJldmlvdXMgPSBmYWxzZTtcblx0bGV0IHByZXZpb3VzVG8gPSBudWxsO1xuXHRjb25zdCByb3V0ZSA9IGNvbXB1dGVkKCgpID0+IHtcblx0XHRjb25zdCB0byA9IHVucmVmKHByb3BzLnRvKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICghaGFzUHJldmlvdXMgfHwgdG8gIT09IHByZXZpb3VzVG8pKSB7XG5cdFx0XHRpZiAoIWlzUm91dGVMb2NhdGlvbih0bykpIGlmIChoYXNQcmV2aW91cykgd2FybiQxKGBJbnZhbGlkIHZhbHVlIGZvciBwcm9wIFwidG9cIiBpbiB1c2VMaW5rKClcXG4tIHRvOmAsIHRvLCBgXFxuLSBwcmV2aW91cyB0bzpgLCBwcmV2aW91c1RvLCBgXFxuLSBwcm9wczpgLCBwcm9wcyk7XG5cdFx0XHRlbHNlIHdhcm4kMShgSW52YWxpZCB2YWx1ZSBmb3IgcHJvcCBcInRvXCIgaW4gdXNlTGluaygpXFxuLSB0bzpgLCB0bywgYFxcbi0gcHJvcHM6YCwgcHJvcHMpO1xuXHRcdFx0cHJldmlvdXNUbyA9IHRvO1xuXHRcdFx0aGFzUHJldmlvdXMgPSB0cnVlO1xuXHRcdH1cblx0XHRyZXR1cm4gcm91dGVyLnJlc29sdmUodG8pO1xuXHR9KTtcblx0Y29uc3QgYWN0aXZlUmVjb3JkSW5kZXggPSBjb21wdXRlZCgoKSA9PiB7XG5cdFx0Y29uc3QgeyBtYXRjaGVkIH0gPSByb3V0ZS52YWx1ZTtcblx0XHRjb25zdCB7IGxlbmd0aCB9ID0gbWF0Y2hlZDtcblx0XHRjb25zdCByb3V0ZU1hdGNoZWQgPSBtYXRjaGVkW2xlbmd0aCAtIDFdO1xuXHRcdGNvbnN0IGN1cnJlbnRNYXRjaGVkID0gY3VycmVudFJvdXRlLm1hdGNoZWQ7XG5cdFx0aWYgKCFyb3V0ZU1hdGNoZWQgfHwgIWN1cnJlbnRNYXRjaGVkLmxlbmd0aCkgcmV0dXJuIC0xO1xuXHRcdGNvbnN0IGluZGV4ID0gY3VycmVudE1hdGNoZWQuZmluZEluZGV4KGlzU2FtZVJvdXRlUmVjb3JkLmJpbmQobnVsbCwgcm91dGVNYXRjaGVkKSk7XG5cdFx0aWYgKGluZGV4ID4gLTEpIHJldHVybiBpbmRleDtcblx0XHRjb25zdCBwYXJlbnRSZWNvcmRQYXRoID0gZ2V0T3JpZ2luYWxQYXRoKG1hdGNoZWRbbGVuZ3RoIC0gMl0pO1xuXHRcdHJldHVybiBsZW5ndGggPiAxICYmIGdldE9yaWdpbmFsUGF0aChyb3V0ZU1hdGNoZWQpID09PSBwYXJlbnRSZWNvcmRQYXRoICYmIGN1cnJlbnRNYXRjaGVkW2N1cnJlbnRNYXRjaGVkLmxlbmd0aCAtIDFdLnBhdGggIT09IHBhcmVudFJlY29yZFBhdGggPyBjdXJyZW50TWF0Y2hlZC5maW5kSW5kZXgoaXNTYW1lUm91dGVSZWNvcmQuYmluZChudWxsLCBtYXRjaGVkW2xlbmd0aCAtIDJdKSkgOiBpbmRleDtcblx0fSk7XG5cdGNvbnN0IGlzQWN0aXZlID0gY29tcHV0ZWQoKCkgPT4gYWN0aXZlUmVjb3JkSW5kZXgudmFsdWUgPiAtMSAmJiBpbmNsdWRlc1BhcmFtcyhjdXJyZW50Um91dGUucGFyYW1zLCByb3V0ZS52YWx1ZS5wYXJhbXMpKTtcblx0Y29uc3QgaXNFeGFjdEFjdGl2ZSA9IGNvbXB1dGVkKCgpID0+IGFjdGl2ZVJlY29yZEluZGV4LnZhbHVlID4gLTEgJiYgYWN0aXZlUmVjb3JkSW5kZXgudmFsdWUgPT09IGN1cnJlbnRSb3V0ZS5tYXRjaGVkLmxlbmd0aCAtIDEgJiYgaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcyhjdXJyZW50Um91dGUucGFyYW1zLCByb3V0ZS52YWx1ZS5wYXJhbXMpKTtcblx0ZnVuY3Rpb24gbmF2aWdhdGUoZSA9IHt9KSB7XG5cdFx0aWYgKGd1YXJkRXZlbnQoZSkpIHtcblx0XHRcdGNvbnN0IHAgPSByb3V0ZXJbdW5yZWYocHJvcHMucmVwbGFjZSkgPyBcInJlcGxhY2VcIiA6IFwicHVzaFwiXSh1bnJlZihwcm9wcy50bykpLmNhdGNoKG5vb3ApO1xuXHRcdFx0aWYgKHByb3BzLnZpZXdUcmFuc2l0aW9uICYmIHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBcInN0YXJ0Vmlld1RyYW5zaXRpb25cIiBpbiBkb2N1bWVudCkgZG9jdW1lbnQuc3RhcnRWaWV3VHJhbnNpdGlvbigoKSA9PiBwKTtcblx0XHRcdHJldHVybiBwO1xuXHRcdH1cblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0aWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSAmJiBpc0Jyb3dzZXIpIHtcblx0XHRjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuXHRcdGlmIChpbnN0YW5jZSkge1xuXHRcdFx0Y29uc3QgbGlua0NvbnRleHREZXZ0b29scyA9IHtcblx0XHRcdFx0cm91dGU6IHJvdXRlLnZhbHVlLFxuXHRcdFx0XHRpc0FjdGl2ZTogaXNBY3RpdmUudmFsdWUsXG5cdFx0XHRcdGlzRXhhY3RBY3RpdmU6IGlzRXhhY3RBY3RpdmUudmFsdWUsXG5cdFx0XHRcdGVycm9yOiBudWxsXG5cdFx0XHR9O1xuXHRcdFx0aW5zdGFuY2UuX192cmxfZGV2dG9vbHMgPSBpbnN0YW5jZS5fX3ZybF9kZXZ0b29scyB8fCBbXTtcblx0XHRcdGluc3RhbmNlLl9fdnJsX2RldnRvb2xzLnB1c2gobGlua0NvbnRleHREZXZ0b29scyk7XG5cdFx0XHR3YXRjaEVmZmVjdCgoKSA9PiB7XG5cdFx0XHRcdGxpbmtDb250ZXh0RGV2dG9vbHMucm91dGUgPSByb3V0ZS52YWx1ZTtcblx0XHRcdFx0bGlua0NvbnRleHREZXZ0b29scy5pc0FjdGl2ZSA9IGlzQWN0aXZlLnZhbHVlO1xuXHRcdFx0XHRsaW5rQ29udGV4dERldnRvb2xzLmlzRXhhY3RBY3RpdmUgPSBpc0V4YWN0QWN0aXZlLnZhbHVlO1xuXHRcdFx0XHRsaW5rQ29udGV4dERldnRvb2xzLmVycm9yID0gaXNSb3V0ZUxvY2F0aW9uKHVucmVmKHByb3BzLnRvKSkgPyBudWxsIDogXCJJbnZhbGlkIFxcXCJ0b1xcXCIgdmFsdWVcIjtcblx0XHRcdH0sIHsgZmx1c2g6IFwicG9zdFwiIH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBOT1RFOiB1cGRhdGUge0BsaW5rIF9Sb3V0ZXJMaW5rSX0ncyBgJHNsb3RzYCB0eXBlIHdoZW4gdXBkYXRpbmcgdGhpc1xuXHQqL1xuXHRyZXR1cm4ge1xuXHRcdHJvdXRlLFxuXHRcdGhyZWY6IGNvbXB1dGVkKCgpID0+IHJvdXRlLnZhbHVlLmhyZWYpLFxuXHRcdGlzQWN0aXZlLFxuXHRcdGlzRXhhY3RBY3RpdmUsXG5cdFx0bmF2aWdhdGVcblx0fTtcbn1cbmZ1bmN0aW9uIHByZWZlclNpbmdsZVZOb2RlKHZub2Rlcykge1xuXHRyZXR1cm4gdm5vZGVzLmxlbmd0aCA9PT0gMSA/IHZub2Rlc1swXSA6IHZub2Rlcztcbn1cbmNvbnN0IFJvdXRlckxpbmtJbXBsID0gLyogQF9fUFVSRV9fICovIGRlZmluZUNvbXBvbmVudCh7XG5cdG5hbWU6IFwiUm91dGVyTGlua1wiLFxuXHRjb21wYXRDb25maWc6IHsgTU9ERTogMyB9LFxuXHRwcm9wczoge1xuXHRcdHRvOiB7XG5cdFx0XHR0eXBlOiBbU3RyaW5nLCBPYmplY3RdLFxuXHRcdFx0cmVxdWlyZWQ6IHRydWVcblx0XHR9LFxuXHRcdHJlcGxhY2U6IEJvb2xlYW4sXG5cdFx0YWN0aXZlQ2xhc3M6IFN0cmluZyxcblx0XHRleGFjdEFjdGl2ZUNsYXNzOiBTdHJpbmcsXG5cdFx0Y3VzdG9tOiBCb29sZWFuLFxuXHRcdGFyaWFDdXJyZW50VmFsdWU6IHtcblx0XHRcdHR5cGU6IFN0cmluZyxcblx0XHRcdGRlZmF1bHQ6IFwicGFnZVwiXG5cdFx0fSxcblx0XHR2aWV3VHJhbnNpdGlvbjogQm9vbGVhblxuXHR9LFxuXHR1c2VMaW5rLFxuXHRzZXR1cChwcm9wcywgeyBzbG90cyB9KSB7XG5cdFx0Y29uc3QgbGluayA9IHJlYWN0aXZlKHVzZUxpbmsocHJvcHMpKTtcblx0XHRjb25zdCB7IG9wdGlvbnMgfSA9IGluamVjdChyb3V0ZXJLZXkpO1xuXHRcdGNvbnN0IGVsQ2xhc3MgPSBjb21wdXRlZCgoKSA9PiAoe1xuXHRcdFx0W2dldExpbmtDbGFzcyhwcm9wcy5hY3RpdmVDbGFzcywgb3B0aW9ucy5saW5rQWN0aXZlQ2xhc3MsIFwicm91dGVyLWxpbmstYWN0aXZlXCIpXTogbGluay5pc0FjdGl2ZSxcblx0XHRcdFtnZXRMaW5rQ2xhc3MocHJvcHMuZXhhY3RBY3RpdmVDbGFzcywgb3B0aW9ucy5saW5rRXhhY3RBY3RpdmVDbGFzcywgXCJyb3V0ZXItbGluay1leGFjdC1hY3RpdmVcIildOiBsaW5rLmlzRXhhY3RBY3RpdmVcblx0XHR9KSk7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IGNoaWxkcmVuID0gc2xvdHMuZGVmYXVsdCAmJiBwcmVmZXJTaW5nbGVWTm9kZShzbG90cy5kZWZhdWx0KGxpbmspKTtcblx0XHRcdHJldHVybiBwcm9wcy5jdXN0b20gPyBjaGlsZHJlbiA6IGgoXCJhXCIsIHtcblx0XHRcdFx0XCJhcmlhLWN1cnJlbnRcIjogbGluay5pc0V4YWN0QWN0aXZlID8gcHJvcHMuYXJpYUN1cnJlbnRWYWx1ZSA6IG51bGwsXG5cdFx0XHRcdGhyZWY6IGxpbmsuaHJlZixcblx0XHRcdFx0b25DbGljazogbGluay5uYXZpZ2F0ZSxcblx0XHRcdFx0Y2xhc3M6IGVsQ2xhc3MudmFsdWVcblx0XHRcdH0sIGNoaWxkcmVuKTtcblx0XHR9O1xuXHR9XG59KTtcbi8qKlxuKiBDb21wb25lbnQgdG8gcmVuZGVyIGEgbGluayB0aGF0IHRyaWdnZXJzIGEgbmF2aWdhdGlvbiBvbiBjbGljay5cbiovXG5jb25zdCBSb3V0ZXJMaW5rID0gUm91dGVyTGlua0ltcGw7XG5mdW5jdGlvbiBndWFyZEV2ZW50KGUpIHtcblx0aWYgKGUubWV0YUtleSB8fCBlLmFsdEtleSB8fCBlLmN0cmxLZXkgfHwgZS5zaGlmdEtleSkgcmV0dXJuO1xuXHRpZiAoZS5kZWZhdWx0UHJldmVudGVkKSByZXR1cm47XG5cdGlmIChlLmJ1dHRvbiAhPT0gdm9pZCAwICYmIGUuYnV0dG9uICE9PSAwKSByZXR1cm47XG5cdGlmIChlLmN1cnJlbnRUYXJnZXQgJiYgZS5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSkge1xuXHRcdGNvbnN0IHRhcmdldCA9IGUuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUoXCJ0YXJnZXRcIik7XG5cdFx0aWYgKC9cXGJfYmxhbmtcXGIvaS50ZXN0KHRhcmdldCkpIHJldHVybjtcblx0fVxuXHRpZiAoZS5wcmV2ZW50RGVmYXVsdCkgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGluY2x1ZGVzUGFyYW1zKG91dGVyLCBpbm5lcikge1xuXHRmb3IgKGNvbnN0IGtleSBpbiBpbm5lcikge1xuXHRcdGNvbnN0IGlubmVyVmFsdWUgPSBpbm5lcltrZXldO1xuXHRcdGNvbnN0IG91dGVyVmFsdWUgPSBvdXRlcltrZXldO1xuXHRcdGlmICh0eXBlb2YgaW5uZXJWYWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0aWYgKGlubmVyVmFsdWUgIT09IG91dGVyVmFsdWUpIHJldHVybiBmYWxzZTtcblx0XHR9IGVsc2UgaWYgKCFpc0FycmF5KG91dGVyVmFsdWUpIHx8IG91dGVyVmFsdWUubGVuZ3RoICE9PSBpbm5lclZhbHVlLmxlbmd0aCB8fCBpbm5lclZhbHVlLnNvbWUoKHZhbHVlLCBpKSA9PiB2YWx1ZS52YWx1ZU9mKCkgIT09IG91dGVyVmFsdWVbaV0udmFsdWVPZigpKSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdHJldHVybiB0cnVlO1xufVxuLyoqXG4qIEdldCB0aGUgb3JpZ2luYWwgcGF0aCB2YWx1ZSBvZiBhIHJlY29yZCBieSBmb2xsb3dpbmcgaXRzIGFsaWFzT2ZcbiogQHBhcmFtIHJlY29yZFxuKi9cbmZ1bmN0aW9uIGdldE9yaWdpbmFsUGF0aChyZWNvcmQpIHtcblx0cmV0dXJuIHJlY29yZCA/IHJlY29yZC5hbGlhc09mID8gcmVjb3JkLmFsaWFzT2YucGF0aCA6IHJlY29yZC5wYXRoIDogXCJcIjtcbn1cbi8qKlxuKiBVdGlsaXR5IGNsYXNzIHRvIGdldCB0aGUgYWN0aXZlIGNsYXNzIGJhc2VkIG9uIGRlZmF1bHRzLlxuKiBAcGFyYW0gcHJvcENsYXNzXG4qIEBwYXJhbSBnbG9iYWxDbGFzc1xuKiBAcGFyYW0gZGVmYXVsdENsYXNzXG4qL1xuY29uc3QgZ2V0TGlua0NsYXNzID0gKHByb3BDbGFzcywgZ2xvYmFsQ2xhc3MsIGRlZmF1bHRDbGFzcykgPT4gcHJvcENsYXNzICE9IG51bGwgPyBwcm9wQ2xhc3MgOiBnbG9iYWxDbGFzcyAhPSBudWxsID8gZ2xvYmFsQ2xhc3MgOiBkZWZhdWx0Q2xhc3M7XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9Sb3V0ZXJWaWV3LnRzXG5jb25zdCBSb3V0ZXJWaWV3SW1wbCA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVDb21wb25lbnQoe1xuXHRuYW1lOiBcIlJvdXRlclZpZXdcIixcblx0aW5oZXJpdEF0dHJzOiBmYWxzZSxcblx0cHJvcHM6IHtcblx0XHRuYW1lOiB7XG5cdFx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0XHRkZWZhdWx0OiBcImRlZmF1bHRcIlxuXHRcdH0sXG5cdFx0cm91dGU6IE9iamVjdFxuXHR9LFxuXHRjb21wYXRDb25maWc6IHsgTU9ERTogMyB9LFxuXHRzZXR1cChwcm9wcywgeyBhdHRycywgc2xvdHMgfSkge1xuXHRcdHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiB3YXJuRGVwcmVjYXRlZFVzYWdlKCk7XG5cdFx0Y29uc3QgaW5qZWN0ZWRSb3V0ZSA9IGluamVjdChyb3V0ZXJWaWV3TG9jYXRpb25LZXkpO1xuXHRcdGNvbnN0IHJvdXRlVG9EaXNwbGF5ID0gY29tcHV0ZWQoKCkgPT4gcHJvcHMucm91dGUgfHwgaW5qZWN0ZWRSb3V0ZS52YWx1ZSk7XG5cdFx0Y29uc3QgaW5qZWN0ZWREZXB0aCA9IGluamVjdCh2aWV3RGVwdGhLZXksIDApO1xuXHRcdGNvbnN0IGRlcHRoID0gY29tcHV0ZWQoKCkgPT4ge1xuXHRcdFx0bGV0IGluaXRpYWxEZXB0aCA9IHVucmVmKGluamVjdGVkRGVwdGgpO1xuXHRcdFx0Y29uc3QgeyBtYXRjaGVkIH0gPSByb3V0ZVRvRGlzcGxheS52YWx1ZTtcblx0XHRcdGxldCBtYXRjaGVkUm91dGU7XG5cdFx0XHR3aGlsZSAoKG1hdGNoZWRSb3V0ZSA9IG1hdGNoZWRbaW5pdGlhbERlcHRoXSkgJiYgIW1hdGNoZWRSb3V0ZS5jb21wb25lbnRzKSBpbml0aWFsRGVwdGgrKztcblx0XHRcdHJldHVybiBpbml0aWFsRGVwdGg7XG5cdFx0fSk7XG5cdFx0Y29uc3QgbWF0Y2hlZFJvdXRlUmVmID0gY29tcHV0ZWQoKCkgPT4gcm91dGVUb0Rpc3BsYXkudmFsdWUubWF0Y2hlZFtkZXB0aC52YWx1ZV0pO1xuXHRcdHByb3ZpZGUodmlld0RlcHRoS2V5LCBjb21wdXRlZCgoKSA9PiBkZXB0aC52YWx1ZSArIDEpKTtcblx0XHRwcm92aWRlKG1hdGNoZWRSb3V0ZUtleSwgbWF0Y2hlZFJvdXRlUmVmKTtcblx0XHRwcm92aWRlKHJvdXRlclZpZXdMb2NhdGlvbktleSwgcm91dGVUb0Rpc3BsYXkpO1xuXHRcdGNvbnN0IHZpZXdSZWYgPSByZWYoKTtcblx0XHR3YXRjaCgoKSA9PiBbXG5cdFx0XHR2aWV3UmVmLnZhbHVlLFxuXHRcdFx0bWF0Y2hlZFJvdXRlUmVmLnZhbHVlLFxuXHRcdFx0cHJvcHMubmFtZVxuXHRcdF0sIChbaW5zdGFuY2UsIHRvLCBuYW1lXSwgW29sZEluc3RhbmNlLCBmcm9tLCBvbGROYW1lXSkgPT4ge1xuXHRcdFx0aWYgKHRvKSB7XG5cdFx0XHRcdHRvLmluc3RhbmNlc1tuYW1lXSA9IGluc3RhbmNlO1xuXHRcdFx0XHRpZiAoZnJvbSAmJiBmcm9tICE9PSB0byAmJiBpbnN0YW5jZSAmJiBpbnN0YW5jZSA9PT0gb2xkSW5zdGFuY2UpIHtcblx0XHRcdFx0XHRpZiAoIXRvLmxlYXZlR3VhcmRzLnNpemUpIHRvLmxlYXZlR3VhcmRzID0gZnJvbS5sZWF2ZUd1YXJkcztcblx0XHRcdFx0XHRpZiAoIXRvLnVwZGF0ZUd1YXJkcy5zaXplKSB0by51cGRhdGVHdWFyZHMgPSBmcm9tLnVwZGF0ZUd1YXJkcztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGluc3RhbmNlICYmIHRvICYmICghZnJvbSB8fCAhaXNTYW1lUm91dGVSZWNvcmQodG8sIGZyb20pIHx8ICFvbGRJbnN0YW5jZSkpICh0by5lbnRlckNhbGxiYWNrc1tuYW1lXSB8fCBbXSkuZm9yRWFjaCgoY2FsbGJhY2spID0+IGNhbGxiYWNrKGluc3RhbmNlKSk7XG5cdFx0fSwgeyBmbHVzaDogXCJwb3N0XCIgfSk7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IHJvdXRlID0gcm91dGVUb0Rpc3BsYXkudmFsdWU7XG5cdFx0XHRjb25zdCBjdXJyZW50TmFtZSA9IHByb3BzLm5hbWU7XG5cdFx0XHRjb25zdCBtYXRjaGVkUm91dGUgPSBtYXRjaGVkUm91dGVSZWYudmFsdWU7XG5cdFx0XHRjb25zdCBWaWV3Q29tcG9uZW50ID0gbWF0Y2hlZFJvdXRlICYmIG1hdGNoZWRSb3V0ZS5jb21wb25lbnRzW2N1cnJlbnROYW1lXTtcblx0XHRcdGlmICghVmlld0NvbXBvbmVudCkgcmV0dXJuIG5vcm1hbGl6ZVNsb3Qoc2xvdHMuZGVmYXVsdCwge1xuXHRcdFx0XHRDb21wb25lbnQ6IFZpZXdDb21wb25lbnQsXG5cdFx0XHRcdHJvdXRlXG5cdFx0XHR9KTtcblx0XHRcdGNvbnN0IHJvdXRlUHJvcHNPcHRpb24gPSBtYXRjaGVkUm91dGUucHJvcHNbY3VycmVudE5hbWVdO1xuXHRcdFx0Y29uc3Qgcm91dGVQcm9wcyA9IHJvdXRlUHJvcHNPcHRpb24gPyByb3V0ZVByb3BzT3B0aW9uID09PSB0cnVlID8gcm91dGUucGFyYW1zIDogdHlwZW9mIHJvdXRlUHJvcHNPcHRpb24gPT09IFwiZnVuY3Rpb25cIiA/IHJvdXRlUHJvcHNPcHRpb24ocm91dGUpIDogcm91dGVQcm9wc09wdGlvbiA6IG51bGw7XG5cdFx0XHRjb25zdCBvblZub2RlVW5tb3VudGVkID0gKHZub2RlKSA9PiB7XG5cdFx0XHRcdGlmICh2bm9kZS5jb21wb25lbnQuaXNVbm1vdW50ZWQpIG1hdGNoZWRSb3V0ZS5pbnN0YW5jZXNbY3VycmVudE5hbWVdID0gbnVsbDtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBjb21wb25lbnQgPSBoKFZpZXdDb21wb25lbnQsIGFzc2lnbih7fSwgcm91dGVQcm9wcywgYXR0cnMsIHtcblx0XHRcdFx0b25Wbm9kZVVubW91bnRlZCxcblx0XHRcdFx0cmVmOiB2aWV3UmVmXG5cdFx0XHR9KSk7XG5cdFx0XHRpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIGlzQnJvd3NlciAmJiBjb21wb25lbnQucmVmKSB7XG5cdFx0XHRcdGNvbnN0IGluZm8gPSB7XG5cdFx0XHRcdFx0ZGVwdGg6IGRlcHRoLnZhbHVlLFxuXHRcdFx0XHRcdG5hbWU6IG1hdGNoZWRSb3V0ZS5uYW1lLFxuXHRcdFx0XHRcdHBhdGg6IG1hdGNoZWRSb3V0ZS5wYXRoLFxuXHRcdFx0XHRcdG1ldGE6IG1hdGNoZWRSb3V0ZS5tZXRhXG5cdFx0XHRcdH07XG5cdFx0XHRcdChpc0FycmF5KGNvbXBvbmVudC5yZWYpID8gY29tcG9uZW50LnJlZi5tYXAoKHIpID0+IHIuaSkgOiBbY29tcG9uZW50LnJlZi5pXSkuZm9yRWFjaCgoaW5zdGFuY2UpID0+IHtcblx0XHRcdFx0XHRpbnN0YW5jZS5fX3Zydl9kZXZ0b29scyA9IGluZm87XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIG5vcm1hbGl6ZVNsb3Qoc2xvdHMuZGVmYXVsdCwge1xuXHRcdFx0XHRDb21wb25lbnQ6IGNvbXBvbmVudCxcblx0XHRcdFx0cm91dGVcblx0XHRcdH0pIHx8IGNvbXBvbmVudDtcblx0XHR9O1xuXHR9XG59KTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZVNsb3Qoc2xvdCwgZGF0YSkge1xuXHRpZiAoIXNsb3QpIHJldHVybiBudWxsO1xuXHRjb25zdCBzbG90Q29udGVudCA9IHNsb3QoZGF0YSk7XG5cdHJldHVybiBzbG90Q29udGVudC5sZW5ndGggPT09IDEgPyBzbG90Q29udGVudFswXSA6IHNsb3RDb250ZW50O1xufVxuLyoqXG4qIENvbXBvbmVudCB0byBkaXNwbGF5IHRoZSBjdXJyZW50IHJvdXRlIHRoZSB1c2VyIGlzIGF0LlxuKi9cbmNvbnN0IFJvdXRlclZpZXcgPSBSb3V0ZXJWaWV3SW1wbDtcbmZ1bmN0aW9uIHdhcm5EZXByZWNhdGVkVXNhZ2UoKSB7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG5cdGNvbnN0IHBhcmVudE5hbWUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnR5cGUubmFtZTtcblx0Y29uc3QgcGFyZW50U3ViVHJlZVR5cGUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUudHlwZTtcblx0aWYgKHBhcmVudE5hbWUgJiYgKHBhcmVudE5hbWUgPT09IFwiS2VlcEFsaXZlXCIgfHwgcGFyZW50TmFtZS5pbmNsdWRlcyhcIlRyYW5zaXRpb25cIikpICYmIHR5cGVvZiBwYXJlbnRTdWJUcmVlVHlwZSA9PT0gXCJvYmplY3RcIiAmJiBwYXJlbnRTdWJUcmVlVHlwZS5uYW1lID09PSBcIlJvdXRlclZpZXdcIikge1xuXHRcdGNvbnN0IGNvbXAgPSBwYXJlbnROYW1lID09PSBcIktlZXBBbGl2ZVwiID8gXCJrZWVwLWFsaXZlXCIgOiBcInRyYW5zaXRpb25cIjtcblx0XHR3YXJuJDEoYDxyb3V0ZXItdmlldz4gY2FuIG5vIGxvbmdlciBiZSB1c2VkIGRpcmVjdGx5IGluc2lkZSA8dHJhbnNpdGlvbj4gb3IgPGtlZXAtYWxpdmU+LlxuVXNlIHNsb3QgcHJvcHMgaW5zdGVhZDpcblxuPHJvdXRlci12aWV3IHYtc2xvdD1cInsgQ29tcG9uZW50IH1cIj5cbiAgPCR7Y29tcH0+XFxuICAgIDxjb21wb25lbnQgOmlzPVwiQ29tcG9uZW50XCIgLz5cXG4gIDwvJHtjb21wfT5cXG48L3JvdXRlci12aWV3PmApO1xuXHR9XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9yb3V0ZXIudHNcbi8qKlxuKiBDcmVhdGVzIGEgUm91dGVyIGluc3RhbmNlIHRoYXQgY2FuIGJlIHVzZWQgYnkgYSBWdWUgYXBwLlxuKlxuKiBAcGFyYW0gb3B0aW9ucyAtIHtAbGluayBSb3V0ZXJPcHRpb25zfVxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlcihvcHRpb25zKSB7XG5cdGNvbnN0IG1hdGNoZXIgPSBjcmVhdGVSb3V0ZXJNYXRjaGVyKG9wdGlvbnMucm91dGVzLCBvcHRpb25zKTtcblx0Y29uc3QgcGFyc2VRdWVyeSQxID0gb3B0aW9ucy5wYXJzZVF1ZXJ5IHx8IHBhcnNlUXVlcnk7XG5cdGNvbnN0IHN0cmluZ2lmeVF1ZXJ5JDEgPSBvcHRpb25zLnN0cmluZ2lmeVF1ZXJ5IHx8IHN0cmluZ2lmeVF1ZXJ5O1xuXHRjb25zdCByb3V0ZXJIaXN0b3J5ID0gb3B0aW9ucy5oaXN0b3J5O1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFyb3V0ZXJIaXN0b3J5KSB0aHJvdyBuZXcgRXJyb3IoXCJQcm92aWRlIHRoZSBcXFwiaGlzdG9yeVxcXCIgb3B0aW9uIHdoZW4gY2FsbGluZyBcXFwiY3JlYXRlUm91dGVyKClcXFwiOiBodHRwczovL3JvdXRlci52dWVqcy5vcmcvYXBpL2ludGVyZmFjZXMvUm91dGVyT3B0aW9ucy5odG1sI2hpc3RvcnlcIik7XG5cdGNvbnN0IGJlZm9yZUd1YXJkcyA9IHVzZUNhbGxiYWNrcygpO1xuXHRjb25zdCBiZWZvcmVSZXNvbHZlR3VhcmRzID0gdXNlQ2FsbGJhY2tzKCk7XG5cdGNvbnN0IGFmdGVyR3VhcmRzID0gdXNlQ2FsbGJhY2tzKCk7XG5cdGNvbnN0IGN1cnJlbnRSb3V0ZSA9IHNoYWxsb3dSZWYoU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCk7XG5cdGxldCBwZW5kaW5nTG9jYXRpb24gPSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEO1xuXHRpZiAoaXNCcm93c2VyICYmIG9wdGlvbnMuc2Nyb2xsQmVoYXZpb3IgJiYgXCJzY3JvbGxSZXN0b3JhdGlvblwiIGluIGhpc3RvcnkpIGhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSBcIm1hbnVhbFwiO1xuXHRjb25zdCBub3JtYWxpemVQYXJhbXMgPSBhcHBseVRvUGFyYW1zLmJpbmQobnVsbCwgKHBhcmFtVmFsdWUpID0+IFwiXCIgKyBwYXJhbVZhbHVlKTtcblx0Y29uc3QgZW5jb2RlUGFyYW1zID0gYXBwbHlUb1BhcmFtcy5iaW5kKG51bGwsIGVuY29kZVBhcmFtKTtcblx0Y29uc3QgZGVjb2RlUGFyYW1zID0gYXBwbHlUb1BhcmFtcy5iaW5kKG51bGwsIGRlY29kZSk7XG5cdGZ1bmN0aW9uIGFkZFJvdXRlKHBhcmVudE9yUm91dGUsIHJvdXRlKSB7XG5cdFx0bGV0IHBhcmVudDtcblx0XHRsZXQgcmVjb3JkO1xuXHRcdGlmIChpc1JvdXRlTmFtZShwYXJlbnRPclJvdXRlKSkge1xuXHRcdFx0cGFyZW50ID0gbWF0Y2hlci5nZXRSZWNvcmRNYXRjaGVyKHBhcmVudE9yUm91dGUpO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhcGFyZW50KSB3YXJuJDEoYFBhcmVudCByb3V0ZSBcIiR7U3RyaW5nKHBhcmVudE9yUm91dGUpfVwiIG5vdCBmb3VuZCB3aGVuIGFkZGluZyBjaGlsZCByb3V0ZWAsIHJvdXRlKTtcblx0XHRcdHJlY29yZCA9IHJvdXRlO1xuXHRcdH0gZWxzZSByZWNvcmQgPSBwYXJlbnRPclJvdXRlO1xuXHRcdHJldHVybiBtYXRjaGVyLmFkZFJvdXRlKHJlY29yZCwgcGFyZW50KTtcblx0fVxuXHRmdW5jdGlvbiByZW1vdmVSb3V0ZShuYW1lKSB7XG5cdFx0Y29uc3QgcmVjb3JkTWF0Y2hlciA9IG1hdGNoZXIuZ2V0UmVjb3JkTWF0Y2hlcihuYW1lKTtcblx0XHRpZiAocmVjb3JkTWF0Y2hlcikgbWF0Y2hlci5yZW1vdmVSb3V0ZShyZWNvcmRNYXRjaGVyKTtcblx0XHRlbHNlIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHdhcm4kMShgQ2Fubm90IHJlbW92ZSBub24tZXhpc3RlbnQgcm91dGUgXCIke1N0cmluZyhuYW1lKX1cImApO1xuXHR9XG5cdGZ1bmN0aW9uIGdldFJvdXRlcygpIHtcblx0XHRyZXR1cm4gbWF0Y2hlci5nZXRSb3V0ZXMoKS5tYXAoKHJvdXRlTWF0Y2hlcikgPT4gcm91dGVNYXRjaGVyLnJlY29yZCk7XG5cdH1cblx0ZnVuY3Rpb24gaGFzUm91dGUobmFtZSkge1xuXHRcdHJldHVybiAhIW1hdGNoZXIuZ2V0UmVjb3JkTWF0Y2hlcihuYW1lKTtcblx0fVxuXHRmdW5jdGlvbiByZXNvbHZlKHJhd0xvY2F0aW9uLCBjdXJyZW50TG9jYXRpb24pIHtcblx0XHRjdXJyZW50TG9jYXRpb24gPSBhc3NpZ24oe30sIGN1cnJlbnRMb2NhdGlvbiB8fCBjdXJyZW50Um91dGUudmFsdWUpO1xuXHRcdGlmICh0eXBlb2YgcmF3TG9jYXRpb24gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGNvbnN0IGxvY2F0aW9uTm9ybWFsaXplZCA9IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgcmF3TG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbi5wYXRoKTtcblx0XHRcdGNvbnN0IG1hdGNoZWRSb3V0ZSQxID0gbWF0Y2hlci5yZXNvbHZlKHsgcGF0aDogbG9jYXRpb25Ob3JtYWxpemVkLnBhdGggfSwgY3VycmVudExvY2F0aW9uKTtcblx0XHRcdGNvbnN0IGhyZWYkMSA9IHJvdXRlckhpc3RvcnkuY3JlYXRlSHJlZihsb2NhdGlvbk5vcm1hbGl6ZWQuZnVsbFBhdGgpO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAoaHJlZiQxLnN0YXJ0c1dpdGgoXCIvL1wiKSkgd2FybiQxKGBMb2NhdGlvbiBcIiR7cmF3TG9jYXRpb259XCIgcmVzb2x2ZWQgdG8gXCIke2hyZWYkMX1cIi4gQSByZXNvbHZlZCBsb2NhdGlvbiBjYW5ub3Qgc3RhcnQgd2l0aCBtdWx0aXBsZSBzbGFzaGVzLmApO1xuXHRcdFx0XHRlbHNlIGlmICghbWF0Y2hlZFJvdXRlJDEubWF0Y2hlZC5sZW5ndGgpIHdhcm4kMShgTm8gbWF0Y2ggZm91bmQgZm9yIGxvY2F0aW9uIHdpdGggcGF0aCBcIiR7cmF3TG9jYXRpb259XCJgKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBhc3NpZ24obG9jYXRpb25Ob3JtYWxpemVkLCBtYXRjaGVkUm91dGUkMSwge1xuXHRcdFx0XHRwYXJhbXM6IGRlY29kZVBhcmFtcyhtYXRjaGVkUm91dGUkMS5wYXJhbXMpLFxuXHRcdFx0XHRoYXNoOiBkZWNvZGUobG9jYXRpb25Ob3JtYWxpemVkLmhhc2gpLFxuXHRcdFx0XHRyZWRpcmVjdGVkRnJvbTogdm9pZCAwLFxuXHRcdFx0XHRocmVmOiBocmVmJDFcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFpc1JvdXRlTG9jYXRpb24ocmF3TG9jYXRpb24pKSB7XG5cdFx0XHR3YXJuJDEoYHJvdXRlci5yZXNvbHZlKCkgd2FzIHBhc3NlZCBhbiBpbnZhbGlkIGxvY2F0aW9uLiBUaGlzIHdpbGwgZmFpbCBpbiBwcm9kdWN0aW9uLlxcbi0gTG9jYXRpb246YCwgcmF3TG9jYXRpb24pO1xuXHRcdFx0cmV0dXJuIHJlc29sdmUoe30pO1xuXHRcdH1cblx0XHRsZXQgbWF0Y2hlckxvY2F0aW9uO1xuXHRcdGlmIChyYXdMb2NhdGlvbi5wYXRoICE9IG51bGwpIHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgXCJwYXJhbXNcIiBpbiByYXdMb2NhdGlvbiAmJiAhKFwibmFtZVwiIGluIHJhd0xvY2F0aW9uKSAmJiBPYmplY3Qua2V5cyhyYXdMb2NhdGlvbi5wYXJhbXMpLmxlbmd0aCkgd2FybiQxKGBQYXRoIFwiJHtyYXdMb2NhdGlvbi5wYXRofVwiIHdhcyBwYXNzZWQgd2l0aCBwYXJhbXMgYnV0IHRoZXkgd2lsbCBiZSBpZ25vcmVkLiBVc2UgYSBuYW1lZCByb3V0ZSBhbG9uZ3NpZGUgcGFyYW1zIGluc3RlYWQuYCk7XG5cdFx0XHRtYXRjaGVyTG9jYXRpb24gPSBhc3NpZ24oe30sIHJhd0xvY2F0aW9uLCB7IHBhdGg6IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgcmF3TG9jYXRpb24ucGF0aCwgY3VycmVudExvY2F0aW9uLnBhdGgpLnBhdGggfSk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IHRhcmdldFBhcmFtcyA9IGFzc2lnbih7fSwgcmF3TG9jYXRpb24ucGFyYW1zKTtcblx0XHRcdGZvciAoY29uc3Qga2V5IGluIHRhcmdldFBhcmFtcykgaWYgKHRhcmdldFBhcmFtc1trZXldID09IG51bGwpIGRlbGV0ZSB0YXJnZXRQYXJhbXNba2V5XTtcblx0XHRcdG1hdGNoZXJMb2NhdGlvbiA9IGFzc2lnbih7fSwgcmF3TG9jYXRpb24sIHsgcGFyYW1zOiBlbmNvZGVQYXJhbXModGFyZ2V0UGFyYW1zKSB9KTtcblx0XHRcdGN1cnJlbnRMb2NhdGlvbi5wYXJhbXMgPSBlbmNvZGVQYXJhbXMoY3VycmVudExvY2F0aW9uLnBhcmFtcyk7XG5cdFx0fVxuXHRcdGNvbnN0IG1hdGNoZWRSb3V0ZSA9IG1hdGNoZXIucmVzb2x2ZShtYXRjaGVyTG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbik7XG5cdFx0Y29uc3QgaGFzaCA9IHJhd0xvY2F0aW9uLmhhc2ggfHwgXCJcIjtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGhhc2ggJiYgIWhhc2guc3RhcnRzV2l0aChcIiNcIikpIHdhcm4kMShgQSBcXGBoYXNoXFxgIHNob3VsZCBhbHdheXMgc3RhcnQgd2l0aCB0aGUgY2hhcmFjdGVyIFwiI1wiLiBSZXBsYWNlIFwiJHtoYXNofVwiIHdpdGggXCIjJHtoYXNofVwiLmApO1xuXHRcdG1hdGNoZWRSb3V0ZS5wYXJhbXMgPSBub3JtYWxpemVQYXJhbXMoZGVjb2RlUGFyYW1zKG1hdGNoZWRSb3V0ZS5wYXJhbXMpKTtcblx0XHRjb25zdCBmdWxsUGF0aCA9IHN0cmluZ2lmeVVSTChzdHJpbmdpZnlRdWVyeSQxLCBhc3NpZ24oe30sIHJhd0xvY2F0aW9uLCB7XG5cdFx0XHRoYXNoOiBlbmNvZGVIYXNoKGhhc2gpLFxuXHRcdFx0cGF0aDogbWF0Y2hlZFJvdXRlLnBhdGhcblx0XHR9KSk7XG5cdFx0Y29uc3QgaHJlZiA9IHJvdXRlckhpc3RvcnkuY3JlYXRlSHJlZihmdWxsUGF0aCk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0aWYgKGhyZWYuc3RhcnRzV2l0aChcIi8vXCIpKSB3YXJuJDEoYExvY2F0aW9uIFwiJHtyYXdMb2NhdGlvbn1cIiByZXNvbHZlZCB0byBcIiR7aHJlZn1cIi4gQSByZXNvbHZlZCBsb2NhdGlvbiBjYW5ub3Qgc3RhcnQgd2l0aCBtdWx0aXBsZSBzbGFzaGVzLmApO1xuXHRcdFx0ZWxzZSBpZiAoIW1hdGNoZWRSb3V0ZS5tYXRjaGVkLmxlbmd0aCkgd2FybiQxKGBObyBtYXRjaCBmb3VuZCBmb3IgbG9jYXRpb24gd2l0aCBwYXRoIFwiJHtyYXdMb2NhdGlvbi5wYXRoICE9IG51bGwgPyByYXdMb2NhdGlvbi5wYXRoIDogcmF3TG9jYXRpb259XCJgKTtcblx0XHR9XG5cdFx0cmV0dXJuIGFzc2lnbih7XG5cdFx0XHRmdWxsUGF0aCxcblx0XHRcdGhhc2gsXG5cdFx0XHRxdWVyeTogc3RyaW5naWZ5UXVlcnkkMSA9PT0gc3RyaW5naWZ5UXVlcnkgPyBub3JtYWxpemVRdWVyeShyYXdMb2NhdGlvbi5xdWVyeSkgOiByYXdMb2NhdGlvbi5xdWVyeSB8fCB7fVxuXHRcdH0sIG1hdGNoZWRSb3V0ZSwge1xuXHRcdFx0cmVkaXJlY3RlZEZyb206IHZvaWQgMCxcblx0XHRcdGhyZWZcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBsb2NhdGlvbkFzT2JqZWN0KHRvKSB7XG5cdFx0cmV0dXJuIHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIiA/IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgdG8sIGN1cnJlbnRSb3V0ZS52YWx1ZS5wYXRoKSA6IGFzc2lnbih7fSwgdG8pO1xuXHR9XG5cdGZ1bmN0aW9uIGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uKHRvLCBmcm9tKSB7XG5cdFx0aWYgKHBlbmRpbmdMb2NhdGlvbiAhPT0gdG8pIHJldHVybiBjcmVhdGVSb3V0ZXJFcnJvcihFcnJvclR5cGVzLk5BVklHQVRJT05fQ0FOQ0VMTEVELCB7XG5cdFx0XHRmcm9tLFxuXHRcdFx0dG9cblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBwdXNoKHRvKSB7XG5cdFx0cmV0dXJuIHB1c2hXaXRoUmVkaXJlY3QodG8pO1xuXHR9XG5cdGZ1bmN0aW9uIHJlcGxhY2UodG8pIHtcblx0XHRyZXR1cm4gcHVzaChhc3NpZ24obG9jYXRpb25Bc09iamVjdCh0byksIHsgcmVwbGFjZTogdHJ1ZSB9KSk7XG5cdH1cblx0ZnVuY3Rpb24gaGFuZGxlUmVkaXJlY3RSZWNvcmQodG8sIGZyb20pIHtcblx0XHRjb25zdCBsYXN0TWF0Y2hlZCA9IHRvLm1hdGNoZWRbdG8ubWF0Y2hlZC5sZW5ndGggLSAxXTtcblx0XHRpZiAobGFzdE1hdGNoZWQgJiYgbGFzdE1hdGNoZWQucmVkaXJlY3QpIHtcblx0XHRcdGNvbnN0IHsgcmVkaXJlY3QgfSA9IGxhc3RNYXRjaGVkO1xuXHRcdFx0bGV0IG5ld1RhcmdldExvY2F0aW9uID0gdHlwZW9mIHJlZGlyZWN0ID09PSBcImZ1bmN0aW9uXCIgPyByZWRpcmVjdCh0bywgZnJvbSkgOiByZWRpcmVjdDtcblx0XHRcdGlmICh0eXBlb2YgbmV3VGFyZ2V0TG9jYXRpb24gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24gPSBuZXdUYXJnZXRMb2NhdGlvbi5pbmNsdWRlcyhcIj9cIikgfHwgbmV3VGFyZ2V0TG9jYXRpb24uaW5jbHVkZXMoXCIjXCIpID8gbmV3VGFyZ2V0TG9jYXRpb24gPSBsb2NhdGlvbkFzT2JqZWN0KG5ld1RhcmdldExvY2F0aW9uKSA6IHsgcGF0aDogbmV3VGFyZ2V0TG9jYXRpb24gfTtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24ucGFyYW1zID0ge307XG5cdFx0XHR9XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIG5ld1RhcmdldExvY2F0aW9uLnBhdGggPT0gbnVsbCAmJiAhKFwibmFtZVwiIGluIG5ld1RhcmdldExvY2F0aW9uKSkge1xuXHRcdFx0XHR3YXJuJDEoYEludmFsaWQgcmVkaXJlY3QgZm91bmQ6XFxuJHtKU09OLnN0cmluZ2lmeShuZXdUYXJnZXRMb2NhdGlvbiwgbnVsbCwgMil9XFxuIHdoZW4gbmF2aWdhdGluZyB0byBcIiR7dG8uZnVsbFBhdGh9XCIuIEEgcmVkaXJlY3QgbXVzdCBjb250YWluIGEgbmFtZSBvciBwYXRoLiBUaGlzIHdpbGwgYnJlYWsgaW4gcHJvZHVjdGlvbi5gKTtcblx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCByZWRpcmVjdFwiKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBhc3NpZ24oe1xuXHRcdFx0XHRxdWVyeTogdG8ucXVlcnksXG5cdFx0XHRcdGhhc2g6IHRvLmhhc2gsXG5cdFx0XHRcdHBhcmFtczogbmV3VGFyZ2V0TG9jYXRpb24ucGF0aCAhPSBudWxsID8ge30gOiB0by5wYXJhbXNcblx0XHRcdH0sIG5ld1RhcmdldExvY2F0aW9uKTtcblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gcHVzaFdpdGhSZWRpcmVjdCh0bywgcmVkaXJlY3RlZEZyb20pIHtcblx0XHRjb25zdCB0YXJnZXRMb2NhdGlvbiA9IHBlbmRpbmdMb2NhdGlvbiA9IHJlc29sdmUodG8pO1xuXHRcdGNvbnN0IGZyb20gPSBjdXJyZW50Um91dGUudmFsdWU7XG5cdFx0Y29uc3QgZGF0YSA9IHRvLnN0YXRlO1xuXHRcdGNvbnN0IGZvcmNlID0gdG8uZm9yY2U7XG5cdFx0Y29uc3QgcmVwbGFjZSQxID0gdG8ucmVwbGFjZSA9PT0gdHJ1ZTtcblx0XHRjb25zdCBzaG91bGRSZWRpcmVjdCA9IGhhbmRsZVJlZGlyZWN0UmVjb3JkKHRhcmdldExvY2F0aW9uLCBmcm9tKTtcblx0XHRpZiAoc2hvdWxkUmVkaXJlY3QpIHJldHVybiBwdXNoV2l0aFJlZGlyZWN0KGFzc2lnbihsb2NhdGlvbkFzT2JqZWN0KHNob3VsZFJlZGlyZWN0KSwge1xuXHRcdFx0c3RhdGU6IHR5cGVvZiBzaG91bGRSZWRpcmVjdCA9PT0gXCJvYmplY3RcIiA/IGFzc2lnbih7fSwgZGF0YSwgc2hvdWxkUmVkaXJlY3Quc3RhdGUpIDogZGF0YSxcblx0XHRcdGZvcmNlLFxuXHRcdFx0cmVwbGFjZTogcmVwbGFjZSQxXG5cdFx0fSksIHJlZGlyZWN0ZWRGcm9tIHx8IHRhcmdldExvY2F0aW9uKTtcblx0XHRjb25zdCB0b0xvY2F0aW9uID0gdGFyZ2V0TG9jYXRpb247XG5cdFx0dG9Mb2NhdGlvbi5yZWRpcmVjdGVkRnJvbSA9IHJlZGlyZWN0ZWRGcm9tO1xuXHRcdGxldCBmYWlsdXJlO1xuXHRcdGlmICghZm9yY2UgJiYgaXNTYW1lUm91dGVMb2NhdGlvbihzdHJpbmdpZnlRdWVyeSQxLCBmcm9tLCB0YXJnZXRMb2NhdGlvbikpIHtcblx0XHRcdGZhaWx1cmUgPSBjcmVhdGVSb3V0ZXJFcnJvcihFcnJvclR5cGVzLk5BVklHQVRJT05fRFVQTElDQVRFRCwge1xuXHRcdFx0XHR0bzogdG9Mb2NhdGlvbixcblx0XHRcdFx0ZnJvbVxuXHRcdFx0fSk7XG5cdFx0XHRoYW5kbGVTY3JvbGwoZnJvbSwgZnJvbSwgdHJ1ZSwgZmFsc2UpO1xuXHRcdH1cblx0XHRyZXR1cm4gKGZhaWx1cmUgPyBQcm9taXNlLnJlc29sdmUoZmFpbHVyZSkgOiBuYXZpZ2F0ZSh0b0xvY2F0aW9uLCBmcm9tKSkuY2F0Y2goKGVycm9yKSA9PiBpc05hdmlnYXRpb25GYWlsdXJlKGVycm9yKSA/IGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyb3IsIEVycm9yVHlwZXMuTkFWSUdBVElPTl9HVUFSRF9SRURJUkVDVCkgPyBlcnJvciA6IG1hcmtBc1JlYWR5KGVycm9yKSA6IHRyaWdnZXJFcnJvcihlcnJvciwgdG9Mb2NhdGlvbiwgZnJvbSkpLnRoZW4oKGZhaWx1cmUkMSkgPT4ge1xuXHRcdFx0aWYgKGZhaWx1cmUkMSkge1xuXHRcdFx0XHRpZiAoaXNOYXZpZ2F0aW9uRmFpbHVyZShmYWlsdXJlJDEsIEVycm9yVHlwZXMuTkFWSUdBVElPTl9HVUFSRF9SRURJUkVDVCkpIHtcblx0XHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGlzU2FtZVJvdXRlTG9jYXRpb24oc3RyaW5naWZ5UXVlcnkkMSwgcmVzb2x2ZShmYWlsdXJlJDEudG8pLCB0b0xvY2F0aW9uKSAmJiByZWRpcmVjdGVkRnJvbSAmJiAocmVkaXJlY3RlZEZyb20uX2NvdW50ID0gcmVkaXJlY3RlZEZyb20uX2NvdW50ID8gcmVkaXJlY3RlZEZyb20uX2NvdW50ICsgMSA6IDEpID4gMzApIHtcblx0XHRcdFx0XHRcdHdhcm4kMShgRGV0ZWN0ZWQgYSBwb3NzaWJseSBpbmZpbml0ZSByZWRpcmVjdGlvbiBpbiBhIG5hdmlnYXRpb24gZ3VhcmQgd2hlbiBnb2luZyBmcm9tIFwiJHtmcm9tLmZ1bGxQYXRofVwiIHRvIFwiJHt0b0xvY2F0aW9uLmZ1bGxQYXRofVwiLiBBYm9ydGluZyB0byBhdm9pZCBhIFN0YWNrIE92ZXJmbG93LlxcbiBBcmUgeW91IGFsd2F5cyByZXR1cm5pbmcgYSBuZXcgbG9jYXRpb24gd2l0aGluIGEgbmF2aWdhdGlvbiBndWFyZD8gVGhhdCB3b3VsZCBsZWFkIHRvIHRoaXMgZXJyb3IuIE9ubHkgcmV0dXJuIHdoZW4gcmVkaXJlY3Rpbmcgb3IgYWJvcnRpbmcsIHRoYXQgc2hvdWxkIGZpeCB0aGlzLiBUaGlzIG1pZ2h0IGJyZWFrIGluIHByb2R1Y3Rpb24gaWYgbm90IGZpeGVkLmApO1xuXHRcdFx0XHRcdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJJbmZpbml0ZSByZWRpcmVjdCBpbiBuYXZpZ2F0aW9uIGd1YXJkXCIpKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0cmV0dXJuIHB1c2hXaXRoUmVkaXJlY3QoYXNzaWduKHsgcmVwbGFjZTogcmVwbGFjZSQxIH0sIGxvY2F0aW9uQXNPYmplY3QoZmFpbHVyZSQxLnRvKSwge1xuXHRcdFx0XHRcdFx0c3RhdGU6IHR5cGVvZiBmYWlsdXJlJDEudG8gPT09IFwib2JqZWN0XCIgPyBhc3NpZ24oe30sIGRhdGEsIGZhaWx1cmUkMS50by5zdGF0ZSkgOiBkYXRhLFxuXHRcdFx0XHRcdFx0Zm9yY2Vcblx0XHRcdFx0XHR9KSwgcmVkaXJlY3RlZEZyb20gfHwgdG9Mb2NhdGlvbik7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBmYWlsdXJlJDEgPSBmaW5hbGl6ZU5hdmlnYXRpb24odG9Mb2NhdGlvbiwgZnJvbSwgdHJ1ZSwgcmVwbGFjZSQxLCBkYXRhKTtcblx0XHRcdHRyaWdnZXJBZnRlckVhY2godG9Mb2NhdGlvbiwgZnJvbSwgZmFpbHVyZSQxKTtcblx0XHRcdHJldHVybiBmYWlsdXJlJDE7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogSGVscGVyIHRvIHJlamVjdCBhbmQgc2tpcCBhbGwgbmF2aWdhdGlvbiBndWFyZHMgaWYgYSBuZXcgbmF2aWdhdGlvbiBoYXBwZW5lZFxuXHQqIEBwYXJhbSB0b1xuXHQqIEBwYXJhbSBmcm9tXG5cdCovXG5cdGZ1bmN0aW9uIGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uQW5kUmVqZWN0KHRvLCBmcm9tKSB7XG5cdFx0Y29uc3QgZXJyb3IgPSBjaGVja0NhbmNlbGVkTmF2aWdhdGlvbih0bywgZnJvbSk7XG5cdFx0cmV0dXJuIGVycm9yID8gUHJvbWlzZS5yZWplY3QoZXJyb3IpIDogUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0ZnVuY3Rpb24gcnVuV2l0aENvbnRleHQoZm4pIHtcblx0XHRjb25zdCBhcHAgPSBpbnN0YWxsZWRBcHBzLnZhbHVlcygpLm5leHQoKS52YWx1ZTtcblx0XHRyZXR1cm4gYXBwICYmIHR5cGVvZiBhcHAucnVuV2l0aENvbnRleHQgPT09IFwiZnVuY3Rpb25cIiA/IGFwcC5ydW5XaXRoQ29udGV4dChmbikgOiBmbigpO1xuXHR9XG5cdGZ1bmN0aW9uIG5hdmlnYXRlKHRvLCBmcm9tKSB7XG5cdFx0bGV0IGd1YXJkcztcblx0XHRjb25zdCBbbGVhdmluZ1JlY29yZHMsIHVwZGF0aW5nUmVjb3JkcywgZW50ZXJpbmdSZWNvcmRzXSA9IGV4dHJhY3RDaGFuZ2luZ1JlY29yZHModG8sIGZyb20pO1xuXHRcdGd1YXJkcyA9IGV4dHJhY3RDb21wb25lbnRzR3VhcmRzKGxlYXZpbmdSZWNvcmRzLnJldmVyc2UoKSwgXCJiZWZvcmVSb3V0ZUxlYXZlXCIsIHRvLCBmcm9tKTtcblx0XHRmb3IgKGNvbnN0IHJlY29yZCBvZiBsZWF2aW5nUmVjb3JkcykgcmVjb3JkLmxlYXZlR3VhcmRzLmZvckVhY2goKGd1YXJkKSA9PiB7XG5cdFx0XHRndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSkpO1xuXHRcdH0pO1xuXHRcdGNvbnN0IGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrID0gY2hlY2tDYW5jZWxlZE5hdmlnYXRpb25BbmRSZWplY3QuYmluZChudWxsLCB0bywgZnJvbSk7XG5cdFx0Z3VhcmRzLnB1c2goY2FuY2VsZWROYXZpZ2F0aW9uQ2hlY2spO1xuXHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcykudGhlbigoKSA9PiB7XG5cdFx0XHRndWFyZHMgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgZ3VhcmQgb2YgYmVmb3JlR3VhcmRzLmxpc3QoKSkgZ3VhcmRzLnB1c2goZ3VhcmRUb1Byb21pc2VGbihndWFyZCwgdG8sIGZyb20pKTtcblx0XHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcyk7XG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHRndWFyZHMgPSBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyh1cGRhdGluZ1JlY29yZHMsIFwiYmVmb3JlUm91dGVVcGRhdGVcIiwgdG8sIGZyb20pO1xuXHRcdFx0Zm9yIChjb25zdCByZWNvcmQgb2YgdXBkYXRpbmdSZWNvcmRzKSByZWNvcmQudXBkYXRlR3VhcmRzLmZvckVhY2goKGd1YXJkKSA9PiB7XG5cdFx0XHRcdGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tKSk7XG5cdFx0XHR9KTtcblx0XHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcyk7XG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHRndWFyZHMgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgcmVjb3JkIG9mIGVudGVyaW5nUmVjb3JkcykgaWYgKHJlY29yZC5iZWZvcmVFbnRlcikgaWYgKGlzQXJyYXkocmVjb3JkLmJlZm9yZUVudGVyKSkgZm9yIChjb25zdCBiZWZvcmVFbnRlciBvZiByZWNvcmQuYmVmb3JlRW50ZXIpIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oYmVmb3JlRW50ZXIsIHRvLCBmcm9tKSk7XG5cdFx0XHRlbHNlIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4ocmVjb3JkLmJlZm9yZUVudGVyLCB0bywgZnJvbSkpO1xuXHRcdFx0Z3VhcmRzLnB1c2goY2FuY2VsZWROYXZpZ2F0aW9uQ2hlY2spO1xuXHRcdFx0cmV0dXJuIHJ1bkd1YXJkUXVldWUoZ3VhcmRzKTtcblx0XHR9KS50aGVuKCgpID0+IHtcblx0XHRcdHRvLm1hdGNoZWQuZm9yRWFjaCgocmVjb3JkKSA9PiByZWNvcmQuZW50ZXJDYWxsYmFja3MgPSB7fSk7XG5cdFx0XHRndWFyZHMgPSBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyhlbnRlcmluZ1JlY29yZHMsIFwiYmVmb3JlUm91dGVFbnRlclwiLCB0bywgZnJvbSwgcnVuV2l0aENvbnRleHQpO1xuXHRcdFx0Z3VhcmRzLnB1c2goY2FuY2VsZWROYXZpZ2F0aW9uQ2hlY2spO1xuXHRcdFx0cmV0dXJuIHJ1bkd1YXJkUXVldWUoZ3VhcmRzKTtcblx0XHR9KS50aGVuKCgpID0+IHtcblx0XHRcdGd1YXJkcyA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBndWFyZCBvZiBiZWZvcmVSZXNvbHZlR3VhcmRzLmxpc3QoKSkgZ3VhcmRzLnB1c2goZ3VhcmRUb1Byb21pc2VGbihndWFyZCwgdG8sIGZyb20pKTtcblx0XHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcyk7XG5cdFx0fSkuY2F0Y2goKGVycikgPT4gaXNOYXZpZ2F0aW9uRmFpbHVyZShlcnIsIEVycm9yVHlwZXMuTkFWSUdBVElPTl9DQU5DRUxMRUQpID8gZXJyIDogUHJvbWlzZS5yZWplY3QoZXJyKSk7XG5cdH1cblx0ZnVuY3Rpb24gdHJpZ2dlckFmdGVyRWFjaCh0bywgZnJvbSwgZmFpbHVyZSkge1xuXHRcdGFmdGVyR3VhcmRzLmxpc3QoKS5mb3JFYWNoKChndWFyZCkgPT4gcnVuV2l0aENvbnRleHQoKCkgPT4gZ3VhcmQodG8sIGZyb20sIGZhaWx1cmUpKSk7XG5cdH1cblx0LyoqXG5cdCogLSBDbGVhbnMgdXAgYW55IG5hdmlnYXRpb24gZ3VhcmRzXG5cdCogLSBDaGFuZ2VzIHRoZSB1cmwgaWYgbmVjZXNzYXJ5XG5cdCogLSBDYWxscyB0aGUgc2Nyb2xsQmVoYXZpb3Jcblx0Ki9cblx0ZnVuY3Rpb24gZmluYWxpemVOYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20sIGlzUHVzaCwgcmVwbGFjZSQxLCBkYXRhKSB7XG5cdFx0Y29uc3QgZXJyb3IgPSBjaGVja0NhbmNlbGVkTmF2aWdhdGlvbih0b0xvY2F0aW9uLCBmcm9tKTtcblx0XHRpZiAoZXJyb3IpIHJldHVybiBlcnJvcjtcblx0XHRjb25zdCBpc0ZpcnN0TmF2aWdhdGlvbiA9IGZyb20gPT09IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQ7XG5cdFx0Y29uc3Qgc3RhdGUgPSAhaXNCcm93c2VyID8ge30gOiBoaXN0b3J5LnN0YXRlO1xuXHRcdGlmIChpc1B1c2gpIGlmIChyZXBsYWNlJDEgfHwgaXNGaXJzdE5hdmlnYXRpb24pIHJvdXRlckhpc3RvcnkucmVwbGFjZSh0b0xvY2F0aW9uLmZ1bGxQYXRoLCBhc3NpZ24oeyBzY3JvbGw6IGlzRmlyc3ROYXZpZ2F0aW9uICYmIHN0YXRlICYmIHN0YXRlLnNjcm9sbCB9LCBkYXRhKSk7XG5cdFx0ZWxzZSByb3V0ZXJIaXN0b3J5LnB1c2godG9Mb2NhdGlvbi5mdWxsUGF0aCwgZGF0YSk7XG5cdFx0Y3VycmVudFJvdXRlLnZhbHVlID0gdG9Mb2NhdGlvbjtcblx0XHRoYW5kbGVTY3JvbGwodG9Mb2NhdGlvbiwgZnJvbSwgaXNQdXNoLCBpc0ZpcnN0TmF2aWdhdGlvbik7XG5cdFx0bWFya0FzUmVhZHkoKTtcblx0fVxuXHRsZXQgcmVtb3ZlSGlzdG9yeUxpc3RlbmVyO1xuXHRmdW5jdGlvbiBzZXR1cExpc3RlbmVycygpIHtcblx0XHRpZiAocmVtb3ZlSGlzdG9yeUxpc3RlbmVyKSByZXR1cm47XG5cdFx0cmVtb3ZlSGlzdG9yeUxpc3RlbmVyID0gcm91dGVySGlzdG9yeS5saXN0ZW4oKHRvLCBfZnJvbSwgaW5mbykgPT4ge1xuXHRcdFx0aWYgKCFyb3V0ZXIubGlzdGVuaW5nKSByZXR1cm47XG5cdFx0XHRjb25zdCB0b0xvY2F0aW9uID0gcmVzb2x2ZSh0byk7XG5cdFx0XHRjb25zdCBzaG91bGRSZWRpcmVjdCA9IGhhbmRsZVJlZGlyZWN0UmVjb3JkKHRvTG9jYXRpb24sIHJvdXRlci5jdXJyZW50Um91dGUudmFsdWUpO1xuXHRcdFx0aWYgKHNob3VsZFJlZGlyZWN0KSB7XG5cdFx0XHRcdHB1c2hXaXRoUmVkaXJlY3QoYXNzaWduKHNob3VsZFJlZGlyZWN0LCB7XG5cdFx0XHRcdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRcdFx0XHRmb3JjZTogdHJ1ZVxuXHRcdFx0XHR9KSwgdG9Mb2NhdGlvbikuY2F0Y2gobm9vcCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdHBlbmRpbmdMb2NhdGlvbiA9IHRvTG9jYXRpb247XG5cdFx0XHRjb25zdCBmcm9tID0gY3VycmVudFJvdXRlLnZhbHVlO1xuXHRcdFx0aWYgKGlzQnJvd3Nlcikgc2F2ZVNjcm9sbFBvc2l0aW9uKGdldFNjcm9sbEtleShmcm9tLmZ1bGxQYXRoLCBpbmZvLmRlbHRhKSwgY29tcHV0ZVNjcm9sbFBvc2l0aW9uKCkpO1xuXHRcdFx0bmF2aWdhdGUodG9Mb2NhdGlvbiwgZnJvbSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGVycm9yLCBFcnJvclR5cGVzLk5BVklHQVRJT05fQUJPUlRFRCB8IEVycm9yVHlwZXMuTkFWSUdBVElPTl9DQU5DRUxMRUQpKSByZXR1cm4gZXJyb3I7XG5cdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGVycm9yLCBFcnJvclR5cGVzLk5BVklHQVRJT05fR1VBUkRfUkVESVJFQ1QpKSB7XG5cdFx0XHRcdFx0cHVzaFdpdGhSZWRpcmVjdChhc3NpZ24obG9jYXRpb25Bc09iamVjdChlcnJvci50byksIHsgZm9yY2U6IHRydWUgfSksIHRvTG9jYXRpb24pLnRoZW4oKGZhaWx1cmUpID0+IHtcblx0XHRcdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIEVycm9yVHlwZXMuTkFWSUdBVElPTl9BQk9SVEVEIHwgRXJyb3JUeXBlcy5OQVZJR0FUSU9OX0RVUExJQ0FURUQpICYmICFpbmZvLmRlbHRhICYmIGluZm8udHlwZSA9PT0gTmF2aWdhdGlvblR5cGUucG9wKSByb3V0ZXJIaXN0b3J5LmdvKC0xLCBmYWxzZSk7XG5cdFx0XHRcdFx0fSkuY2F0Y2gobm9vcCk7XG5cdFx0XHRcdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGluZm8uZGVsdGEpIHJvdXRlckhpc3RvcnkuZ28oLWluZm8uZGVsdGEsIGZhbHNlKTtcblx0XHRcdFx0cmV0dXJuIHRyaWdnZXJFcnJvcihlcnJvciwgdG9Mb2NhdGlvbiwgZnJvbSk7XG5cdFx0XHR9KS50aGVuKChmYWlsdXJlKSA9PiB7XG5cdFx0XHRcdGZhaWx1cmUgPSBmYWlsdXJlIHx8IGZpbmFsaXplTmF2aWdhdGlvbih0b0xvY2F0aW9uLCBmcm9tLCBmYWxzZSk7XG5cdFx0XHRcdGlmIChmYWlsdXJlKSB7XG5cdFx0XHRcdFx0aWYgKGluZm8uZGVsdGEgJiYgIWlzTmF2aWdhdGlvbkZhaWx1cmUoZmFpbHVyZSwgRXJyb3JUeXBlcy5OQVZJR0FUSU9OX0NBTkNFTExFRCkpIHJvdXRlckhpc3RvcnkuZ28oLWluZm8uZGVsdGEsIGZhbHNlKTtcblx0XHRcdFx0XHRlbHNlIGlmIChpbmZvLnR5cGUgPT09IE5hdmlnYXRpb25UeXBlLnBvcCAmJiBpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIEVycm9yVHlwZXMuTkFWSUdBVElPTl9BQk9SVEVEIHwgRXJyb3JUeXBlcy5OQVZJR0FUSU9OX0RVUExJQ0FURUQpKSByb3V0ZXJIaXN0b3J5LmdvKC0xLCBmYWxzZSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0dHJpZ2dlckFmdGVyRWFjaCh0b0xvY2F0aW9uLCBmcm9tLCBmYWlsdXJlKTtcblx0XHRcdH0pLmNhdGNoKG5vb3ApO1xuXHRcdH0pO1xuXHR9XG5cdGxldCByZWFkeUhhbmRsZXJzID0gdXNlQ2FsbGJhY2tzKCk7XG5cdGxldCBlcnJvckxpc3RlbmVycyA9IHVzZUNhbGxiYWNrcygpO1xuXHRsZXQgcmVhZHk7XG5cdC8qKlxuXHQqIFRyaWdnZXIgZXJyb3JMaXN0ZW5lcnMgYWRkZWQgdmlhIG9uRXJyb3IgYW5kIHRocm93cyB0aGUgZXJyb3IgYXMgd2VsbFxuXHQqXG5cdCogQHBhcmFtIGVycm9yIC0gZXJyb3IgdG8gdGhyb3dcblx0KiBAcGFyYW0gdG8gLSBsb2NhdGlvbiB3ZSB3ZXJlIG5hdmlnYXRpbmcgdG8gd2hlbiB0aGUgZXJyb3IgaGFwcGVuZWRcblx0KiBAcGFyYW0gZnJvbSAtIGxvY2F0aW9uIHdlIHdlcmUgbmF2aWdhdGluZyBmcm9tIHdoZW4gdGhlIGVycm9yIGhhcHBlbmVkXG5cdCogQHJldHVybnMgdGhlIGVycm9yIGFzIGEgcmVqZWN0ZWQgcHJvbWlzZVxuXHQqL1xuXHRmdW5jdGlvbiB0cmlnZ2VyRXJyb3IoZXJyb3IsIHRvLCBmcm9tKSB7XG5cdFx0bWFya0FzUmVhZHkoZXJyb3IpO1xuXHRcdGNvbnN0IGxpc3QgPSBlcnJvckxpc3RlbmVycy5saXN0KCk7XG5cdFx0aWYgKGxpc3QubGVuZ3RoKSBsaXN0LmZvckVhY2goKGhhbmRsZXIpID0+IGhhbmRsZXIoZXJyb3IsIHRvLCBmcm9tKSk7XG5cdFx0ZWxzZSB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB3YXJuJDEoXCJ1bmNhdWdodCBlcnJvciBkdXJpbmcgcm91dGUgbmF2aWdhdGlvbjpcIik7XG5cdFx0XHRjb25zb2xlLmVycm9yKGVycm9yKTtcblx0XHR9XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcblx0fVxuXHRmdW5jdGlvbiBpc1JlYWR5KCkge1xuXHRcdGlmIChyZWFkeSAmJiBjdXJyZW50Um91dGUudmFsdWUgIT09IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQpIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUkMSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRyZWFkeUhhbmRsZXJzLmFkZChbcmVzb2x2ZSQxLCByZWplY3RdKTtcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBtYXJrQXNSZWFkeShlcnIpIHtcblx0XHRpZiAoIXJlYWR5KSB7XG5cdFx0XHRyZWFkeSA9ICFlcnI7XG5cdFx0XHRzZXR1cExpc3RlbmVycygpO1xuXHRcdFx0cmVhZHlIYW5kbGVycy5saXN0KCkuZm9yRWFjaCgoW3Jlc29sdmUkMSwgcmVqZWN0XSkgPT4gZXJyID8gcmVqZWN0KGVycikgOiByZXNvbHZlJDEoKSk7XG5cdFx0XHRyZWFkeUhhbmRsZXJzLnJlc2V0KCk7XG5cdFx0fVxuXHRcdHJldHVybiBlcnI7XG5cdH1cblx0ZnVuY3Rpb24gaGFuZGxlU2Nyb2xsKHRvLCBmcm9tLCBpc1B1c2gsIGlzRmlyc3ROYXZpZ2F0aW9uKSB7XG5cdFx0Y29uc3QgeyBzY3JvbGxCZWhhdmlvciB9ID0gb3B0aW9ucztcblx0XHRpZiAoIWlzQnJvd3NlciB8fCAhc2Nyb2xsQmVoYXZpb3IpIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRjb25zdCBzY3JvbGxQb3NpdGlvbiA9ICFpc1B1c2ggJiYgZ2V0U2F2ZWRTY3JvbGxQb3NpdGlvbihnZXRTY3JvbGxLZXkodG8uZnVsbFBhdGgsIDApKSB8fCAoaXNGaXJzdE5hdmlnYXRpb24gfHwgIWlzUHVzaCkgJiYgaGlzdG9yeS5zdGF0ZSAmJiBoaXN0b3J5LnN0YXRlLnNjcm9sbCB8fCBudWxsO1xuXHRcdHJldHVybiBuZXh0VGljaygpLnRoZW4oKCkgPT4gc2Nyb2xsQmVoYXZpb3IodG8sIGZyb20sIHNjcm9sbFBvc2l0aW9uKSkudGhlbigocG9zaXRpb24pID0+IHBvc2l0aW9uICYmIHNjcm9sbFRvUG9zaXRpb24ocG9zaXRpb24pKS5jYXRjaCgoZXJyKSA9PiB0cmlnZ2VyRXJyb3IoZXJyLCB0bywgZnJvbSkpO1xuXHR9XG5cdGNvbnN0IGdvID0gKGRlbHRhKSA9PiByb3V0ZXJIaXN0b3J5LmdvKGRlbHRhKTtcblx0bGV0IHN0YXJ0ZWQ7XG5cdGNvbnN0IGluc3RhbGxlZEFwcHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRjb25zdCByb3V0ZXIgPSB7XG5cdFx0Y3VycmVudFJvdXRlLFxuXHRcdGxpc3RlbmluZzogdHJ1ZSxcblx0XHRhZGRSb3V0ZSxcblx0XHRyZW1vdmVSb3V0ZSxcblx0XHRjbGVhclJvdXRlczogbWF0Y2hlci5jbGVhclJvdXRlcyxcblx0XHRoYXNSb3V0ZSxcblx0XHRnZXRSb3V0ZXMsXG5cdFx0cmVzb2x2ZSxcblx0XHRvcHRpb25zLFxuXHRcdHB1c2gsXG5cdFx0cmVwbGFjZSxcblx0XHRnbyxcblx0XHRiYWNrOiAoKSA9PiBnbygtMSksXG5cdFx0Zm9yd2FyZDogKCkgPT4gZ28oMSksXG5cdFx0YmVmb3JlRWFjaDogYmVmb3JlR3VhcmRzLmFkZCxcblx0XHRiZWZvcmVSZXNvbHZlOiBiZWZvcmVSZXNvbHZlR3VhcmRzLmFkZCxcblx0XHRhZnRlckVhY2g6IGFmdGVyR3VhcmRzLmFkZCxcblx0XHRvbkVycm9yOiBlcnJvckxpc3RlbmVycy5hZGQsXG5cdFx0aXNSZWFkeSxcblx0XHRpbnN0YWxsKGFwcCkge1xuXHRcdFx0YXBwLmNvbXBvbmVudChcIlJvdXRlckxpbmtcIiwgUm91dGVyTGluayk7XG5cdFx0XHRhcHAuY29tcG9uZW50KFwiUm91dGVyVmlld1wiLCBSb3V0ZXJWaWV3KTtcblx0XHRcdGFwcC5jb25maWcuZ2xvYmFsUHJvcGVydGllcy4kcm91dGVyID0gcm91dGVyO1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGFwcC5jb25maWcuZ2xvYmFsUHJvcGVydGllcywgXCIkcm91dGVcIiwge1xuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRnZXQ6ICgpID0+IHVucmVmKGN1cnJlbnRSb3V0ZSlcblx0XHRcdH0pO1xuXHRcdFx0aWYgKGlzQnJvd3NlciAmJiAhc3RhcnRlZCAmJiBjdXJyZW50Um91dGUudmFsdWUgPT09IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQpIHtcblx0XHRcdFx0c3RhcnRlZCA9IHRydWU7XG5cdFx0XHRcdHB1c2gocm91dGVySGlzdG9yeS5sb2NhdGlvbikuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHdhcm4kMShcIlVuZXhwZWN0ZWQgZXJyb3Igd2hlbiBzdGFydGluZyB0aGUgcm91dGVyOlwiLCBlcnIpO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHJlYWN0aXZlUm91dGUgPSB7fTtcblx0XHRcdGZvciAoY29uc3Qga2V5IGluIFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQpIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZWFjdGl2ZVJvdXRlLCBrZXksIHtcblx0XHRcdFx0Z2V0OiAoKSA9PiBjdXJyZW50Um91dGUudmFsdWVba2V5XSxcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRhcHAucHJvdmlkZShyb3V0ZXJLZXksIHJvdXRlcik7XG5cdFx0XHRhcHAucHJvdmlkZShyb3V0ZUxvY2F0aW9uS2V5LCBzaGFsbG93UmVhY3RpdmUocmVhY3RpdmVSb3V0ZSkpO1xuXHRcdFx0YXBwLnByb3ZpZGUocm91dGVyVmlld0xvY2F0aW9uS2V5LCBjdXJyZW50Um91dGUpO1xuXHRcdFx0Y29uc3QgdW5tb3VudEFwcCA9IGFwcC51bm1vdW50O1xuXHRcdFx0aW5zdGFsbGVkQXBwcy5hZGQoYXBwKTtcblx0XHRcdGFwcC51bm1vdW50ID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRcdGluc3RhbGxlZEFwcHMuZGVsZXRlKGFwcCk7XG5cdFx0XHRcdGlmIChpbnN0YWxsZWRBcHBzLnNpemUgPCAxKSB7XG5cdFx0XHRcdFx0cGVuZGluZ0xvY2F0aW9uID0gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRDtcblx0XHRcdFx0XHRyZW1vdmVIaXN0b3J5TGlzdGVuZXIgJiYgcmVtb3ZlSGlzdG9yeUxpc3RlbmVyKCk7XG5cdFx0XHRcdFx0cmVtb3ZlSGlzdG9yeUxpc3RlbmVyID0gbnVsbDtcblx0XHRcdFx0XHRjdXJyZW50Um91dGUudmFsdWUgPSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEO1xuXHRcdFx0XHRcdHN0YXJ0ZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRyZWFkeSA9IGZhbHNlO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHVubW91bnRBcHAoKTtcblx0XHRcdH07XG5cdFx0XHRpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIGlzQnJvd3NlcikgYWRkRGV2dG9vbHMoYXBwLCByb3V0ZXIsIG1hdGNoZXIpO1xuXHRcdH1cblx0fTtcblx0ZnVuY3Rpb24gcnVuR3VhcmRRdWV1ZShndWFyZHMpIHtcblx0XHRyZXR1cm4gZ3VhcmRzLnJlZHVjZSgocHJvbWlzZSwgZ3VhcmQpID0+IHByb21pc2UudGhlbigoKSA9PiBydW5XaXRoQ29udGV4dChndWFyZCkpLCBQcm9taXNlLnJlc29sdmUoKSk7XG5cdH1cblx0cmV0dXJuIHJvdXRlcjtcbn1cblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3VzZUFwaS50c1xuLyoqXG4qIFJldHVybnMgdGhlIHJvdXRlciBpbnN0YW5jZS4gRXF1aXZhbGVudCB0byB1c2luZyBgJHJvdXRlcmAgaW5zaWRlXG4qIHRlbXBsYXRlcy5cbiovXG5mdW5jdGlvbiB1c2VSb3V0ZXIoKSB7XG5cdHJldHVybiBpbmplY3Qocm91dGVyS2V5KTtcbn1cbi8qKlxuKiBSZXR1cm5zIHRoZSBjdXJyZW50IHJvdXRlIGxvY2F0aW9uLiBFcXVpdmFsZW50IHRvIHVzaW5nIGAkcm91dGVgIGluc2lkZVxuKiB0ZW1wbGF0ZXMuXG4qL1xuZnVuY3Rpb24gdXNlUm91dGUoX25hbWUpIHtcblx0cmV0dXJuIGluamVjdChyb3V0ZUxvY2F0aW9uS2V5KTtcbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBOYXZpZ2F0aW9uRmFpbHVyZVR5cGUsIFJvdXRlckxpbmssIFJvdXRlclZpZXcsIFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQgYXMgU1RBUlRfTE9DQVRJT04sIGNyZWF0ZU1lbW9yeUhpc3RvcnksIGNyZWF0ZVJvdXRlciwgY3JlYXRlUm91dGVyTWF0Y2hlciwgY3JlYXRlV2ViSGFzaEhpc3RvcnksIGNyZWF0ZVdlYkhpc3RvcnksIGlzTmF2aWdhdGlvbkZhaWx1cmUsIGxvYWRSb3V0ZUxvY2F0aW9uLCBtYXRjaGVkUm91dGVLZXksIG9uQmVmb3JlUm91dGVMZWF2ZSwgb25CZWZvcmVSb3V0ZVVwZGF0ZSwgcGFyc2VRdWVyeSwgcm91dGVMb2NhdGlvbktleSwgcm91dGVyS2V5LCByb3V0ZXJWaWV3TG9jYXRpb25LZXksIHN0cmluZ2lmeVF1ZXJ5LCB1c2VMaW5rLCB1c2VSb3V0ZSwgdXNlUm91dGVyLCB2aWV3RGVwdGhLZXkgfTsiXSwibWFwcGluZ3MiOiI7O0FBQUEsU0FBZ0Isd0JBQXdCO0NBQ3BDLE9BQU8sVUFBVSxDQUFDLENBQUM7QUFDdkI7QUFDQSxTQUFnQixZQUFZO0NBRXhCLE9BQVEsT0FBTyxjQUFjLGVBQWUsT0FBTyxXQUFXLGNBQ3hELFNBQ0EsT0FBTyxlQUFlLGNBQ2xCLGFBQ0EsQ0FBQztBQUNmO0FBQ0EsSUFBYSxtQkFBbUIsT0FBTyxVQUFVOzs7QUNYakQsSUFBYSxhQUFhO0FBQzFCLElBQWEsMkJBQTJCOzs7QUNEeEMsSUFBSTtBQUNKLElBQUk7QUFDSixTQUFnQix5QkFBeUI7Q0FDckMsSUFBSTtDQUNKLElBQUksY0FBYyxLQUFBLEdBQ2QsT0FBTztDQUVYLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxhQUFhO0VBQ3JELFlBQVk7RUFDWixPQUFPLE9BQU87Q0FDbEIsT0FDSyxJQUFJLE9BQU8sZUFBZSxpQkFBaUIsS0FBSyxXQUFXLGdCQUFnQixRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLGNBQWM7RUFDOUgsWUFBWTtFQUNaLE9BQU8sV0FBVyxXQUFXO0NBQ2pDLE9BRUksWUFBWTtDQUVoQixPQUFPO0FBQ1g7QUFDQSxTQUFnQixNQUFNO0NBQ2xCLE9BQU8sdUJBQXVCLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJO0FBQzVEOzs7QUNwQkEsSUFBYSxXQUFiLE1BQXNCO0NBQ2xCLFlBQVksUUFBUSxNQUFNO0VBQ3RCLEtBQUssU0FBUztFQUNkLEtBQUssY0FBYyxDQUFDO0VBQ3BCLEtBQUssVUFBVSxDQUFDO0VBQ2hCLEtBQUssU0FBUztFQUNkLEtBQUssT0FBTztFQUNaLE1BQU0sa0JBQWtCLENBQUM7RUFDekIsSUFBSSxPQUFPLFVBQ1AsS0FBSyxNQUFNLE1BQU0sT0FBTyxVQUVwQixnQkFBZ0IsTUFESCxPQUFPLFNBQVMsR0FDSCxDQUFDO0VBR25DLE1BQU0sc0JBQXNCLG1DQUFtQyxPQUFPO0VBQ3RFLElBQUksa0JBQWtCLE9BQU8sT0FBTyxDQUFDLEdBQUcsZUFBZTtFQUN2RCxJQUFJO0dBQ0EsTUFBTSxNQUFNLGFBQWEsUUFBUSxtQkFBbUI7R0FDcEQsTUFBTSxPQUFPLEtBQUssTUFBTSxHQUFHO0dBQzNCLE9BQU8sT0FBTyxpQkFBaUIsSUFBSTtFQUN2QyxTQUNPLEdBQUcsQ0FFVjtFQUNBLEtBQUssWUFBWTtHQUNiLGNBQWM7SUFDVixPQUFPO0dBQ1g7R0FDQSxZQUFZLE9BQU87SUFDZixJQUFJO0tBQ0EsYUFBYSxRQUFRLHFCQUFxQixLQUFLLFVBQVUsS0FBSyxDQUFDO0lBQ25FLFNBQ08sR0FBRyxDQUVWO0lBQ0Esa0JBQWtCO0dBQ3RCO0dBQ0EsTUFBTTtJQUNGLE9BQU8sSUFBSTtHQUNmO0VBQ0o7RUFDQSxJQUFJLE1BQ0EsS0FBSyxHQUFHLDJCQUEyQixVQUFVLFVBQVU7R0FDbkQsSUFBSSxhQUFhLEtBQUssT0FBTyxJQUN6QixLQUFLLFVBQVUsWUFBWSxLQUFLO0VBRXhDLENBQUM7RUFFTCxLQUFLLFlBQVksSUFBSSxNQUFNLENBQUMsR0FBRyxFQUMzQixNQUFNLFNBQVMsU0FBUztHQUNwQixJQUFJLEtBQUssUUFDTCxPQUFPLEtBQUssT0FBTyxHQUFHO1FBR3RCLFFBQVEsR0FBRyxTQUFTO0lBQ2hCLEtBQUssUUFBUSxLQUFLO0tBQ2QsUUFBUTtLQUNSO0lBQ0osQ0FBQztHQUNMO0VBRVIsRUFDSixDQUFDO0VBQ0QsS0FBSyxnQkFBZ0IsSUFBSSxNQUFNLENBQUMsR0FBRyxFQUMvQixNQUFNLFNBQVMsU0FBUztHQUNwQixJQUFJLEtBQUssUUFDTCxPQUFPLEtBQUssT0FBTztRQUVsQixJQUFJLFNBQVMsTUFDZCxPQUFPLEtBQUs7UUFFWCxJQUFJLE9BQU8sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFNBQVMsSUFBSSxHQUM5QyxRQUFRLEdBQUcsU0FBUztJQUNoQixLQUFLLFlBQVksS0FBSztLQUNsQixRQUFRO0tBQ1I7S0FDQSxlQUFlLENBQUU7SUFDckIsQ0FBQztJQUNELE9BQU8sS0FBSyxVQUFVLEtBQUssQ0FBQyxHQUFHLElBQUk7R0FDdkM7UUFHQSxRQUFRLEdBQUcsU0FBUztJQUNoQixPQUFPLElBQUksU0FBUyxZQUFZO0tBQzVCLEtBQUssWUFBWSxLQUFLO01BQ2xCLFFBQVE7TUFDUjtNQUNBO0tBQ0osQ0FBQztJQUNMLENBQUM7R0FDTDtFQUVSLEVBQ0osQ0FBQztDQUNMO0NBQ0EsTUFBTSxjQUFjLFFBQVE7RUFDeEIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxNQUFNLFFBQVEsS0FBSyxTQUNwQixLQUFLLE9BQU8sR0FBRyxLQUFLLE9BQU8sQ0FBQyxHQUFHLEtBQUssSUFBSTtFQUU1QyxLQUFLLE1BQU0sUUFBUSxLQUFLLGFBQ3BCLEtBQUssUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLE9BQU8sQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDO0NBRWpFO0FBQ0o7OztBQ3BHQSxTQUFnQixvQkFBb0Isa0JBQWtCLFNBQVM7Q0FDM0QsTUFBTSxhQUFhO0NBQ25CLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sT0FBTyxzQkFBc0I7Q0FDbkMsTUFBTSxjQUFjLG9CQUFvQixXQUFXO0NBQ25ELElBQUksU0FBUyxPQUFPLHlDQUF5QyxDQUFDLGNBQzFELEtBQUssS0FBSyxZQUFZLGtCQUFrQixPQUFPO01BRTlDO0VBQ0QsTUFBTSxRQUFRLGNBQWMsSUFBSSxTQUFTLFlBQVksSUFBSSxJQUFJO0VBRTdELENBRGEsT0FBTywyQkFBMkIsT0FBTyw0QkFBNEIsQ0FBQyxFQUFBLENBQzlFLEtBQUs7R0FDTixrQkFBa0I7R0FDbEI7R0FDQTtFQUNKLENBQUM7RUFDRCxJQUFJLE9BQ0EsUUFBUSxNQUFNLGFBQWE7Q0FFbkM7QUFDSjs7Ozs7Ozs7QUNqQkEsSUFBTSxZQUFZLE9BQU8sYUFBYTs7Ozs7OztBQWtCdEMsU0FBUyxpQkFBaUIsV0FBVztDQUNwQyxPQUFPLE9BQU8sY0FBYyxZQUFZLGlCQUFpQixhQUFhLFdBQVcsYUFBYSxlQUFlO0FBQzlHO0FBQ0EsU0FBUyxXQUFXLEtBQUs7Q0FDeEIsT0FBTyxJQUFJLGNBQWMsSUFBSSxPQUFPLGlCQUFpQixZQUFZLElBQUksV0FBVyxpQkFBaUIsSUFBSSxPQUFPO0FBQzdHO0FBQ0EsSUFBTSxTQUFTLE9BQU87QUFDdEIsU0FBUyxjQUFjLElBQUksUUFBUTtDQUNsQyxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sT0FBTyxRQUFRO0VBQ3pCLE1BQU0sUUFBUSxPQUFPO0VBQ3JCLFVBQVUsT0FBTyxRQUFRLEtBQUssSUFBSSxNQUFNLElBQUksRUFBRSxJQUFJLEdBQUcsS0FBSztDQUMzRDtDQUNBLE9BQU87QUFDUjtBQUNBLElBQU0sYUFBYSxDQUFDOzs7Ozs7O0FBT3BCLElBQU0sVUFBVSxNQUFNO0FBQ3RCLFNBQVMsYUFBYSxVQUFVLGdCQUFnQjtDQUMvQyxNQUFNLFVBQVUsQ0FBQztDQUNqQixLQUFLLE1BQU0sT0FBTyxVQUFVLFFBQVEsT0FBTyxPQUFPLGlCQUFpQixlQUFlLE9BQU8sU0FBUztDQUNsRyxPQUFPO0FBQ1I7QUFJQSxTQUFTLE9BQU8sS0FBSztDQUNwQixNQUFNLE9BQU8sTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztDQUMxQyxRQUFRLEtBQUssTUFBTSxTQUFTLENBQUMsd0JBQXdCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDO0FBQ3ZFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQkEsSUFBTSxVQUFVO0FBQ2hCLElBQU0sZUFBZTtBQUNyQixJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBQ2pCLElBQU0sUUFBUTtBQUNkLElBQU0sVUFBVTs7Ozs7Ozs7Ozs7Ozs7O0FBZWhCLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sdUJBQXVCO0FBQzdCLElBQU0sZUFBZTtBQUNyQixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxxQkFBcUI7QUFDM0IsSUFBTSxlQUFlOzs7Ozs7Ozs7QUFTckIsU0FBUyxhQUFhLE1BQU07Q0FDM0IsT0FBTyxRQUFRLE9BQU8sS0FBSyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsUUFBUSxhQUFhLEdBQUcsQ0FBQyxDQUFDLFFBQVEscUJBQXFCLEdBQUcsQ0FBQyxDQUFDLFFBQVEsc0JBQXNCLEdBQUc7QUFDOUk7Ozs7Ozs7QUFPQSxTQUFTLFdBQVcsTUFBTTtDQUN6QixPQUFPLGFBQWEsSUFBSSxDQUFDLENBQUMsUUFBUSxtQkFBbUIsR0FBRyxDQUFDLENBQUMsUUFBUSxvQkFBb0IsR0FBRyxDQUFDLENBQUMsUUFBUSxjQUFjLEdBQUc7QUFDckg7Ozs7Ozs7O0FBUUEsU0FBUyxpQkFBaUIsTUFBTTtDQUMvQixPQUFPLGFBQWEsSUFBSSxDQUFDLENBQUMsUUFBUSxTQUFTLEtBQUssQ0FBQyxDQUFDLFFBQVEsY0FBYyxHQUFHLENBQUMsQ0FBQyxRQUFRLFNBQVMsS0FBSyxDQUFDLENBQUMsUUFBUSxjQUFjLEtBQUssQ0FBQyxDQUFDLFFBQVEsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLFFBQVEsb0JBQW9CLEdBQUcsQ0FBQyxDQUFDLFFBQVEsY0FBYyxHQUFHO0FBQzNQOzs7Ozs7QUFNQSxTQUFTLGVBQWUsTUFBTTtDQUM3QixPQUFPLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxRQUFRLFVBQVUsS0FBSztBQUN0RDs7Ozs7OztBQU9BLFNBQVMsV0FBVyxNQUFNO0NBQ3pCLE9BQU8sYUFBYSxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVMsS0FBSyxDQUFDLENBQUMsUUFBUSxPQUFPLEtBQUs7QUFDdkU7Ozs7Ozs7Ozs7QUFVQSxTQUFTLFlBQVksTUFBTTtDQUMxQixPQUFPLFdBQVcsSUFBSSxDQUFDLENBQUMsUUFBUSxVQUFVLEtBQUs7QUFDaEQ7QUFDQSxTQUFTLE9BQU8sTUFBTTtDQUNyQixJQUFJLFFBQVEsTUFBTSxPQUFPO0NBQ3pCLElBQUk7RUFDSCxPQUFPLG1CQUFtQixLQUFLLElBQUk7Q0FDcEMsU0FBUyxLQUFLO0VBQ2IsT0FBZ0QsbUJBQW1CLEtBQUssd0JBQXdCO0NBQ2pHO0NBQ0EsT0FBTyxLQUFLO0FBQ2I7QUFJQSxJQUFNLG9CQUFvQjtBQUMxQixJQUFNLHVCQUF1QixTQUFTLEtBQUssUUFBUSxtQkFBbUIsRUFBRTs7Ozs7Ozs7OztBQVV4RSxTQUFTLFNBQVMsY0FBYyxVQUFVLGtCQUFrQixLQUFLO0NBQ2hFLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxlQUFlLElBQUksT0FBTztDQUNoRCxNQUFNLFVBQVUsU0FBUyxRQUFRLEdBQUc7Q0FDcEMsSUFBSSxZQUFZLFNBQVMsUUFBUSxHQUFHO0NBQ3BDLFlBQVksV0FBVyxLQUFLLFlBQVksVUFBVSxLQUFLO0NBQ3ZELElBQUksYUFBYSxHQUFHO0VBQ25CLE9BQU8sU0FBUyxNQUFNLEdBQUcsU0FBUztFQUNsQyxlQUFlLFNBQVMsTUFBTSxXQUFXLFVBQVUsSUFBSSxVQUFVLFNBQVMsTUFBTTtFQUNoRixRQUFRLGFBQWEsYUFBYSxNQUFNLENBQUMsQ0FBQztDQUMzQztDQUNBLElBQUksV0FBVyxHQUFHO0VBQ2pCLE9BQU8sUUFBUSxTQUFTLE1BQU0sR0FBRyxPQUFPO0VBQ3hDLE9BQU8sU0FBUyxNQUFNLFNBQVMsU0FBUyxNQUFNO0NBQy9DO0NBQ0EsT0FBTyxvQkFBb0IsUUFBUSxPQUFPLE9BQU8sVUFBVSxlQUFlO0NBQzFFLE9BQU87RUFDTixVQUFVLE9BQU8sZUFBZTtFQUNoQztFQUNBO0VBQ0EsTUFBTSxPQUFPLElBQUk7Q0FDbEI7QUFDRDs7Ozs7OztBQVdBLFNBQVMsYUFBYSxrQkFBa0IsVUFBVTtDQUNqRCxNQUFNLFFBQVEsU0FBUyxRQUFRLGlCQUFpQixTQUFTLEtBQUssSUFBSTtDQUNsRSxPQUFPLFNBQVMsUUFBUSxTQUFTLE9BQU8sU0FBUyxTQUFTLFFBQVE7QUFDbkU7Ozs7Ozs7QUFPQSxTQUFTLFVBQVUsVUFBVSxNQUFNO0NBQ2xDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxZQUFZLENBQUMsQ0FBQyxXQUFXLEtBQUssWUFBWSxDQUFDLEdBQUcsT0FBTztDQUM1RSxPQUFPLFNBQVMsTUFBTSxLQUFLLE1BQU0sS0FBSztBQUN2Qzs7Ozs7Ozs7OztBQVVBLFNBQVMsb0JBQW9CLGtCQUFrQixHQUFHLEdBQUc7Q0FDcEQsTUFBTSxhQUFhLEVBQUUsUUFBUSxTQUFTO0NBQ3RDLE1BQU0sYUFBYSxFQUFFLFFBQVEsU0FBUztDQUN0QyxPQUFPLGFBQWEsTUFBTSxlQUFlLGNBQWMsa0JBQWtCLEVBQUUsUUFBUSxhQUFhLEVBQUUsUUFBUSxXQUFXLEtBQUssMEJBQTBCLEVBQUUsUUFBUSxFQUFFLE1BQU0sS0FBSyxpQkFBaUIsRUFBRSxLQUFLLE1BQU0saUJBQWlCLEVBQUUsS0FBSyxLQUFLLEVBQUUsU0FBUyxFQUFFO0FBQ3BQOzs7Ozs7OztBQVFBLFNBQVMsa0JBQWtCLEdBQUcsR0FBRztDQUNoQyxRQUFRLEVBQUUsV0FBVyxRQUFRLEVBQUUsV0FBVztBQUMzQztBQUNBLFNBQVMsMEJBQTBCLEdBQUcsR0FBRztDQUN4QyxJQUFJLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLE9BQU87Q0FDNUQsS0FBSyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsK0JBQStCLEVBQUUsTUFBTSxFQUFFLElBQUksR0FBRyxPQUFPO0NBQy9FLE9BQU87QUFDUjtBQUNBLFNBQVMsK0JBQStCLEdBQUcsR0FBRztDQUM3QyxPQUFPLFFBQVEsQ0FBQyxJQUFJLGtCQUFrQixHQUFHLENBQUMsSUFBSSxRQUFRLENBQUMsSUFBSSxrQkFBa0IsR0FBRyxDQUFDLElBQUksR0FBRyxRQUFRLE1BQU0sR0FBRyxRQUFRO0FBQ2xIOzs7Ozs7OztBQVFBLFNBQVMsa0JBQWtCLEdBQUcsR0FBRztDQUNoQyxPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxPQUFPLE9BQU8sTUFBTSxVQUFVLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxLQUFLLEVBQUUsT0FBTztBQUNqSDs7Ozs7OztBQU9BLFNBQVMsb0JBQW9CLElBQUksTUFBTTtDQUN0QyxJQUFJLEdBQUcsV0FBVyxHQUFHLEdBQUcsT0FBTztDQUMvQixJQUE2QyxDQUFDLEtBQUssV0FBVyxHQUFHLEdBQUc7RUFDbkUsT0FBTyxtRkFBbUYsR0FBRyxVQUFVLEtBQUssMkJBQTJCLEtBQUssR0FBRztFQUMvSSxPQUFPO0NBQ1I7Q0FDQSxJQUFJLENBQUMsSUFBSSxPQUFPO0NBQ2hCLE1BQU0sZUFBZSxLQUFLLE1BQU0sR0FBRztDQUNuQyxNQUFNLGFBQWEsR0FBRyxNQUFNLEdBQUc7Q0FDL0IsTUFBTSxnQkFBZ0IsV0FBVyxXQUFXLFNBQVM7Q0FDckQsSUFBSSxrQkFBa0IsUUFBUSxrQkFBa0IsS0FBSyxXQUFXLEtBQUssRUFBRTtDQUN2RSxJQUFJLFdBQVcsYUFBYSxTQUFTO0NBQ3JDLElBQUk7Q0FDSixJQUFJO0NBQ0osS0FBSyxhQUFhLEdBQUcsYUFBYSxXQUFXLFFBQVEsY0FBYztFQUNsRSxVQUFVLFdBQVc7RUFDckIsSUFBSSxZQUFZLEtBQUs7RUFDckIsSUFBSSxZQUFZLE1BQ1g7T0FBQSxXQUFXLEdBQUc7RUFBQSxPQUNaO0NBQ1I7Q0FDQSxPQUFPLGFBQWEsTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLE1BQU0sV0FBVyxNQUFNLFVBQVUsQ0FBQyxDQUFDLEtBQUssR0FBRztBQUMvRjs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxJQUFNLDRCQUE0QjtDQUNqQyxNQUFNO0NBQ04sTUFBTSxLQUFLO0NBQ1gsUUFBUSxDQUFDO0NBQ1QsT0FBTyxDQUFDO0NBQ1IsTUFBTTtDQUNOLFVBQVU7Q0FDVixTQUFTLENBQUM7Q0FDVixNQUFNLENBQUM7Q0FDUCxnQkFBZ0IsS0FBSztBQUN0QjtBQUlBLElBQUksaUJBQWlDLHlCQUFTLGtCQUFrQjtDQUMvRCxpQkFBaUIsU0FBUztDQUMxQixpQkFBaUIsVUFBVTtDQUMzQixPQUFPO0FBQ1IsRUFBRSxDQUFDLENBQUM7QUFDSixJQUFJLHNCQUFzQyx5QkFBUyx1QkFBdUI7Q0FDekUsc0JBQXNCLFVBQVU7Q0FDaEMsc0JBQXNCLGFBQWE7Q0FDbkMsc0JBQXNCLGFBQWE7Q0FDbkMsT0FBTztBQUNSLEVBQUUsQ0FBQyxDQUFDOzs7Ozs7O0FBV0osU0FBUyxjQUFjLE1BQU07Q0FDNUIsSUFBSSxDQUFDLE1BQU0sSUFBSSxXQUFXO0VBQ3pCLE1BQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtFQUM1QyxPQUFPLFVBQVUsT0FBTyxhQUFhLE1BQU0sS0FBSztFQUNoRCxPQUFPLEtBQUssUUFBUSxtQkFBbUIsRUFBRTtDQUMxQyxPQUFPLE9BQU87Q0FDZCxJQUFJLEtBQUssT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sTUFBTTtDQUNyRCxPQUFPLG9CQUFvQixJQUFJO0FBQ2hDO0FBQ0EsSUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxXQUFXLE1BQU0sVUFBVTtDQUNuQyxPQUFPLEtBQUssUUFBUSxnQkFBZ0IsR0FBRyxJQUFJO0FBQzVDO0FBSUEsU0FBUyxtQkFBbUIsSUFBSSxRQUFRO0NBQ3ZDLE1BQU0sVUFBVSxTQUFTLGdCQUFnQixzQkFBc0I7Q0FDL0QsTUFBTSxTQUFTLEdBQUcsc0JBQXNCO0NBQ3hDLE9BQU87RUFDTixVQUFVLE9BQU87RUFDakIsTUFBTSxPQUFPLE9BQU8sUUFBUSxRQUFRLE9BQU8sUUFBUTtFQUNuRCxLQUFLLE9BQU8sTUFBTSxRQUFRLE9BQU8sT0FBTyxPQUFPO0NBQ2hEO0FBQ0Q7QUFDQSxJQUFNLCtCQUErQjtDQUNwQyxNQUFNLE9BQU87Q0FDYixLQUFLLE9BQU87QUFDYjtBQUNBLFNBQVMsaUJBQWlCLFVBQVU7Q0FDbkMsSUFBSTtDQUNKLElBQUksUUFBUSxVQUFVO0VBQ3JCLE1BQU0sYUFBYSxTQUFTO0VBQzVCLE1BQU0sZUFBZSxPQUFPLGVBQWUsWUFBWSxXQUFXLFdBQVcsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXNCaEYsSUFBNkMsT0FBTyxTQUFTLE9BQU8sVUFDL0Q7T0FBQSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsZUFBZSxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJO0lBQ3hFLE1BQU0sVUFBVSxTQUFTLGNBQWMsU0FBUyxFQUFFO0lBQ2xELElBQUksZ0JBQWdCLFNBQVM7S0FDNUIsT0FBTyxpQkFBaUIsU0FBUyxHQUFHLHFEQUFxRCxTQUFTLEdBQUcsZ0NBQWdDO0tBQ3JJO0lBQ0Q7R0FDRCxTQUFTLEtBQUs7SUFDYixPQUFPLGlCQUFpQixTQUFTLEdBQUcsMlFBQTJRO0lBQy9TO0dBQ0Q7O0VBRUQsTUFBTSxLQUFLLE9BQU8sZUFBZSxXQUFXLGVBQWUsU0FBUyxlQUFlLFdBQVcsTUFBTSxDQUFDLENBQUMsSUFBSSxTQUFTLGNBQWMsVUFBVSxJQUFJO0VBQy9JLElBQUksQ0FBQyxJQUFJO0dBQ1IsT0FBZ0QseUNBQXlDLFNBQVMsR0FBRyw4QkFBOEI7R0FDbkk7RUFDRDtFQUNBLGtCQUFrQixtQkFBbUIsSUFBSSxRQUFRO0NBQ2xELE9BQU8sa0JBQWtCO0NBQ3pCLElBQUksb0JBQW9CLFNBQVMsZ0JBQWdCLE9BQU8sT0FBTyxTQUFTLGVBQWU7TUFDbEYsT0FBTyxTQUFTLGdCQUFnQixRQUFRLE9BQU8sZ0JBQWdCLE9BQU8sT0FBTyxTQUFTLGdCQUFnQixPQUFPLE9BQU8sZ0JBQWdCLE1BQU0sT0FBTyxPQUFPO0FBQzlKO0FBQ0EsU0FBUyxhQUFhLE1BQU0sT0FBTztDQUNsQyxRQUFRLFFBQVEsUUFBUSxRQUFRLE1BQU0sV0FBVyxRQUFRLE1BQU07QUFDaEU7QUFDQSxJQUFNLGtDQUFrQyxJQUFJLElBQUk7QUFDaEQsU0FBUyxtQkFBbUIsS0FBSyxnQkFBZ0I7Q0FDaEQsZ0JBQWdCLElBQUksS0FBSyxjQUFjO0FBQ3hDO0FBQ0EsU0FBUyx1QkFBdUIsS0FBSztDQUNwQyxNQUFNLFNBQVMsZ0JBQWdCLElBQUksR0FBRztDQUN0QyxnQkFBZ0IsT0FBTyxHQUFHO0NBQzFCLE9BQU87QUFDUjs7Ozs7QUFRQSxTQUFTLGdCQUFnQixPQUFPO0NBQy9CLE9BQU8sT0FBTyxVQUFVLFlBQVksU0FBUyxPQUFPLFVBQVU7QUFDL0Q7QUFDQSxTQUFTLFlBQVksTUFBTTtDQUMxQixPQUFPLE9BQU8sU0FBUyxZQUFZLE9BQU8sU0FBUztBQUNwRDs7Ozs7OztBQVVBLElBQUksYUFBNkIseUJBQVMsY0FBYztDQUN2RCxhQUFhLGFBQWEsdUJBQXVCLEtBQUs7Q0FDdEQsYUFBYSxhQUFhLCtCQUErQixLQUFLO0NBQzlELGFBQWEsYUFBYSx3QkFBd0IsS0FBSztDQUN2RCxhQUFhLGFBQWEsMEJBQTBCLEtBQUs7Q0FDekQsYUFBYSxhQUFhLDJCQUEyQixNQUFNO0NBQzNELE9BQU87QUFDUixFQUFFLENBQUMsQ0FBQztBQUNKLElBQU0sMEJBQTBCLE9BQStDLG9CQUF5Qjs7Ozs7QUFLeEcsSUFBSSx3QkFBd0MseUJBQVMseUJBQXlCOzs7OztDQUs3RSx3QkFBd0Isd0JBQXdCLGFBQWEsS0FBSzs7Ozs7Q0FLbEUsd0JBQXdCLHdCQUF3QixlQUFlLEtBQUs7Ozs7O0NBS3BFLHdCQUF3Qix3QkFBd0IsZ0JBQWdCLE1BQU07Q0FDdEUsT0FBTztBQUNSLEVBQUUsQ0FBQyxDQUFDO0FBQ0osSUFBTSxvQkFBb0I7Q0FDekIsQ0FBQyxXQUFXLG1CQUFtQixFQUFFLFVBQVUsbUJBQW1CO0VBQzdELE9BQU8sa0JBQWtCLEtBQUssVUFBVSxRQUFRLElBQUksa0JBQWtCLHVCQUF1QixLQUFLLFVBQVUsZUFBZSxJQUFJO0NBQ2hJO0NBQ0EsQ0FBQyxXQUFXLDJCQUEyQixFQUFFLE1BQU0sTUFBTTtFQUNwRCxPQUFPLG9CQUFvQixLQUFLLFNBQVMsUUFBUSxlQUFlLEVBQUUsRUFBRTtDQUNyRTtDQUNBLENBQUMsV0FBVyxvQkFBb0IsRUFBRSxNQUFNLE1BQU07RUFDN0MsT0FBTyw0QkFBNEIsS0FBSyxTQUFTLFFBQVEsR0FBRyxTQUFTO0NBQ3RFO0NBQ0EsQ0FBQyxXQUFXLHNCQUFzQixFQUFFLE1BQU0sTUFBTTtFQUMvQyxPQUFPLDhCQUE4QixLQUFLLFNBQVMsUUFBUSxHQUFHLFNBQVM7Q0FDeEU7Q0FDQSxDQUFDLFdBQVcsdUJBQXVCLEVBQUUsTUFBTSxNQUFNO0VBQ2hELE9BQU8sc0RBQXNELEtBQUssU0FBUztDQUM1RTtBQUNEOzs7Ozs7O0FBT0EsU0FBUyxrQkFBa0IsTUFBTSxRQUFRO0NBQ1ksT0FBTyxPQUFPLElBQUksTUFBTSxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0VBQzdHO0dBQ0MsMEJBQTBCO0NBQzVCLEdBQUcsTUFBTTtBQUtWO0FBQ0EsU0FBUyxvQkFBb0IsT0FBTyxNQUFNO0NBQ3pDLE9BQU8saUJBQWlCLFNBQVMsMkJBQTJCLFVBQVUsUUFBUSxRQUFRLENBQUMsRUFBRSxNQUFNLE9BQU87QUFDdkc7QUFDQSxJQUFNLGtCQUFrQjtDQUN2QjtDQUNBO0NBQ0E7QUFDRDtBQUNBLFNBQVMsZUFBZSxJQUFJO0NBQzNCLElBQUksT0FBTyxPQUFPLFVBQVUsT0FBTztDQUNuQyxJQUFJLEdBQUcsUUFBUSxNQUFNLE9BQU8sR0FBRztDQUMvQixNQUFNLFdBQVcsQ0FBQztDQUNsQixLQUFLLE1BQU0sT0FBTyxpQkFBaUIsSUFBSSxPQUFPLElBQUksU0FBUyxPQUFPLEdBQUc7Q0FDckUsT0FBTyxLQUFLLFVBQVUsVUFBVSxNQUFNLENBQUM7QUFDeEM7Ozs7Ozs7Ozs7QUFhQSxTQUFTLFdBQVcsUUFBUTtDQUMzQixNQUFNLFFBQVEsQ0FBQztDQUNmLElBQUksV0FBVyxNQUFNLFdBQVcsS0FBSyxPQUFPO0NBQzVDLE1BQU0sZ0JBQWdCLE9BQU8sT0FBTyxNQUFNLE9BQU8sTUFBTSxDQUFDLElBQUksT0FBQSxDQUFRLE1BQU0sR0FBRztDQUM3RSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEVBQUUsR0FBRztFQUM3QyxNQUFNLGNBQWMsYUFBYSxFQUFFLENBQUMsUUFBUSxTQUFTLEdBQUc7RUFDeEQsTUFBTSxRQUFRLFlBQVksUUFBUSxHQUFHO0VBQ3JDLE1BQU0sTUFBTSxPQUFPLFFBQVEsSUFBSSxjQUFjLFlBQVksTUFBTSxHQUFHLEtBQUssQ0FBQztFQUN4RSxNQUFNLFFBQVEsUUFBUSxJQUFJLE9BQU8sT0FBTyxZQUFZLE1BQU0sUUFBUSxDQUFDLENBQUM7RUFDcEUsSUFBSSxPQUFPLE9BQU87R0FDakIsSUFBSSxlQUFlLE1BQU07R0FDekIsSUFBSSxDQUFDLFFBQVEsWUFBWSxHQUFHLGVBQWUsTUFBTSxPQUFPLENBQUMsWUFBWTtHQUNyRSxhQUFhLEtBQUssS0FBSztFQUN4QixPQUFPLE1BQU0sT0FBTztDQUNyQjtDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7OztBQVVBLFNBQVMsZUFBZSxPQUFPO0NBQzlCLElBQUksU0FBUztDQUNiLEtBQUssSUFBSSxPQUFPLE9BQU87RUFDdEIsTUFBTSxRQUFRLE1BQU07RUFDcEIsTUFBTSxlQUFlLEdBQUc7RUFDeEIsSUFBSSxTQUFTLE1BQU07R0FDbEIsSUFBSSxVQUFVLEtBQUssR0FBRyxXQUFXLE9BQU8sU0FBUyxNQUFNLE1BQU07R0FDN0Q7RUFDRDtFQUNBLENBQUMsUUFBUSxLQUFLLElBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLGlCQUFpQixLQUFLLENBQUMsRUFBQSxDQUFHLFNBQVMsWUFBWTtHQUN2SCxJQUFJLFlBQVksS0FBSyxHQUFHO0lBQ3ZCLFdBQVcsT0FBTyxTQUFTLE1BQU0sTUFBTTtJQUN2QyxJQUFJLFdBQVcsTUFBTSxVQUFVLE1BQU07R0FDdEM7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7OztBQVNBLFNBQVMsZUFBZSxPQUFPO0NBQzlCLE1BQU0sa0JBQWtCLENBQUM7Q0FDekIsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN4QixNQUFNLFFBQVEsTUFBTTtFQUNwQixJQUFJLFVBQVUsS0FBSyxHQUFHLGdCQUFnQixPQUFPLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTyxPQUFPLEtBQUssQ0FBQyxJQUFJLFNBQVMsT0FBTyxRQUFRLEtBQUs7Q0FDMUk7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7O0FBV0EsSUFBTSxrQkFBa0IsT0FBK0MsOEJBQW1DOzs7Ozs7O0FBTzFHLElBQU0sZUFBZSxPQUErQyxtQkFBd0I7Ozs7Ozs7QUFPNUYsSUFBTSxZQUFZLE9BQStDLFFBQWE7Ozs7Ozs7QUFPOUUsSUFBTSxtQkFBbUIsT0FBK0MsZ0JBQXFCOzs7Ozs7O0FBTzdGLElBQU0sd0JBQXdCLE9BQStDLHNCQUEyQjs7OztBQU94RyxTQUFTLGVBQWU7Q0FDdkIsSUFBSSxXQUFXLENBQUM7Q0FDaEIsU0FBUyxJQUFJLFNBQVM7RUFDckIsU0FBUyxLQUFLLE9BQU87RUFDckIsYUFBYTtHQUNaLE1BQU0sSUFBSSxTQUFTLFFBQVEsT0FBTztHQUNsQyxJQUFJLElBQUksSUFBSSxTQUFTLE9BQU8sR0FBRyxDQUFDO0VBQ2pDO0NBQ0Q7Q0FDQSxTQUFTLFFBQVE7RUFDaEIsV0FBVyxDQUFDO0NBQ2I7Q0FDQSxPQUFPO0VBQ047RUFDQSxZQUFZLFNBQVMsTUFBTTtFQUMzQjtDQUNEO0FBQ0Q7QUFJQSxTQUFTLGNBQWMsUUFBUSxNQUFNLE9BQU87Q0FDM0MsTUFBTSx1QkFBdUI7RUFDNUIsT0FBTyxLQUFLLENBQUMsT0FBTyxLQUFLO0NBQzFCO0NBQ0EsWUFBWSxjQUFjO0NBQzFCLGNBQWMsY0FBYztDQUM1QixrQkFBa0I7RUFDakIsT0FBTyxLQUFLLENBQUMsSUFBSSxLQUFLO0NBQ3ZCLENBQUM7Q0FDRCxPQUFPLEtBQUssQ0FBQyxJQUFJLEtBQUs7QUFDdkI7Ozs7Ozs7O0FBUUEsU0FBUyxtQkFBbUIsWUFBWTtDQUN2QyxJQUE2QyxDQUFDLG1CQUFtQixHQUFHO0VBQ25FLE9BQU8sd0dBQXdHO0VBQy9HO0NBQ0Q7Q0FDQSxNQUFNLGVBQWUsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUNqRCxJQUFJLENBQUMsY0FBYztFQUNsQixPQUFnRCwwTEFBMEw7RUFDMU87Q0FDRDtDQUNBLGNBQWMsY0FBYyxlQUFlLFVBQVU7QUFDdEQ7Ozs7Ozs7O0FBUUEsU0FBUyxvQkFBb0IsYUFBYTtDQUN6QyxJQUE2QyxDQUFDLG1CQUFtQixHQUFHO0VBQ25FLE9BQU8seUdBQXlHO0VBQ2hIO0NBQ0Q7Q0FDQSxNQUFNLGVBQWUsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUNqRCxJQUFJLENBQUMsY0FBYztFQUNsQixPQUFnRCwyTEFBMkw7RUFDM087Q0FDRDtDQUNBLGNBQWMsY0FBYyxnQkFBZ0IsV0FBVztBQUN4RDtBQUNBLFNBQVMsaUJBQWlCLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTSxrQkFBa0IsT0FBTyxHQUFHLEdBQUc7Q0FDdkYsTUFBTSxxQkFBcUIsV0FBVyxPQUFPLGVBQWUsUUFBUSxPQUFPLGVBQWUsU0FBUyxDQUFDO0NBQ3BHLGFBQWEsSUFBSSxTQUFTLFNBQVMsV0FBVztFQUM3QyxNQUFNLFFBQVEsVUFBVTtHQUN2QixJQUFJLFVBQVUsT0FBTyxPQUFPLGtCQUFrQixXQUFXLG9CQUFvQjtJQUM1RTtJQUNBO0dBQ0QsQ0FBQyxDQUFDO1FBQ0csSUFBSSxpQkFBaUIsT0FBTyxPQUFPLEtBQUs7UUFDeEMsSUFBSSxnQkFBZ0IsS0FBSyxHQUFHLE9BQU8sa0JBQWtCLFdBQVcsMkJBQTJCO0lBQy9GLE1BQU07SUFDTixJQUFJO0dBQ0wsQ0FBQyxDQUFDO1FBQ0c7SUFDSixJQUFJLHNCQUFzQixPQUFPLGVBQWUsVUFBVSxzQkFBc0IsT0FBTyxVQUFVLFlBQVksbUJBQW1CLEtBQUssS0FBSztJQUMxSSxRQUFRO0dBQ1Q7RUFDRDtFQUNBLE1BQU0sY0FBYyxxQkFBcUIsTUFBTSxLQUFLLFVBQVUsT0FBTyxVQUFVLE9BQU8sSUFBSSxNQUE4QyxvQkFBb0IsTUFBTSxJQUFJLElBQUksQ0FBUSxDQUFDO0VBQ25MLElBQUksWUFBWSxRQUFRLFFBQVEsV0FBVztFQUMzQyxJQUFJLE1BQU0sU0FBUyxHQUFHLFlBQVksVUFBVSxLQUFLLElBQUk7RUFDckQsSUFBNkMsTUFBTSxTQUFTLEdBQUc7R0FDOUQsTUFBTSxVQUFVLGtEQUFrRCxNQUFNLE9BQU8sT0FBTyxNQUFNLE9BQU8sT0FBTyxHQUFHLEtBQUssTUFBTSxTQUFTLEVBQUU7R0FDbkksSUFBSSxPQUFPLGdCQUFnQixZQUFZLFVBQVUsYUFBYSxZQUFZLFVBQVUsTUFBTSxrQkFBa0I7SUFDM0csSUFBSSxDQUFDLEtBQUssU0FBUztLQUNsQixPQUFPLE9BQU87S0FDZCxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSwwQkFBMEIsQ0FBQztJQUM1RTtJQUNBLE9BQU87R0FDUixDQUFDO1FBQ0ksSUFBSSxnQkFBZ0IsS0FBSyxHQUN6QjtRQUFBLENBQUMsS0FBSyxTQUFTO0tBQ2xCLE9BQU8sT0FBTztLQUNkLHVCQUF1QixJQUFJLE1BQU0sMEJBQTBCLENBQUM7S0FDNUQ7SUFDRDs7RUFFRjtFQUNBLFVBQVUsT0FBTyxRQUFRLE9BQU8sR0FBRyxDQUFDO0NBQ3JDLENBQUM7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLE1BQU0sSUFBSSxNQUFNO0NBQzVDLElBQUksU0FBUztDQUNiLE9BQU8sV0FBVztFQUNqQixJQUFJLGFBQWEsR0FBRyxPQUFPLDBGQUEwRixLQUFLLFNBQVMsUUFBUSxHQUFHLFNBQVMsZ0dBQWdHO0VBQ3ZQLEtBQUssVUFBVTtFQUNmLElBQUksV0FBVyxHQUFHLEtBQUssTUFBTSxNQUFNLFNBQVM7Q0FDN0M7QUFDRDtBQUNBLFNBQVMsd0JBQXdCLFNBQVMsV0FBVyxJQUFJLE1BQU0sa0JBQWtCLE9BQU8sR0FBRyxHQUFHO0NBQzdGLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxVQUFVLFNBQVM7RUFDN0IsSUFBNkMsQ0FBQyxPQUFPLGNBQWMsT0FBTyxZQUFZLENBQUMsT0FBTyxTQUFTLFFBQVEsT0FBTyxxQkFBcUIsT0FBTyxLQUFLLDZEQUE2RDtFQUNwTixLQUFLLE1BQU0sUUFBUSxPQUFPLFlBQVk7R0FDckMsSUFBSSxlQUFlLE9BQU8sV0FBVztHQUVwQyxJQUFJLENBQUMsZ0JBQWdCLE9BQU8saUJBQWlCLFlBQVksT0FBTyxpQkFBaUIsWUFBWTtJQUM1RixPQUFPLGNBQWMsS0FBSyx5QkFBeUIsT0FBTyxLQUFLLHdDQUF3QyxPQUFPLFlBQVksRUFBRSxHQUFHO0lBQy9ILE1BQU0sSUFBSSxNQUFNLHlCQUF5QjtHQUMxQyxPQUFPLElBQUksVUFBVSxjQUFjO0lBQ2xDLE9BQU8sY0FBYyxLQUFLLHlCQUF5QixPQUFPLEtBQUssNExBQTRMO0lBQzNQLE1BQU0sVUFBVTtJQUNoQixxQkFBcUI7R0FDdEIsT0FBTyxJQUFJLGFBQWEsaUJBQWlCLENBQUMsYUFBYSxxQkFBcUI7SUFDM0UsYUFBYSxzQkFBc0I7SUFDbkMsT0FBTyxjQUFjLEtBQUsseUJBQXlCLE9BQU8sS0FBSyxtSkFBbUo7R0FDbk47R0FFRCxJQUFJLGNBQWMsc0JBQXNCLENBQUMsT0FBTyxVQUFVLE9BQU87R0FDakUsSUFBSSxpQkFBaUIsWUFBWSxHQUFHO0lBQ25DLE1BQU0sU0FBUyxhQUFhLGFBQWEsYUFBQSxDQUFjO0lBQ3ZELFNBQVMsT0FBTyxLQUFLLGlCQUFpQixPQUFPLElBQUksTUFBTSxRQUFRLE1BQU0sY0FBYyxDQUFDO0dBQ3JGLE9BQU87SUFDTixJQUFJLG1CQUFtQixhQUFhO0lBQ3BDLElBQTZDLEVBQUUsV0FBVyxtQkFBbUI7S0FDNUUsT0FBTyxjQUFjLEtBQUsseUJBQXlCLE9BQU8sS0FBSywyTEFBMkw7S0FDMVAsbUJBQW1CLFFBQVEsUUFBUSxnQkFBZ0I7SUFDcEQ7SUFDQSxPQUFPLFdBQVcsaUJBQWlCLE1BQU0sYUFBYTtLQUNyRCxJQUFJLENBQUMsVUFBVSxNQUFNLElBQUksTUFBTSwrQkFBK0IsS0FBSyxRQUFRLE9BQU8sS0FBSyxFQUFFO0tBQ3pGLE1BQU0sb0JBQW9CLFdBQVcsUUFBUSxJQUFJLFNBQVMsVUFBVTtLQUNwRSxPQUFPLEtBQUssUUFBUTtLQUNwQixPQUFPLFdBQVcsUUFBUTtLQUMxQixNQUFNLFNBQVMsa0JBQWtCLGFBQWEsa0JBQUEsQ0FBbUI7S0FDakUsT0FBTyxTQUFTLGlCQUFpQixPQUFPLElBQUksTUFBTSxRQUFRLE1BQU0sY0FBYyxDQUFDLENBQUM7SUFDakYsQ0FBQyxDQUFDO0dBQ0g7RUFDRDtDQUNEO0NBQ0EsT0FBTztBQUNSOzs7Ozs7QUFNQSxTQUFTLGtCQUFrQixPQUFPO0NBQ2pDLE9BQU8sTUFBTSxRQUFRLE9BQU8sV0FBVyxPQUFPLFFBQVEsSUFBSSxRQUFRLHVCQUF1QixJQUFJLE1BQU0scUNBQXFDLENBQUMsSUFBSSxRQUFRLElBQUksTUFBTSxRQUFRLEtBQUssV0FBVyxPQUFPLGNBQWMsUUFBUSxJQUFJLE9BQU8sS0FBSyxPQUFPLFVBQVUsQ0FBQyxDQUFDLFFBQVEsVUFBVSxTQUFTO0VBQ2pSLE1BQU0sZUFBZSxPQUFPLFdBQVc7RUFDdkMsSUFBSSxPQUFPLGlCQUFpQixjQUFjLEVBQUUsaUJBQWlCLGVBQWUsU0FBUyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE1BQU0sYUFBYTtHQUMzSCxJQUFJLENBQUMsVUFBVSxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSwrQkFBK0IsS0FBSyxRQUFRLE9BQU8sS0FBSyx3REFBd0QsQ0FBQztHQUNoTCxNQUFNLG9CQUFvQixXQUFXLFFBQVEsSUFBSSxTQUFTLFVBQVU7R0FDcEUsT0FBTyxLQUFLLFFBQVE7R0FDcEIsT0FBTyxXQUFXLFFBQVE7RUFDM0IsQ0FBQyxDQUFDO0VBQ0YsT0FBTztDQUNSLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUs7QUFDM0I7Ozs7Ozs7O0FBUUEsU0FBUyx1QkFBdUIsSUFBSSxNQUFNO0NBQ3pDLE1BQU0saUJBQWlCLENBQUM7Q0FDeEIsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixNQUFNLGtCQUFrQixDQUFDO0NBQ3pCLE1BQU0sTUFBTSxLQUFLLElBQUksS0FBSyxRQUFRLFFBQVEsR0FBRyxRQUFRLE1BQU07Q0FDM0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztFQUM3QixNQUFNLGFBQWEsS0FBSyxRQUFRO0VBQ2hDLElBQUksWUFBWSxJQUFJLEdBQUcsUUFBUSxNQUFNLFdBQVcsa0JBQWtCLFFBQVEsVUFBVSxDQUFDLEdBQUcsZ0JBQWdCLEtBQUssVUFBVTtPQUNsSCxlQUFlLEtBQUssVUFBVTtFQUNuQyxNQUFNLFdBQVcsR0FBRyxRQUFRO0VBQzVCLElBQUksVUFDQztPQUFBLENBQUMsS0FBSyxRQUFRLE1BQU0sV0FBVyxrQkFBa0IsUUFBUSxRQUFRLENBQUMsR0FBRyxnQkFBZ0IsS0FBSyxRQUFRO0VBQUE7Q0FFeEc7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0NBQ0Q7QUFDRDs7Ozs7Ozs7QUFXQSxTQUFTLG9CQUFvQixlQUFlLFNBQVM7Q0FDcEQsTUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFHLGVBQWUsRUFBRSxTQUFTLGNBQWMsUUFBUSxLQUFLLFlBQVksS0FBSyxTQUFTO0VBQ3RHO0VBQ0E7RUFDQTtDQUNELENBQUMsQ0FBQyxFQUFFLENBQUM7Q0FDTCxPQUFPLEVBQUUsU0FBUztFQUNqQixNQUFNO0VBQ04sVUFBVTtFQUNWLFNBQVMsY0FBYztFQUN2QjtFQUNBLE9BQU87Q0FDUixFQUFFO0FBQ0g7QUFDQSxTQUFTLGNBQWMsU0FBUztDQUMvQixPQUFPLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRTtBQUMvQjtBQUNBLElBQUksV0FBVztBQUNmLFNBQVMsWUFBWSxLQUFLLFFBQVEsU0FBUztDQUMxQyxJQUFJLE9BQU8sZUFBZTtDQUMxQixPQUFPLGdCQUFnQjtDQUN2QixNQUFNLEtBQUs7Q0FDWCxvQkFBb0I7RUFDbkIsSUFBSSxzQkFBc0IsS0FBSyxNQUFNLEtBQUs7RUFDMUMsT0FBTztFQUNQLGFBQWE7RUFDYixVQUFVO0VBQ1YsTUFBTTtFQUNOLHFCQUFxQixDQUFDLFNBQVM7RUFDL0I7Q0FDRCxJQUFJLFFBQVE7RUFDWCxJQUFJLE9BQU8sSUFBSSxRQUFRLFlBQVksT0FBTyx1TkFBdU47RUFDalEsSUFBSSxHQUFHLGtCQUFrQixTQUFTLFFBQVE7R0FDekMsSUFBSSxRQUFRLGNBQWMsUUFBUSxhQUFhLE1BQU0sS0FBSztJQUN6RCxNQUFNO0lBQ04sS0FBSztJQUNMLFVBQVU7SUFDVixPQUFPLG9CQUFvQixPQUFPLGFBQWEsT0FBTyxlQUFlO0dBQ3RFLENBQUM7RUFDRixDQUFDO0VBQ0QsSUFBSSxHQUFHLG9CQUFvQixFQUFFLFVBQVUsTUFBTSx3QkFBd0I7R0FDcEUsSUFBSSxrQkFBa0IsZ0JBQWdCO0lBQ3JDLE1BQU0sT0FBTyxrQkFBa0I7SUFDL0IsS0FBSyxLQUFLLEtBQUs7S0FDZCxRQUFRLEtBQUssT0FBTyxHQUFHLEtBQUssS0FBSyxTQUFTLEVBQUUsTUFBTSxNQUFNLEtBQUs7S0FDN0QsV0FBVztLQUNYLFNBQVM7S0FDVCxpQkFBaUI7SUFDbEIsQ0FBQztHQUNGO0dBQ0EsSUFBSSxRQUFRLGtCQUFrQixjQUFjLEdBQUc7SUFDOUMsa0JBQWtCLGdCQUFnQjtJQUNsQyxrQkFBa0IsZUFBZSxTQUFTLGlCQUFpQjtLQUMxRCxJQUFJLFFBQVEsYUFBYSxNQUFNO0tBQy9CLElBQUksa0JBQWtCO0tBQ3RCLElBQUksVUFBVTtLQUNkLElBQUksWUFBWTtLQUNoQixJQUFJLGFBQWEsT0FBTztNQUN2QixRQUFRLGFBQWE7TUFDckIsa0JBQWtCO01BQ2xCLFlBQVk7S0FDYixPQUFPLElBQUksYUFBYSxlQUFlO01BQ3RDLGtCQUFrQjtNQUNsQixVQUFVO0tBQ1gsT0FBTyxJQUFJLGFBQWEsVUFBVTtNQUNqQyxrQkFBa0I7TUFDbEIsVUFBVTtLQUNYO0tBQ0EsS0FBSyxLQUFLLEtBQUs7TUFDZDtNQUNBO01BQ0E7TUFDQTtLQUNELENBQUM7SUFDRixDQUFDO0dBQ0Y7RUFDRCxDQUFDO0VBQ0QsTUFBTSxPQUFPLG9CQUFvQjtHQUNoQyxrQkFBa0I7R0FDbEIsSUFBSSxzQkFBc0I7R0FDMUIsSUFBSSxrQkFBa0IsaUJBQWlCO0dBQ3ZDLElBQUksbUJBQW1CLGlCQUFpQjtFQUN6QyxDQUFDO0VBQ0QsTUFBTSxxQkFBcUIsd0JBQXdCO0VBQ25ELElBQUksaUJBQWlCO0dBQ3BCLElBQUk7R0FDSixPQUFPLFNBQVMsS0FBSyxNQUFNLEtBQUssR0FBRztHQUNuQyxPQUFPO0VBQ1IsQ0FBQztFQUNELE9BQU8sU0FBUyxPQUFPLE9BQU87R0FDN0IsSUFBSSxpQkFBaUI7SUFDcEIsU0FBUztJQUNULE9BQU87S0FDTixPQUFPO0tBQ1AsVUFBVSxHQUFHO0tBQ2IsU0FBUztLQUNULE1BQU0sSUFBSSxJQUFJO0tBQ2QsTUFBTSxFQUFFLE1BQU07S0FDZCxTQUFTLEdBQUcsS0FBSztJQUNsQjtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsSUFBSSxlQUFlO0VBQ25CLE9BQU8sWUFBWSxJQUFJLFNBQVM7R0FDL0IsTUFBTSxPQUFPO0lBQ1osT0FBTyxjQUFjLFlBQVk7SUFDakMsTUFBTSxvQkFBb0IsTUFBTSx5Q0FBeUM7SUFDekUsSUFBSSxvQkFBb0IsSUFBSSxpQkFBaUI7R0FDOUM7R0FDQSxPQUFPLGVBQWUsR0FBRyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sZUFBZSxDQUFDO0dBQzFFLElBQUksaUJBQWlCO0lBQ3BCLFNBQVM7SUFDVCxPQUFPO0tBQ04sTUFBTSxJQUFJLElBQUk7S0FDZCxPQUFPO0tBQ1AsVUFBVSxHQUFHO0tBQ2I7S0FDQSxTQUFTLEdBQUcsS0FBSztJQUNsQjtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTyxXQUFXLElBQUksTUFBTSxZQUFZO0dBQ3ZDLE1BQU0sT0FBTyxFQUFFLE9BQU8sY0FBYyxXQUFXLEVBQUU7R0FDakQsSUFBSSxTQUFTO0lBQ1osS0FBSyxVQUFVLEVBQUUsU0FBUztLQUN6QixNQUFNO0tBQ04sVUFBVTtLQUNWLFNBQVMsVUFBVSxRQUFRLFVBQVU7S0FDckMsU0FBUztLQUNULE9BQU87SUFDUixFQUFFO0lBQ0YsS0FBSyxTQUFTLGNBQWMsR0FBRztHQUNoQyxPQUFPLEtBQUssU0FBUyxjQUFjLEdBQUc7R0FDdEMsS0FBSyxPQUFPLG9CQUFvQixNQUFNLHlDQUF5QztHQUMvRSxLQUFLLEtBQUssb0JBQW9CLElBQUksaUJBQWlCO0dBQ25ELElBQUksaUJBQWlCO0lBQ3BCLFNBQVM7SUFDVCxPQUFPO0tBQ04sT0FBTztLQUNQLFVBQVUsR0FBRztLQUNiLE1BQU0sSUFBSSxJQUFJO0tBQ2Q7S0FDQSxTQUFTLFVBQVUsWUFBWTtLQUMvQixTQUFTLEdBQUcsS0FBSztJQUNsQjtHQUNELENBQUM7RUFDRixDQUFDOzs7O0VBSUQsTUFBTSxvQkFBb0Isc0JBQXNCO0VBQ2hELElBQUksYUFBYTtHQUNoQixJQUFJO0dBQ0osT0FBTyxZQUFZLEtBQUssTUFBTSxLQUFLO0dBQ25DLE1BQU07R0FDTix1QkFBdUI7RUFDeEIsQ0FBQztFQUNELFNBQVMsb0JBQW9CO0dBQzVCLElBQUksQ0FBQyxxQkFBcUI7R0FDMUIsTUFBTSxVQUFVO0dBQ2hCLElBQUksU0FBUyxRQUFRLFVBQVUsQ0FBQyxDQUFDLFFBQVEsVUFBVSxDQUFDLE1BQU0sVUFBVSxDQUFDLE1BQU0sT0FBTyxPQUFPLFVBQVU7R0FDbkcsT0FBTyxRQUFRLDRCQUE0QjtHQUMzQyxJQUFJLFFBQVEsUUFBUSxTQUFTLE9BQU8sUUFBUSxVQUFVLGdCQUFnQixPQUFPLFFBQVEsT0FBTyxZQUFZLENBQUMsQ0FBQztHQUMxRyxPQUFPLFNBQVMsVUFBVSxzQkFBc0IsT0FBTyxPQUFPLGFBQWEsS0FBSyxDQUFDO0dBQ2pGLFFBQVEsWUFBWSxPQUFPLElBQUksNkJBQTZCO0VBQzdEO0VBQ0EsSUFBSTtFQUNKLElBQUksR0FBRyxrQkFBa0IsWUFBWTtHQUNwQyxzQkFBc0I7R0FDdEIsSUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLGdCQUFnQixtQkFBbUIsa0JBQWtCO0VBQ3pGLENBQUM7Ozs7RUFJRCxJQUFJLEdBQUcsbUJBQW1CLFlBQVk7R0FDckMsSUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLGdCQUFnQixtQkFBbUI7SUFDckUsTUFBTSxRQUFRLFFBQVEsVUFBVSxDQUFDLENBQUMsTUFBTSxZQUFZLFFBQVEsT0FBTyxZQUFZLFFBQVEsTUFBTTtJQUM3RixJQUFJLE9BQU8sUUFBUSxRQUFRLEVBQUUsU0FBUywwQ0FBMEMsS0FBSyxFQUFFO0dBQ3hGO0VBQ0QsQ0FBQztFQUNELElBQUksa0JBQWtCLGlCQUFpQjtFQUN2QyxJQUFJLG1CQUFtQixpQkFBaUI7Q0FDekMsQ0FBQztBQUNGO0FBQ0EsU0FBUyxlQUFlLEtBQUs7Q0FDNUIsSUFBSSxJQUFJLFVBQVUsT0FBTyxJQUFJLGFBQWEsTUFBTTtNQUMzQyxPQUFPLElBQUksYUFBYSxNQUFNO0FBQ3BDO0FBQ0EsU0FBUywwQ0FBMEMsT0FBTztDQUN6RCxNQUFNLEVBQUUsV0FBVztDQUNuQixNQUFNLFNBQVMsQ0FBQztFQUNmLFVBQVU7RUFDVixLQUFLO0VBQ0wsT0FBTyxPQUFPO0NBQ2YsQ0FBQztDQUNELElBQUksT0FBTyxRQUFRLE1BQU0sT0FBTyxLQUFLO0VBQ3BDLFVBQVU7RUFDVixLQUFLO0VBQ0wsT0FBTyxPQUFPO0NBQ2YsQ0FBQztDQUNELE9BQU8sS0FBSztFQUNYLFVBQVU7RUFDVixLQUFLO0VBQ0wsT0FBTyxNQUFNO0NBQ2QsQ0FBQztDQUNELElBQUksTUFBTSxLQUFLLFFBQVEsT0FBTyxLQUFLO0VBQ2xDLFVBQVU7RUFDVixLQUFLO0VBQ0wsT0FBTyxFQUFFLFNBQVM7R0FDakIsTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTLE1BQU0sS0FBSyxLQUFLLFFBQVEsR0FBRyxJQUFJLE9BQU8sZUFBZSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRztHQUM5RSxTQUFTO0dBQ1QsT0FBTyxNQUFNO0VBQ2QsRUFBRTtDQUNILENBQUM7Q0FDRCxJQUFJLE9BQU8sWUFBWSxNQUFNLE9BQU8sS0FBSztFQUN4QyxVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU8sT0FBTztDQUNmLENBQUM7Q0FDRCxJQUFJLE1BQU0sTUFBTSxRQUFRLE9BQU8sS0FBSztFQUNuQyxVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU8sTUFBTSxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU8sSUFBSTtDQUNwRCxDQUFDO0NBQ0QsSUFBSSxPQUFPLEtBQUssTUFBTSxPQUFPLElBQUksQ0FBQyxDQUFDLFFBQVEsT0FBTyxLQUFLO0VBQ3RELFVBQVU7RUFDVixLQUFLO0VBQ0wsT0FBTyxNQUFNLE9BQU87Q0FDckIsQ0FBQztDQUNELE9BQU8sS0FBSztFQUNYLEtBQUs7RUFDTCxVQUFVO0VBQ1YsT0FBTyxFQUFFLFNBQVM7R0FDakIsTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLO0dBQ2hFLFNBQVM7R0FDVCxPQUFPLE1BQU07RUFDZCxFQUFFO0NBQ0gsQ0FBQztDQUNELE9BQU87QUFDUjs7OztBQUlBLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBQ2pCLElBQU0sV0FBVztBQUNqQixJQUFNLGFBQWE7QUFDbkIsSUFBTSxPQUFPO0FBQ2IsSUFBTSxVQUFVO0FBQ2hCLElBQU0sVUFBVTtBQUNoQixTQUFTLDhCQUE4QixPQUFPO0NBQzdDLE1BQU0sT0FBTyxDQUFDO0NBQ2QsTUFBTSxFQUFFLFdBQVc7Q0FDbkIsSUFBSSxPQUFPLFFBQVEsTUFBTSxLQUFLLEtBQUs7RUFDbEMsT0FBTyxPQUFPLE9BQU8sSUFBSTtFQUN6QixXQUFXO0VBQ1gsaUJBQWlCO0NBQ2xCLENBQUM7Q0FDRCxJQUFJLE9BQU8sU0FBUyxLQUFLLEtBQUs7RUFDN0IsT0FBTztFQUNQLFdBQVc7RUFDWCxpQkFBaUI7Q0FDbEIsQ0FBQztDQUNELElBQUksTUFBTSxZQUFZLEtBQUssS0FBSztFQUMvQixPQUFPO0VBQ1AsV0FBVztFQUNYLGlCQUFpQjtDQUNsQixDQUFDO0NBQ0QsSUFBSSxNQUFNLGtCQUFrQixLQUFLLEtBQUs7RUFDckMsT0FBTztFQUNQLFdBQVc7RUFDWCxpQkFBaUI7Q0FDbEIsQ0FBQztDQUNELElBQUksTUFBTSxhQUFhLEtBQUssS0FBSztFQUNoQyxPQUFPO0VBQ1AsV0FBVztFQUNYLGlCQUFpQjtDQUNsQixDQUFDO0NBQ0QsSUFBSSxPQUFPLFVBQVUsS0FBSyxLQUFLO0VBQzlCLE9BQU8sT0FBTyxPQUFPLGFBQWEsV0FBVyxhQUFhLE9BQU8sYUFBYTtFQUM5RSxXQUFXO0VBQ1gsaUJBQWlCO0NBQ2xCLENBQUM7Q0FDRCxJQUFJLEtBQUssT0FBTztDQUNoQixJQUFJLE1BQU0sTUFBTTtFQUNmLEtBQUssT0FBTyxlQUFlO0VBQzNCLE9BQU8sVUFBVTtDQUNsQjtDQUNBLE9BQU87RUFDTjtFQUNBLE9BQU8sT0FBTztFQUNkO0VBQ0EsVUFBVSxNQUFNLFNBQVMsSUFBSSw2QkFBNkI7Q0FDM0Q7QUFDRDtBQUNBLElBQUksZ0JBQWdCO0FBQ3BCLElBQU0sb0JBQW9CO0FBQzFCLFNBQVMsc0JBQXNCLE9BQU8sY0FBYztDQUNuRCxNQUFNLGdCQUFnQixhQUFhLFFBQVEsVUFBVSxrQkFBa0IsYUFBYSxRQUFRLGFBQWEsUUFBUSxTQUFTLElBQUksTUFBTSxNQUFNO0NBQzFJLE1BQU0sbUJBQW1CLE1BQU0sY0FBYztDQUM3QyxJQUFJLENBQUMsZUFBZSxNQUFNLGNBQWMsYUFBYSxRQUFRLE1BQU0sVUFBVSxrQkFBa0IsT0FBTyxNQUFNLE1BQU0sQ0FBQztDQUNuSCxNQUFNLFNBQVMsU0FBUyxlQUFlLHNCQUFzQixZQUFZLFlBQVksQ0FBQztBQUN2RjtBQUNBLFNBQVMsNkJBQTZCLE9BQU87Q0FDNUMsTUFBTSxhQUFhO0NBQ25CLE1BQU0sU0FBUyxRQUFRLDRCQUE0QjtBQUNwRDtBQUNBLFNBQVMsZ0JBQWdCLE9BQU8sUUFBUTtDQUN2QyxNQUFNLFFBQVEsT0FBTyxNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0saUJBQWlCO0NBQ3RELE1BQU0sYUFBYTtDQUNuQixJQUFJLENBQUMsU0FBUyxNQUFNLFNBQVMsR0FBRyxPQUFPO0NBQ3ZDLElBQUksSUFBSSxPQUFPLE1BQU0sRUFBRSxDQUFDLFFBQVEsT0FBTyxFQUFFLEdBQUcsTUFBTSxFQUFFLENBQUMsQ0FBQyxLQUFLLE1BQU0sR0FBRztFQUNuRSxNQUFNLFNBQVMsU0FBUyxVQUFVLGdCQUFnQixPQUFPLE1BQU0sQ0FBQztFQUNoRSxJQUFJLE1BQU0sT0FBTyxTQUFTLE9BQU8sV0FBVyxLQUFLO0dBQ2hELE1BQU0sYUFBYSxNQUFNLEdBQUcsS0FBSyxNQUFNO0dBQ3ZDLE9BQU87RUFDUjtFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sT0FBTyxNQUFNLE9BQU8sS0FBSyxZQUFZO0NBQzNDLE1BQU0sY0FBYyxPQUFPLElBQUk7Q0FDL0IsSUFBSSxDQUFDLE9BQU8sV0FBVyxHQUFHLE1BQU0sWUFBWSxTQUFTLE1BQU0sS0FBSyxLQUFLLFNBQVMsTUFBTSxJQUFJLE9BQU87Q0FDL0YsSUFBSSxZQUFZLFdBQVcsTUFBTSxLQUFLLEtBQUssV0FBVyxNQUFNLEdBQUcsT0FBTztDQUN0RSxJQUFJLE1BQU0sT0FBTyxRQUFRLE9BQU8sTUFBTSxPQUFPLElBQUksQ0FBQyxDQUFDLFNBQVMsTUFBTSxHQUFHLE9BQU87Q0FDNUUsT0FBTyxNQUFNLFNBQVMsTUFBTSxVQUFVLGdCQUFnQixPQUFPLE1BQU0sQ0FBQztBQUNyRTtBQUNBLFNBQVMsS0FBSyxLQUFLLE1BQU07Q0FDeEIsTUFBTSxNQUFNLENBQUM7Q0FDYixLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHLElBQUksT0FBTyxJQUFJO0NBQy9ELE9BQU87QUFDUjs7Ozs7Ozs7QUN2ckNBLElBQUksMkJBQTJCLFNBQVMsV0FBVyxPQUFPLFNBQVM7Ozs7OztBQU1uRSxTQUFTLHNCQUFzQixNQUFNLFlBQVk7Q0FDaEQsTUFBTSxFQUFFLFVBQVUsUUFBUSxTQUFTO0NBQ25DLE1BQU0sVUFBVSxLQUFLLFFBQVEsR0FBRztDQUNoQyxJQUFJLFVBQVUsSUFBSTtFQUNqQixJQUFJLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sT0FBTyxDQUFDLENBQUMsU0FBUztFQUNqRixJQUFJLGVBQWUsS0FBSyxNQUFNLFFBQVE7RUFDdEMsSUFBSSxhQUFhLE9BQU8sS0FBSyxlQUFlLE1BQU07RUFDbEQsT0FBTyxVQUFVLGNBQWMsRUFBRTtDQUNsQztDQUNBLE9BQU8sVUFBVSxVQUFVLElBQUksSUFBSSxTQUFTO0FBQzdDO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTSxjQUFjLGlCQUFpQixTQUFTO0NBQzFFLElBQUksWUFBWSxDQUFDO0NBQ2pCLElBQUksWUFBWSxDQUFDO0NBQ2pCLElBQUksYUFBYTtDQUNqQixNQUFNLG1CQUFtQixFQUFFLFlBQVk7RUFDdEMsTUFBTSxLQUFLLHNCQUFzQixNQUFNLFFBQVE7RUFDL0MsTUFBTSxPQUFPLGdCQUFnQjtFQUM3QixNQUFNLFlBQVksYUFBYTtFQUMvQixJQUFJLFFBQVE7RUFDWixJQUFJLE9BQU87R0FDVixnQkFBZ0IsUUFBUTtHQUN4QixhQUFhLFFBQVE7R0FDckIsSUFBSSxjQUFjLGVBQWUsTUFBTTtJQUN0QyxhQUFhO0lBQ2I7R0FDRDtHQUNBLFFBQVEsWUFBWSxNQUFNLFdBQVcsVUFBVSxXQUFXO0VBQzNELE9BQU8sUUFBUSxFQUFFO0VBQ2pCLFVBQVUsU0FBUyxhQUFhO0dBQy9CLFNBQVMsZ0JBQWdCLE9BQU8sTUFBTTtJQUNyQztJQUNBLE1BQU0sZUFBZTtJQUNyQixXQUFXLFFBQVEsUUFBUSxJQUFJLG9CQUFvQixVQUFVLG9CQUFvQixPQUFPLG9CQUFvQjtHQUM3RyxDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsU0FBUyxpQkFBaUI7RUFDekIsYUFBYSxnQkFBZ0I7Q0FDOUI7Q0FDQSxTQUFTLE9BQU8sVUFBVTtFQUN6QixVQUFVLEtBQUssUUFBUTtFQUN2QixNQUFNLGlCQUFpQjtHQUN0QixNQUFNLFFBQVEsVUFBVSxRQUFRLFFBQVE7R0FDeEMsSUFBSSxRQUFRLElBQUksVUFBVSxPQUFPLE9BQU8sQ0FBQztFQUMxQztFQUNBLFVBQVUsS0FBSyxRQUFRO0VBQ3ZCLE9BQU87Q0FDUjtDQUNBLFNBQVMsdUJBQXVCO0VBQy9CLElBQUksU0FBUyxvQkFBb0IsVUFBVTtHQUMxQyxNQUFNLEVBQUUsU0FBUyxjQUFjO0dBQy9CLElBQUksQ0FBQyxVQUFVLE9BQU87R0FDdEIsVUFBVSxhQUFhLE9BQU8sQ0FBQyxHQUFHLFVBQVUsT0FBTyxFQUFFLFFBQVEsc0JBQXNCLEVBQUUsQ0FBQyxHQUFHLEVBQUU7RUFDNUY7Q0FDRDtDQUNBLFNBQVMsVUFBVTtFQUNsQixLQUFLLE1BQU0sWUFBWSxXQUFXLFNBQVM7RUFDM0MsWUFBWSxDQUFDO0VBQ2IsT0FBTyxvQkFBb0IsWUFBWSxlQUFlO0VBQ3RELE9BQU8sb0JBQW9CLFlBQVksb0JBQW9CO0VBQzNELFNBQVMsb0JBQW9CLG9CQUFvQixvQkFBb0I7Q0FDdEU7Q0FDQSxPQUFPLGlCQUFpQixZQUFZLGVBQWU7Q0FDbkQsT0FBTyxpQkFBaUIsWUFBWSxvQkFBb0I7Q0FDeEQsU0FBUyxpQkFBaUIsb0JBQW9CLG9CQUFvQjtDQUNsRSxPQUFPO0VBQ047RUFDQTtFQUNBO0NBQ0Q7QUFDRDs7OztBQUlBLFNBQVMsV0FBVyxNQUFNLFNBQVMsU0FBUyxXQUFXLE9BQU8sZ0JBQWdCLE9BQU87Q0FDcEYsT0FBTztFQUNOO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsVUFBVSxPQUFPLFFBQVE7RUFDekIsUUFBUSxnQkFBZ0Isc0JBQXNCLElBQUk7Q0FDbkQ7QUFDRDtBQUNBLFNBQVMsMEJBQTBCLE1BQU07Q0FDeEMsTUFBTSxFQUFFLFNBQVMsV0FBVyxVQUFVLGVBQWU7Q0FDckQsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLHNCQUFzQixNQUFNLFVBQVUsRUFBRTtDQUN6RSxNQUFNLGVBQWUsRUFBRSxPQUFPLFVBQVUsTUFBTTtDQUM5QyxJQUFJLENBQUMsYUFBYSxPQUFPLGVBQWUsZ0JBQWdCLE9BQU87RUFDOUQsTUFBTTtFQUNOLFNBQVMsZ0JBQWdCO0VBQ3pCLFNBQVM7RUFDVCxVQUFVLFVBQVUsU0FBUztFQUM3QixVQUFVO0VBQ1YsUUFBUTtDQUNULEdBQUcsSUFBSTtDQUNQLFNBQVMsZUFBZSxJQUFJLE9BQU8sV0FBVzs7Ozs7Ozs7OztFQVU3QyxNQUFNLFlBQVksS0FBSyxRQUFRLEdBQUc7RUFDbEMsTUFBTSxNQUFNLFlBQVksTUFBTSxXQUFXLFFBQVEsU0FBUyxjQUFjLE1BQU0sSUFBSSxPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssS0FBSyxtQkFBbUIsSUFBSSxPQUFPO0VBQ3JKLElBQUk7R0FDSCxVQUFVLFlBQVksaUJBQWlCLFlBQVksQ0FBQyxPQUFPLElBQUksR0FBRztHQUNsRSxhQUFhLFFBQVE7RUFDdEIsU0FBUyxLQUFLO0dBQzhCLE9BQU8saUNBQWlDLEdBQUc7R0FFdEYsV0FBVyxZQUFZLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDakQ7Q0FDRDtDQUNBLFNBQVMsUUFBUSxJQUFJLE1BQU07RUFDMUIsZUFBZSxJQUFJLE9BQU8sQ0FBQyxHQUFHLFVBQVUsT0FBTyxXQUFXLGFBQWEsTUFBTSxNQUFNLElBQUksYUFBYSxNQUFNLFNBQVMsSUFBSSxHQUFHLE1BQU0sRUFBRSxVQUFVLGFBQWEsTUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJO0VBQ2hMLGdCQUFnQixRQUFRO0NBQ3pCO0NBQ0EsU0FBUyxLQUFLLElBQUksTUFBTTtFQUN2QixNQUFNLGVBQWUsT0FBTyxDQUFDLEdBQUcsYUFBYSxPQUFPLFVBQVUsT0FBTztHQUNwRSxTQUFTO0dBQ1QsUUFBUSxzQkFBc0I7RUFDL0IsQ0FBQztFQUNELElBQTZDLENBQUMsVUFBVSxPQUFPLE9BQU8saVZBQWlWO0VBQ3ZaLGVBQWUsYUFBYSxTQUFTLGNBQWMsSUFBSTtFQUN2RCxlQUFlLElBQUksT0FBTyxDQUFDLEdBQUcsV0FBVyxnQkFBZ0IsT0FBTyxJQUFJLElBQUksR0FBRyxFQUFFLFVBQVUsYUFBYSxXQUFXLEVBQUUsR0FBRyxJQUFJLEdBQUcsS0FBSztFQUNoSSxnQkFBZ0IsUUFBUTtDQUN6QjtDQUNBLE9BQU87RUFDTixVQUFVO0VBQ1YsT0FBTztFQUNQO0VBQ0E7Q0FDRDtBQUNEOzs7Ozs7QUFNQSxTQUFTLGlCQUFpQixNQUFNO0NBQy9CLE9BQU8sY0FBYyxJQUFJO0NBQ3pCLE1BQU0sb0JBQW9CLDBCQUEwQixJQUFJO0NBQ3hELE1BQU0sbUJBQW1CLG9CQUFvQixNQUFNLGtCQUFrQixPQUFPLGtCQUFrQixVQUFVLGtCQUFrQixPQUFPO0NBQ2pJLFNBQVMsR0FBRyxPQUFPLG1CQUFtQixNQUFNO0VBQzNDLElBQUksQ0FBQyxrQkFBa0IsaUJBQWlCLGVBQWU7RUFDdkQsUUFBUSxHQUFHLEtBQUs7Q0FDakI7Q0FDQSxNQUFNLGdCQUFnQixPQUFPO0VBQzVCLFVBQVU7RUFDVjtFQUNBO0VBQ0EsWUFBWSxXQUFXLEtBQUssTUFBTSxJQUFJO0NBQ3ZDLEdBQUcsbUJBQW1CLGdCQUFnQjtDQUN0QyxPQUFPLGVBQWUsZUFBZSxZQUFZO0VBQ2hELFlBQVk7RUFDWixXQUFXLGtCQUFrQixTQUFTO0NBQ3ZDLENBQUM7Q0FDRCxPQUFPLGVBQWUsZUFBZSxTQUFTO0VBQzdDLFlBQVk7RUFDWixXQUFXLGtCQUFrQixNQUFNO0NBQ3BDLENBQUM7Q0FDRCxPQUFPO0FBQ1I7Ozs7Ozs7O0FBV0EsU0FBUyxvQkFBb0IsT0FBTyxJQUFJO0NBQ3ZDLElBQUksWUFBWSxDQUFDO0NBQ2pCLElBQUksUUFBUSxDQUFDLENBQUEsSUFBUSxDQUFDLENBQUMsQ0FBQztDQUN4QixJQUFJLFdBQVc7Q0FDZixPQUFPLGNBQWMsSUFBSTtDQUN6QixTQUFTLFlBQVksWUFBWSxRQUFRLENBQUMsR0FBRztFQUM1QztFQUNBLElBQUksYUFBYSxNQUFNLFFBQVEsTUFBTSxPQUFPLFFBQVE7RUFDcEQsTUFBTSxLQUFLLENBQUMsWUFBWSxLQUFLLENBQUM7Q0FDL0I7Q0FDQSxTQUFTLGlCQUFpQixJQUFJLE1BQU0sRUFBRSxXQUFXLFNBQVM7RUFDekQsTUFBTSxPQUFPO0dBQ1o7R0FDQTtHQUNBLE1BQU0sZUFBZTtFQUN0QjtFQUNBLEtBQUssTUFBTSxZQUFZLFdBQVcsU0FBUyxJQUFJLE1BQU0sSUFBSTtDQUMxRDtDQUNBLE1BQU0sZ0JBQWdCO0VBQ3JCLFVBQUE7RUFDQSxPQUFPLENBQUM7RUFDUjtFQUNBLFlBQVksV0FBVyxLQUFLLE1BQU0sSUFBSTtFQUN0QyxRQUFRLElBQUksT0FBTztHQUNsQixNQUFNLE9BQU8sWUFBWSxDQUFDO0dBQzFCLFlBQVksSUFBSSxLQUFLO0VBQ3RCO0VBQ0EsS0FBSyxJQUFJLE9BQU87R0FDZixZQUFZLElBQUksS0FBSztFQUN0QjtFQUNBLE9BQU8sVUFBVTtHQUNoQixVQUFVLEtBQUssUUFBUTtHQUN2QixhQUFhO0lBQ1osTUFBTSxRQUFRLFVBQVUsUUFBUSxRQUFRO0lBQ3hDLElBQUksUUFBUSxJQUFJLFVBQVUsT0FBTyxPQUFPLENBQUM7R0FDMUM7RUFDRDtFQUNBLFVBQVU7R0FDVCxZQUFZLENBQUM7R0FDYixRQUFRLENBQUMsQ0FBQSxJQUFRLENBQUMsQ0FBQyxDQUFDO0dBQ3BCLFdBQVc7RUFDWjtFQUNBLEdBQUcsT0FBTyxnQkFBZ0IsTUFBTTtHQUMvQixNQUFNLE9BQU8sS0FBSztHQUNsQixNQUFNLFlBQVksUUFBUSxJQUFJLG9CQUFvQixPQUFPLG9CQUFvQjtHQUM3RSxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxXQUFXLE9BQU8sTUFBTSxTQUFTLENBQUMsQ0FBQztHQUNuRSxJQUFJLGVBQWUsaUJBQWlCLEtBQUssVUFBVSxNQUFNO0lBQ3hEO0lBQ0E7R0FDRCxDQUFDO0VBQ0Y7Q0FDRDtDQUNBLE9BQU8sZUFBZSxlQUFlLFlBQVk7RUFDaEQsWUFBWTtFQUNaLFdBQVcsTUFBTSxTQUFTLENBQUM7Q0FDNUIsQ0FBQztDQUNELE9BQU8sZUFBZSxlQUFlLFNBQVM7RUFDN0MsWUFBWTtFQUNaLFdBQVcsTUFBTSxTQUFTLENBQUM7Q0FDNUIsQ0FBQztDQUNELE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTRCQSxTQUFTLHFCQUFxQixNQUFNO0NBQ25DLE9BQU8sU0FBUyxPQUFPLFFBQVEsU0FBUyxXQUFXLFNBQVMsU0FBUztDQUNyRSxJQUFJLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRyxRQUFRO0NBQ2pDLElBQTZDLENBQUMsS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUcsT0FBTyxzQ0FBc0MsS0FBSyxlQUFlLEtBQUssUUFBUSxRQUFRLEdBQUcsRUFBRSxHQUFHO0NBQ3hMLE9BQU8saUJBQWlCLElBQUk7QUFDN0I7QUFJQSxJQUFJLFlBQTRCLHlCQUFTLGFBQWE7Q0FDckQsWUFBWSxZQUFZLFlBQVksS0FBSztDQUN6QyxZQUFZLFlBQVksV0FBVyxLQUFLO0NBQ3hDLFlBQVksWUFBWSxXQUFXLEtBQUs7Q0FDeEMsT0FBTztBQUNSLEVBQUUsQ0FBQyxDQUFDO0FBQ0osSUFBSSxpQkFBaUMseUJBQVMsa0JBQWtCO0NBQy9ELGlCQUFpQixpQkFBaUIsWUFBWSxLQUFLO0NBQ25ELGlCQUFpQixpQkFBaUIsV0FBVyxLQUFLO0NBQ2xELGlCQUFpQixpQkFBaUIsaUJBQWlCLEtBQUs7Q0FDeEQsaUJBQWlCLGlCQUFpQixvQkFBb0IsS0FBSztDQUMzRCxpQkFBaUIsaUJBQWlCLGdCQUFnQixLQUFLO0NBQ3ZELE9BQU87QUFDUixFQUFFLGtCQUFrQixDQUFDLENBQUM7QUFDdEIsSUFBTSxhQUFhO0NBQ2xCLE1BQU0sVUFBVTtDQUNoQixPQUFPO0FBQ1I7QUFDQSxJQUFNLGlCQUFpQjtBQUN2QixTQUFTLGFBQWEsTUFBTTtDQUMzQixJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUFDO0NBQ3JCLElBQUksU0FBUyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQztDQUN0QyxJQUFJLENBQUMsS0FBSyxXQUFXLEdBQUcsR0FBRyxNQUFNLElBQUksTUFBOEMseUNBQXlDLEtBQUssZ0JBQWdCLEtBQUssR0FBOEI7Q0FDcEwsU0FBUyxNQUFNLFNBQVM7RUFDdkIsTUFBTSxJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLFNBQVM7Q0FDekQ7Q0FDQSxJQUFJLFFBQVEsZUFBZTtDQUMzQixJQUFJLGdCQUFnQjtDQUNwQixNQUFNLFNBQVMsQ0FBQztDQUNoQixJQUFJO0NBQ0osU0FBUyxrQkFBa0I7RUFDMUIsSUFBSSxTQUFTLE9BQU8sS0FBSyxPQUFPO0VBQ2hDLFVBQVUsQ0FBQztDQUNaO0NBQ0EsSUFBSSxJQUFJO0NBQ1IsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUksV0FBVztDQUNmLFNBQVMsZ0JBQWdCO0VBQ3hCLElBQUksQ0FBQyxRQUFRO0VBQ2IsSUFBSSxVQUFVLGVBQWUsUUFBUSxRQUFRLEtBQUs7R0FDakQsTUFBTSxVQUFVO0dBQ2hCLE9BQU87RUFDUixDQUFDO09BQ0ksSUFBSSxVQUFVLGVBQWUsU0FBUyxVQUFVLGVBQWUsZUFBZSxVQUFVLGVBQWUsZ0JBQWdCO0dBQzNILElBQUksUUFBUSxTQUFTLE1BQU0sU0FBUyxPQUFPLFNBQVMsTUFBTSxNQUFNLHVCQUF1QixPQUFPLDZDQUE2QztHQUMzSSxRQUFRLEtBQUs7SUFDWixNQUFNLFVBQVU7SUFDaEIsT0FBTztJQUNQLFFBQVE7SUFDUixZQUFZLFNBQVMsT0FBTyxTQUFTO0lBQ3JDLFVBQVUsU0FBUyxPQUFPLFNBQVM7R0FDcEMsQ0FBQztFQUNGLE9BQU8sTUFBTSxpQ0FBaUM7RUFDOUMsU0FBUztDQUNWO0NBQ0EsU0FBUyxrQkFBa0I7RUFDMUIsVUFBVTtDQUNYO0NBQ0EsT0FBTyxJQUFJLEtBQUssUUFBUTtFQUN2QixPQUFPLEtBQUs7RUFDWixJQUFJLFNBQVMsUUFBUSxVQUFVLGVBQWUsYUFBYTtHQUMxRCxnQkFBZ0I7R0FDaEIsUUFBUSxlQUFlO0dBQ3ZCO0VBQ0Q7RUFDQSxRQUFRLE9BQVI7R0FDQyxLQUFLLGVBQWU7SUFDbkIsSUFBSSxTQUFTLEtBQUs7S0FDakIsSUFBSSxRQUFRLGNBQWM7S0FDMUIsZ0JBQWdCO0lBQ2pCLE9BQU8sSUFBSSxTQUFTLEtBQUs7S0FDeEIsY0FBYztLQUNkLFFBQVEsZUFBZTtJQUN4QixPQUFPLGdCQUFnQjtJQUN2QjtHQUNELEtBQUssZUFBZTtJQUNuQixnQkFBZ0I7SUFDaEIsUUFBUTtJQUNSO0dBQ0QsS0FBSyxlQUFlO0lBQ25CLElBQUksU0FBUyxLQUFLLFFBQVEsZUFBZTtTQUNwQyxJQUFJLGVBQWUsS0FBSyxJQUFJLEdBQUcsZ0JBQWdCO1NBQy9DO0tBQ0osY0FBYztLQUNkLFFBQVEsZUFBZTtLQUN2QixJQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLO0lBQ25EO0lBQ0E7R0FDRCxLQUFLLGVBQWU7SUFDbkIsSUFBSSxTQUFTLEtBQUssSUFBSSxTQUFTLFNBQVMsU0FBUyxNQUFNLE1BQU0sV0FBVyxTQUFTLE1BQU0sR0FBRyxFQUFFLElBQUk7U0FDM0YsUUFBUSxlQUFlO1NBQ3ZCLFlBQVk7SUFDakI7R0FDRCxLQUFLLGVBQWU7SUFDbkIsY0FBYztJQUNkLFFBQVEsZUFBZTtJQUN2QixJQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLO0lBQ2xELFdBQVc7SUFDWDtHQUNELFNBQ0MsTUFBTSxlQUFlO0VBRXZCO0NBQ0Q7Q0FDQSxJQUFJLFVBQVUsZUFBZSxhQUFhLE1BQU0sdUNBQXVDLE9BQU8sRUFBRTtDQUNoRyxjQUFjO0NBQ2QsZ0JBQWdCO0NBQ2hCLE9BQU87QUFDUjtBQUlBLElBQU0scUJBQXFCO0FBQzNCLElBQU0sMkJBQTJCO0NBQ2hDLFdBQVc7Q0FDWCxRQUFRO0NBQ1IsT0FBTztDQUNQLEtBQUs7QUFDTjtBQUNBLElBQUksWUFBNEIseUJBQVMsYUFBYTtDQUNyRCxZQUFZLFlBQVksaUJBQWlCLE1BQU07Q0FDL0MsWUFBWSxZQUFZLFVBQVUsTUFBTTtDQUN4QyxZQUFZLFlBQVksYUFBYSxNQUFNO0NBQzNDLFlBQVksWUFBWSxnQkFBZ0IsTUFBTTtDQUM5QyxZQUFZLFlBQVksWUFBWSxNQUFNO0NBQzFDLFlBQVksWUFBWSxhQUFhLE1BQU07Q0FDM0MsWUFBWSxZQUFZLHVCQUF1QixNQUFNO0NBQ3JELFlBQVksWUFBWSxtQkFBbUIsT0FBTztDQUNsRCxZQUFZLFlBQVkscUJBQXFCLE9BQU87Q0FDcEQsWUFBWSxZQUFZLG1CQUFtQixNQUFNO0NBQ2pELFlBQVksWUFBWSxpQkFBaUIscUJBQXFCO0NBQzlELFlBQVksWUFBWSx3QkFBd0IsT0FBTztDQUN2RCxPQUFPO0FBQ1IsRUFBRSxhQUFhLENBQUMsQ0FBQztBQUNqQixJQUFNLGlCQUFpQjs7Ozs7Ozs7QUFRdkIsU0FBUyxlQUFlLFVBQVUsY0FBYztDQUMvQyxNQUFNLFVBQVUsT0FBTyxDQUFDLEdBQUcsMEJBQTBCLFlBQVk7Q0FDakUsTUFBTSxRQUFRLENBQUM7Q0FDZixJQUFJLFVBQVUsUUFBUSxRQUFRLE1BQU07Q0FDcEMsTUFBTSxPQUFPLENBQUM7Q0FDZCxLQUFLLE1BQU0sV0FBVyxVQUFVO0VBQy9CLE1BQU0sZ0JBQWdCLFFBQVEsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUk7RUFDM0QsSUFBSSxRQUFRLFVBQVUsQ0FBQyxRQUFRLFFBQVEsV0FBVztFQUNsRCxLQUFLLElBQUksYUFBYSxHQUFHLGFBQWEsUUFBUSxRQUFRLGNBQWM7R0FDbkUsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxrQkFBa0IsVUFBVSxXQUFXLFFBQVEsWUFBWSxVQUFVLHFCQUFxQjtHQUM5RixJQUFJLE1BQU0sU0FBUyxVQUFVLFFBQVE7SUFDcEMsSUFBSSxDQUFDLFlBQVksV0FBVztJQUM1QixXQUFXLE1BQU0sTUFBTSxRQUFRLGdCQUFnQixNQUFNO0lBQ3JELG1CQUFtQixVQUFVO0dBQzlCLE9BQU8sSUFBSSxNQUFNLFNBQVMsVUFBVSxPQUFPO0lBQzFDLE1BQU0sRUFBRSxPQUFPLFlBQVksVUFBVSxXQUFXO0lBQ2hELEtBQUssS0FBSztLQUNULE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztJQUNELE1BQU0sT0FBTyxTQUFTLFNBQVM7SUFDL0IsSUFBSSxTQUFTLG9CQUFvQjtLQUNoQyxtQkFBbUIsVUFBVTtLQUM3QixJQUFJO01BQ0gsR0FBRztLQUNKLFNBQVMsS0FBSztNQUNiLE1BQU0sSUFBSSxNQUFNLG9DQUFvQyxNQUFNLEtBQUssS0FBSyxPQUFPLElBQUksT0FBTztLQUN2RjtJQUNEO0lBQ0EsSUFBSSxhQUFhLGFBQWEsT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLElBQUksS0FBSztJQUMxRSxJQUFJLENBQUMsWUFBWSxhQUFhLFlBQVksUUFBUSxTQUFTLElBQUksT0FBTyxXQUFXLEtBQUssTUFBTTtJQUM1RixJQUFJLFVBQVUsY0FBYztJQUM1QixXQUFXO0lBQ1gsbUJBQW1CLFVBQVU7SUFDN0IsSUFBSSxVQUFVLG1CQUFtQixVQUFVO0lBQzNDLElBQUksWUFBWSxtQkFBbUIsVUFBVTtJQUM3QyxJQUFJLFNBQVMsTUFBTSxtQkFBbUIsVUFBVTtHQUNqRDtHQUNBLGNBQWMsS0FBSyxlQUFlO0VBQ25DO0VBQ0EsTUFBTSxLQUFLLGFBQWE7Q0FDekI7Q0FDQSxJQUFJLFFBQVEsVUFBVSxRQUFRLEtBQUs7RUFDbEMsTUFBTSxJQUFJLE1BQU0sU0FBUztFQUN6QixNQUFNLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLE1BQU0sVUFBVTtDQUM1QztDQUNBLElBQUksQ0FBQyxRQUFRLFFBQVEsV0FBVztDQUNoQyxJQUFJLFFBQVEsS0FBSyxXQUFXO01BQ3ZCLElBQUksUUFBUSxVQUFVLENBQUMsUUFBUSxTQUFTLEdBQUcsR0FBRyxXQUFXO0NBQzlELE1BQU0sS0FBSyxJQUFJLE9BQU8sU0FBUyxRQUFRLFlBQVksS0FBSyxHQUFHO0NBQzNELFNBQVMsTUFBTSxNQUFNO0VBQ3BCLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRTtFQUMzQixNQUFNLFNBQVMsQ0FBQztFQUNoQixJQUFJLENBQUMsT0FBTyxPQUFPO0VBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztHQUN0QyxNQUFNLFFBQVEsTUFBTSxNQUFNO0dBQzFCLE1BQU0sTUFBTSxLQUFLLElBQUk7R0FDckIsT0FBTyxJQUFJLFFBQVEsU0FBUyxJQUFJLGFBQWEsTUFBTSxNQUFNLEdBQUcsSUFBSTtFQUNqRTtFQUNBLE9BQU87Q0FDUjtDQUNBLFNBQVMsVUFBVSxRQUFRO0VBQzFCLElBQUksT0FBTztFQUNYLElBQUksdUJBQXVCO0VBQzNCLEtBQUssTUFBTSxXQUFXLFVBQVU7R0FDL0IsSUFBSSxDQUFDLHdCQUF3QixDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUcsUUFBUTtHQUMxRCx1QkFBdUI7R0FDdkIsS0FBSyxNQUFNLFNBQVMsU0FBUyxJQUFJLE1BQU0sU0FBUyxVQUFVLFFBQVEsUUFBUSxNQUFNO1FBQzNFLElBQUksTUFBTSxTQUFTLFVBQVUsT0FBTztJQUN4QyxNQUFNLEVBQUUsT0FBTyxZQUFZLGFBQWE7SUFDeEMsTUFBTSxRQUFRLFNBQVMsU0FBUyxPQUFPLFNBQVM7SUFDaEQsSUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLFlBQVksTUFBTSxJQUFJLE1BQU0sbUJBQW1CLE1BQU0sMERBQTBEO0lBQ3RJLE1BQU0sT0FBTyxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJO0lBQ2hELElBQUksQ0FBQyxNQUFNLElBQUksVUFDVjtTQUFBLFFBQVEsU0FBUyxHQUFHLElBQUksS0FBSyxTQUFTLEdBQUcsR0FBRyxPQUFPLEtBQUssTUFBTSxHQUFHLEVBQUU7VUFDbEUsdUJBQXVCO0lBQUEsT0FDdEIsTUFBTSxJQUFJLE1BQU0sMkJBQTJCLE1BQU0sRUFBRTtJQUMxRCxRQUFRO0dBQ1Q7RUFDRDtFQUNBLE9BQU8sUUFBUTtDQUNoQjtDQUNBLE9BQU87RUFDTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7QUFDRDs7Ozs7Ozs7OztBQVVBLFNBQVMsa0JBQWtCLEdBQUcsR0FBRztDQUNoQyxJQUFJLElBQUk7Q0FDUixPQUFPLElBQUksRUFBRSxVQUFVLElBQUksRUFBRSxRQUFRO0VBQ3BDLE1BQU0sT0FBTyxFQUFFLEtBQUssRUFBRTtFQUN0QixJQUFJLE1BQU0sT0FBTztFQUNqQjtDQUNEO0NBQ0EsSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRLE9BQU8sRUFBRSxXQUFXLEtBQUssRUFBRSxPQUFPLFVBQVUsU0FBUyxVQUFVLFVBQVUsS0FBSztNQUNsRyxJQUFJLEVBQUUsU0FBUyxFQUFFLFFBQVEsT0FBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFVBQVUsVUFBVSxJQUFJO0NBQzNHLE9BQU87QUFDUjs7Ozs7Ozs7QUFRQSxTQUFTLHVCQUF1QixHQUFHLEdBQUc7Q0FDckMsSUFBSSxJQUFJO0NBQ1IsTUFBTSxTQUFTLEVBQUU7Q0FDakIsTUFBTSxTQUFTLEVBQUU7Q0FDakIsT0FBTyxJQUFJLE9BQU8sVUFBVSxJQUFJLE9BQU8sUUFBUTtFQUM5QyxNQUFNLE9BQU8sa0JBQWtCLE9BQU8sSUFBSSxPQUFPLEVBQUU7RUFDbkQsSUFBSSxNQUFNLE9BQU87RUFDakI7Q0FDRDtDQUNBLElBQUksS0FBSyxJQUFJLE9BQU8sU0FBUyxPQUFPLE1BQU0sTUFBTSxHQUFHO0VBQ2xELElBQUksb0JBQW9CLE1BQU0sR0FBRyxPQUFPO0VBQ3hDLElBQUksb0JBQW9CLE1BQU0sR0FBRyxPQUFPO0NBQ3pDO0NBQ0EsT0FBTyxPQUFPLFNBQVMsT0FBTztBQUMvQjs7Ozs7OztBQU9BLFNBQVMsb0JBQW9CLE9BQU87Q0FDbkMsTUFBTSxPQUFPLE1BQU0sTUFBTSxTQUFTO0NBQ2xDLE9BQU8sTUFBTSxTQUFTLEtBQUssS0FBSyxLQUFLLFNBQVMsS0FBSztBQUNwRDtBQUNBLElBQU0sK0JBQStCO0NBQ3BDLFFBQVE7Q0FDUixLQUFLO0NBQ0wsV0FBVztBQUNaO0FBSUEsU0FBUyx5QkFBeUIsUUFBUSxRQUFRLFNBQVM7Q0FDMUQsTUFBTSxTQUFTLGVBQWUsYUFBYSxPQUFPLElBQUksR0FBRyxPQUFPO0NBQ3JCO0VBQzFDLE1BQU0sK0JBQStCLElBQUksSUFBSTtFQUM3QyxLQUFLLE1BQU0sT0FBTyxPQUFPLE1BQU07R0FDOUIsSUFBSSxhQUFhLElBQUksSUFBSSxJQUFJLEdBQUcsT0FBTyxzQ0FBc0MsSUFBSSxLQUFLLGNBQWMsT0FBTyxLQUFLLDJEQUEyRDtHQUMzSyxhQUFhLElBQUksSUFBSSxJQUFJO0VBQzFCO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsT0FBTyxRQUFRO0VBQzlCO0VBQ0E7RUFDQSxVQUFVLENBQUM7RUFDWCxPQUFPLENBQUM7Q0FDVCxDQUFDO0NBQ0QsSUFBSSxRQUNDO01BQUEsQ0FBQyxRQUFRLE9BQU8sWUFBWSxDQUFDLE9BQU8sT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLLE9BQU87Q0FBQTtDQUVyRixPQUFPO0FBQ1I7Ozs7Ozs7O0FBV0EsU0FBUyxvQkFBb0IsUUFBUSxlQUFlO0NBQ25ELE1BQU0sV0FBVyxDQUFDO0NBQ2xCLE1BQU0sNkJBQTZCLElBQUksSUFBSTtDQUMzQyxnQkFBZ0IsYUFBYSw4QkFBOEIsYUFBYTtDQUN4RSxTQUFTLGlCQUFpQixNQUFNO0VBQy9CLE9BQU8sV0FBVyxJQUFJLElBQUk7Q0FDM0I7Q0FDQSxTQUFTLFNBQVMsUUFBUSxRQUFRLGdCQUFnQjtFQUNqRCxNQUFNLFlBQVksQ0FBQztFQUNuQixNQUFNLHVCQUF1QixxQkFBcUIsTUFBTTtFQUNiLG1DQUFtQyxzQkFBc0IsTUFBTTtFQUMxRyxxQkFBcUIsVUFBVSxrQkFBa0IsZUFBZTtFQUNoRSxNQUFNLFVBQVUsYUFBYSxlQUFlLE1BQU07RUFDbEQsTUFBTSxvQkFBb0IsQ0FBQyxvQkFBb0I7RUFDL0MsSUFBSSxXQUFXLFFBQVE7R0FDdEIsTUFBTSxVQUFVLE9BQU8sT0FBTyxVQUFVLFdBQVcsQ0FBQyxPQUFPLEtBQUssSUFBSSxPQUFPO0dBQzNFLEtBQUssTUFBTSxTQUFTLFNBQVMsa0JBQWtCLEtBQUsscUJBQXFCLE9BQU8sQ0FBQyxHQUFHLHNCQUFzQjtJQUN6RyxZQUFZLGlCQUFpQixlQUFlLE9BQU8sYUFBYSxxQkFBcUI7SUFDckYsTUFBTTtJQUNOLFNBQVMsaUJBQWlCLGVBQWUsU0FBUztHQUNuRCxDQUFDLENBQUMsQ0FBQztFQUNKO0VBQ0EsSUFBSTtFQUNKLElBQUk7RUFDSixLQUFLLE1BQU0sb0JBQW9CLG1CQUFtQjtHQUNqRCxNQUFNLEVBQUUsU0FBUztHQUNqQixJQUFJLFVBQVUsS0FBSyxPQUFPLEtBQUs7SUFDOUIsTUFBTSxhQUFhLE9BQU8sT0FBTztJQUNqQyxNQUFNLGtCQUFrQixXQUFXLFdBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSztJQUN6RSxpQkFBaUIsT0FBTyxPQUFPLE9BQU8sUUFBUSxRQUFRLGtCQUFrQjtHQUN6RTtHQUNBLElBQTZDLGlCQUFpQixTQUFTLEtBQUssTUFBTSxJQUFJLE1BQU0sMktBQTJLO0dBQ3ZRLFVBQVUseUJBQXlCLGtCQUFrQixRQUFRLE9BQU87R0FDcEUsSUFBNkMsVUFBVSxLQUFLLE9BQU8sS0FBSyxpQ0FBaUMsU0FBUyxNQUFNO0dBQ3hILElBQUksZ0JBQWdCO0lBQ25CLGVBQWUsTUFBTSxLQUFLLE9BQU87SUFDVSxnQkFBZ0IsZ0JBQWdCLE9BQU87R0FDbkYsT0FBTztJQUNOLGtCQUFrQixtQkFBbUI7SUFDckMsSUFBSSxvQkFBb0IsU0FBUyxnQkFBZ0IsTUFBTSxLQUFLLE9BQU87SUFDbkUsSUFBSSxhQUFhLE9BQU8sUUFBUSxDQUFDLGNBQWMsT0FBTyxHQUFHO0tBQ2Isd0JBQXdCLFFBQVEsTUFBTTtLQUNqRixZQUFZLE9BQU8sSUFBSTtJQUN4QjtHQUNEO0dBQ0EsSUFBSSxZQUFZLE9BQU8sR0FBRyxjQUFjLE9BQU87R0FDL0MsSUFBSSxxQkFBcUIsVUFBVTtJQUNsQyxNQUFNLFdBQVcscUJBQXFCO0lBQ3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSyxTQUFTLFNBQVMsSUFBSSxTQUFTLGtCQUFrQixlQUFlLFNBQVMsRUFBRTtHQUN0SDtHQUNBLGlCQUFpQixrQkFBa0I7RUFDcEM7RUFDQSxPQUFPLHdCQUF3QjtHQUM5QixZQUFZLGVBQWU7RUFDNUIsSUFBSTtDQUNMO0NBQ0EsU0FBUyxZQUFZLFlBQVk7RUFDaEMsSUFBSSxZQUFZLFVBQVUsR0FBRztHQUM1QixNQUFNLFVBQVUsV0FBVyxJQUFJLFVBQVU7R0FDekMsSUFBSSxTQUFTO0lBQ1osV0FBVyxPQUFPLFVBQVU7SUFDNUIsU0FBUyxPQUFPLFNBQVMsUUFBUSxPQUFPLEdBQUcsQ0FBQztJQUM1QyxRQUFRLFNBQVMsUUFBUSxXQUFXO0lBQ3BDLFFBQVEsTUFBTSxRQUFRLFdBQVc7R0FDbEM7RUFDRCxPQUFPO0dBQ04sTUFBTSxRQUFRLFNBQVMsUUFBUSxVQUFVO0dBQ3pDLElBQUksUUFBUSxJQUFJO0lBQ2YsU0FBUyxPQUFPLE9BQU8sQ0FBQztJQUN4QixJQUFJLFdBQVcsT0FBTyxNQUFNLFdBQVcsT0FBTyxXQUFXLE9BQU8sSUFBSTtJQUNwRSxXQUFXLFNBQVMsUUFBUSxXQUFXO0lBQ3ZDLFdBQVcsTUFBTSxRQUFRLFdBQVc7R0FDckM7RUFDRDtDQUNEO0NBQ0EsU0FBUyxZQUFZO0VBQ3BCLE9BQU87Q0FDUjtDQUNBLFNBQVMsY0FBYyxTQUFTO0VBQy9CLE1BQU0sUUFBUSxtQkFBbUIsU0FBUyxRQUFRO0VBQ2xELFNBQVMsT0FBTyxPQUFPLEdBQUcsT0FBTztFQUNqQyxJQUFJLFFBQVEsT0FBTyxRQUFRLENBQUMsY0FBYyxPQUFPLEdBQUcsV0FBVyxJQUFJLFFBQVEsT0FBTyxNQUFNLE9BQU87Q0FDaEc7Q0FDQSxTQUFTLFFBQVEsWUFBWSxpQkFBaUI7RUFDN0MsSUFBSTtFQUNKLElBQUksU0FBUyxDQUFDO0VBQ2QsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJLFVBQVUsY0FBYyxXQUFXLE1BQU07R0FDNUMsVUFBVSxXQUFXLElBQUksV0FBVyxJQUFJO0dBQ3hDLElBQUksQ0FBQyxTQUFTLE1BQU0sa0JBQWtCLFdBQVcsbUJBQW1CLEVBQUUsVUFBVSxXQUFXLENBQUM7R0FDakQ7SUFDMUMsTUFBTSxnQkFBZ0IsT0FBTyxLQUFLLFdBQVcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsY0FBYyxDQUFDLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxTQUFTLFNBQVMsQ0FBQztJQUNoSSxJQUFJLGNBQWMsUUFBUSxPQUFPLCtCQUErQixjQUFjLEtBQUssUUFBUSxFQUFFLCtIQUErSDtHQUM3TjtHQUNBLE9BQU8sUUFBUSxPQUFPO0dBQ3RCLFNBQVMsT0FBTyxXQUFXLGdCQUFnQixRQUFRLFFBQVEsS0FBSyxRQUFRLE1BQU0sQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLE9BQU8sUUFBUSxTQUFTLFFBQVEsT0FBTyxLQUFLLFFBQVEsTUFBTSxFQUFFLFFBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLFdBQVcsVUFBVSxXQUFXLFdBQVcsUUFBUSxRQUFRLEtBQUssS0FBSyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7R0FDL1EsT0FBTyxRQUFRLFVBQVUsTUFBTTtFQUNoQyxPQUFPLElBQUksV0FBVyxRQUFRLE1BQU07R0FDbkMsT0FBTyxXQUFXO0dBQ2xCLElBQTZDLENBQUMsS0FBSyxXQUFXLEdBQUcsR0FBRyxPQUFPLDJEQUEyRCxLQUFLLG1EQUFtRCxLQUFLLHVIQUF1SDtHQUMxVCxVQUFVLFNBQVMsTUFBTSxNQUFNLEVBQUUsR0FBRyxLQUFLLElBQUksQ0FBQztHQUM5QyxJQUFJLFNBQVM7SUFDWixTQUFTLFFBQVEsTUFBTSxJQUFJO0lBQzNCLE9BQU8sUUFBUSxPQUFPO0dBQ3ZCO0VBQ0QsT0FBTztHQUNOLFVBQVUsZ0JBQWdCLE9BQU8sV0FBVyxJQUFJLGdCQUFnQixJQUFJLElBQUksU0FBUyxNQUFNLE1BQU0sRUFBRSxHQUFHLEtBQUssZ0JBQWdCLElBQUksQ0FBQztHQUM1SCxJQUFJLENBQUMsU0FBUyxNQUFNLGtCQUFrQixXQUFXLG1CQUFtQjtJQUNuRSxVQUFVO0lBQ1Y7R0FDRCxDQUFDO0dBQ0QsT0FBTyxRQUFRLE9BQU87R0FDdEIsU0FBUyxPQUFPLENBQUMsR0FBRyxnQkFBZ0IsUUFBUSxXQUFXLE1BQU07R0FDN0QsT0FBTyxRQUFRLFVBQVUsTUFBTTtFQUNoQztFQUNBLE1BQU0sVUFBVSxDQUFDO0VBQ2pCLElBQUksZ0JBQWdCO0VBQ3BCLE9BQU8sZUFBZTtHQUNyQixRQUFRLFFBQVEsY0FBYyxNQUFNO0dBQ3BDLGdCQUFnQixjQUFjO0VBQy9CO0VBQ0EsT0FBTztHQUNOO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsTUFBTSxnQkFBZ0IsT0FBTztFQUM5QjtDQUNEO0NBQ0EsT0FBTyxTQUFTLFVBQVUsU0FBUyxLQUFLLENBQUM7Q0FDekMsU0FBUyxjQUFjO0VBQ3RCLFNBQVMsU0FBUztFQUNsQixXQUFXLE1BQU07Q0FDbEI7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7QUFDRDs7Ozs7OztBQU9BLFNBQVMsV0FBVyxRQUFRLE1BQU07Q0FDakMsTUFBTSxZQUFZLENBQUM7Q0FDbkIsS0FBSyxNQUFNLE9BQU8sTUFBTSxJQUFJLE9BQU8sUUFBUSxVQUFVLE9BQU8sT0FBTztDQUNuRSxPQUFPO0FBQ1I7Ozs7Ozs7QUFPQSxTQUFTLHFCQUFxQixRQUFRO0NBQ3JDLE1BQU0sYUFBYTtFQUNsQixNQUFNLE9BQU87RUFDYixVQUFVLE9BQU87RUFDakIsTUFBTSxPQUFPO0VBQ2IsTUFBTSxPQUFPLFFBQVEsQ0FBQztFQUN0QixTQUFTLE9BQU87RUFDaEIsYUFBYSxPQUFPO0VBQ3BCLE9BQU8scUJBQXFCLE1BQU07RUFDbEMsVUFBVSxPQUFPLFlBQVksQ0FBQztFQUM5QixXQUFXLENBQUM7RUFDWiw2QkFBNkIsSUFBSSxJQUFJO0VBQ3JDLDhCQUE4QixJQUFJLElBQUk7RUFDdEMsZ0JBQWdCLENBQUM7RUFDakIsWUFBWSxnQkFBZ0IsU0FBUyxPQUFPLGNBQWMsT0FBTyxPQUFPLGFBQWEsRUFBRSxTQUFTLE9BQU8sVUFBVTtDQUNsSDtDQUNBLE9BQU8sZUFBZSxZQUFZLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDO0NBQ3ZELE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxxQkFBcUIsUUFBUTtDQUNyQyxNQUFNLGNBQWMsQ0FBQztDQUNyQixNQUFNLFFBQVEsT0FBTyxTQUFTO0NBQzlCLElBQUksZUFBZSxRQUFRLFlBQVksVUFBVTtNQUM1QyxLQUFLLE1BQU0sUUFBUSxPQUFPLFlBQVksWUFBWSxRQUFRLE9BQU8sVUFBVSxXQUFXLE1BQU0sUUFBUTtDQUN6RyxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxjQUFjLFFBQVE7Q0FDOUIsT0FBTyxRQUFRO0VBQ2QsSUFBSSxPQUFPLE9BQU8sU0FBUyxPQUFPO0VBQ2xDLFNBQVMsT0FBTztDQUNqQjtDQUNBLE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxnQkFBZ0IsU0FBUztDQUNqQyxPQUFPLFFBQVEsUUFBUSxNQUFNLFdBQVcsT0FBTyxNQUFNLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQztBQUN0RTtBQUNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7Q0FDMUIsT0FBTyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUU7QUFDN0U7Ozs7Ozs7QUFPQSxTQUFTLGdCQUFnQixHQUFHLEdBQUc7Q0FDOUIsS0FBSyxNQUFNLE9BQU8sRUFBRSxNQUFNLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxFQUFFLEtBQUssS0FBSyxZQUFZLEtBQUssTUFBTSxHQUFHLENBQUMsR0FBRyxPQUFPLE9BQU8sVUFBVSxFQUFFLE9BQU8sS0FBSyw4QkFBOEIsRUFBRSxPQUFPLEtBQUssMENBQTBDLElBQUksS0FBSyxFQUFFO0NBQ2pPLEtBQUssTUFBTSxPQUFPLEVBQUUsTUFBTSxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsRUFBRSxLQUFLLEtBQUssWUFBWSxLQUFLLE1BQU0sR0FBRyxDQUFDLEdBQUcsT0FBTyxPQUFPLFVBQVUsRUFBRSxPQUFPLEtBQUssOEJBQThCLEVBQUUsT0FBTyxLQUFLLDBDQUEwQyxJQUFJLEtBQUssRUFBRTtBQUNsTzs7Ozs7OztBQU9BLFNBQVMsbUNBQW1DLHNCQUFzQixRQUFRO0NBQ3pFLElBQUksVUFBVSxPQUFPLE9BQU8sUUFBUSxDQUFDLHFCQUFxQixRQUFRLENBQUMscUJBQXFCLE1BQU0sT0FBTyxvQkFBb0IsT0FBTyxPQUFPLE9BQU8sSUFBSSxFQUFFLDJPQUEyTztBQUNoWTtBQUNBLFNBQVMsd0JBQXdCLFFBQVEsUUFBUTtDQUNoRCxLQUFLLElBQUksV0FBVyxRQUFRLFVBQVUsV0FBVyxTQUFTLFFBQVEsSUFBSSxTQUFTLE9BQU8sU0FBUyxPQUFPLE1BQU0sTUFBTSxJQUFJLE1BQU0sa0JBQWtCLE9BQU8sT0FBTyxJQUFJLEVBQUUsd0JBQXdCLFdBQVcsV0FBVyxVQUFVLGFBQWEsdUhBQXVIO0FBQy9WO0FBQ0EsU0FBUyxpQ0FBaUMsUUFBUSxRQUFRO0NBQ3pELEtBQUssTUFBTSxPQUFPLE9BQU8sTUFBTSxJQUFJLENBQUMsT0FBTyxLQUFLLEtBQUssWUFBWSxLQUFLLE1BQU0sR0FBRyxDQUFDLEdBQUcsT0FBTyxPQUFPLGtCQUFrQixPQUFPLE9BQU8sS0FBSywwQ0FBMEMsSUFBSSxLQUFLLG1CQUFtQixPQUFPLE9BQU8sS0FBSyxHQUFHO0FBQ25POzs7Ozs7Ozs7O0FBVUEsU0FBUyxtQkFBbUIsU0FBUyxVQUFVO0NBQzlDLElBQUksUUFBUTtDQUNaLElBQUksUUFBUSxTQUFTO0NBQ3JCLE9BQU8sVUFBVSxPQUFPO0VBQ3ZCLE1BQU0sTUFBTSxRQUFRLFNBQVM7RUFDN0IsSUFBSSx1QkFBdUIsU0FBUyxTQUFTLElBQUksSUFBSSxHQUFHLFFBQVE7T0FDM0QsUUFBUSxNQUFNO0NBQ3BCO0NBQ0EsTUFBTSxvQkFBb0IscUJBQXFCLE9BQU87Q0FDdEQsSUFBSSxtQkFBbUI7RUFDdEIsUUFBUSxTQUFTLFlBQVksbUJBQW1CLFFBQVEsQ0FBQztFQUN6RCxJQUE2QyxRQUFRLEdBQUcsT0FBTywyQkFBMkIsa0JBQWtCLE9BQU8sS0FBSyxnQkFBZ0IsUUFBUSxPQUFPLEtBQUssRUFBRTtDQUMvSjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsSUFBSSxXQUFXO0NBQ2YsT0FBTyxXQUFXLFNBQVMsUUFBUSxJQUFJLFlBQVksUUFBUSxLQUFLLHVCQUF1QixTQUFTLFFBQVEsTUFBTSxHQUFHLE9BQU87QUFDekg7Ozs7Ozs7O0FBUUEsU0FBUyxZQUFZLEVBQUUsVUFBVTtDQUNoQyxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsT0FBTyxjQUFjLE9BQU8sS0FBSyxPQUFPLFVBQVUsQ0FBQyxDQUFDLFVBQVUsT0FBTztBQUMvRjs7Ozs7O0FBU0EsU0FBUyxRQUFRLE9BQU87Q0FDdkIsTUFBTSxTQUFTLE9BQU8sU0FBUztDQUMvQixNQUFNLGVBQWUsT0FBTyxnQkFBZ0I7Q0FDNUMsSUFBSSxjQUFjO0NBQ2xCLElBQUksYUFBYTtDQUNqQixNQUFNLFFBQVEsZUFBZTtFQUM1QixNQUFNLEtBQUssTUFBTSxNQUFNLEVBQUU7RUFDekIsSUFBOEMsQ0FBQyxlQUFlLE9BQU8sWUFBYTtHQUNqRixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxJQUFJLGFBQWEsT0FBTyxtREFBbUQsSUFBSSxvQkFBb0IsWUFBWSxjQUFjLEtBQUs7UUFDdkosT0FBTyxtREFBbUQsSUFBSSxjQUFjLEtBQUs7R0FDdEYsYUFBYTtHQUNiLGNBQWM7RUFDZjtFQUNBLE9BQU8sT0FBTyxRQUFRLEVBQUU7Q0FDekIsQ0FBQztDQUNELE1BQU0sb0JBQW9CLGVBQWU7RUFDeEMsTUFBTSxFQUFFLFlBQVksTUFBTTtFQUMxQixNQUFNLEVBQUUsV0FBVztFQUNuQixNQUFNLGVBQWUsUUFBUSxTQUFTO0VBQ3RDLE1BQU0saUJBQWlCLGFBQWE7RUFDcEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsUUFBUSxPQUFPO0VBQ3BELE1BQU0sUUFBUSxlQUFlLFVBQVUsa0JBQWtCLEtBQUssTUFBTSxZQUFZLENBQUM7RUFDakYsSUFBSSxRQUFRLElBQUksT0FBTztFQUN2QixNQUFNLG1CQUFtQixnQkFBZ0IsUUFBUSxTQUFTLEVBQUU7RUFDNUQsT0FBTyxTQUFTLEtBQUssZ0JBQWdCLFlBQVksTUFBTSxvQkFBb0IsZUFBZSxlQUFlLFNBQVMsRUFBRSxDQUFDLFNBQVMsbUJBQW1CLGVBQWUsVUFBVSxrQkFBa0IsS0FBSyxNQUFNLFFBQVEsU0FBUyxFQUFFLENBQUMsSUFBSTtDQUNoTyxDQUFDO0NBQ0QsTUFBTSxXQUFXLGVBQWUsa0JBQWtCLFFBQVEsTUFBTSxlQUFlLGFBQWEsUUFBUSxNQUFNLE1BQU0sTUFBTSxDQUFDO0NBQ3ZILE1BQU0sZ0JBQWdCLGVBQWUsa0JBQWtCLFFBQVEsTUFBTSxrQkFBa0IsVUFBVSxhQUFhLFFBQVEsU0FBUyxLQUFLLDBCQUEwQixhQUFhLFFBQVEsTUFBTSxNQUFNLE1BQU0sQ0FBQztDQUN0TSxTQUFTLFNBQVMsSUFBSSxDQUFDLEdBQUc7RUFDekIsSUFBSSxXQUFXLENBQUMsR0FBRztHQUNsQixNQUFNLElBQUksT0FBTyxNQUFNLE1BQU0sT0FBTyxJQUFJLFlBQVksT0FBTyxDQUFDLE1BQU0sTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSTtHQUN2RixJQUFJLE1BQU0sa0JBQWtCLE9BQU8sYUFBYSxlQUFlLHlCQUF5QixVQUFVLFNBQVMsMEJBQTBCLENBQUM7R0FDdEksT0FBTztFQUNSO0VBQ0EsT0FBTyxRQUFRLFFBQVE7Q0FDeEI7Q0FDQSxJQUF3RSxXQUFXO0VBQ2xGLE1BQU0sV0FBVyxtQkFBbUI7RUFDcEMsSUFBSSxVQUFVO0dBQ2IsTUFBTSxzQkFBc0I7SUFDM0IsT0FBTyxNQUFNO0lBQ2IsVUFBVSxTQUFTO0lBQ25CLGVBQWUsY0FBYztJQUM3QixPQUFPO0dBQ1I7R0FDQSxTQUFTLGlCQUFpQixTQUFTLGtCQUFrQixDQUFDO0dBQ3RELFNBQVMsZUFBZSxLQUFLLG1CQUFtQjtHQUNoRCxrQkFBa0I7SUFDakIsb0JBQW9CLFFBQVEsTUFBTTtJQUNsQyxvQkFBb0IsV0FBVyxTQUFTO0lBQ3hDLG9CQUFvQixnQkFBZ0IsY0FBYztJQUNsRCxvQkFBb0IsUUFBUSxnQkFBZ0IsTUFBTSxNQUFNLEVBQUUsQ0FBQyxJQUFJLE9BQU87R0FDdkUsR0FBRyxFQUFFLE9BQU8sT0FBTyxDQUFDO0VBQ3JCO0NBQ0Q7Ozs7Q0FJQSxPQUFPO0VBQ047RUFDQSxNQUFNLGVBQWUsTUFBTSxNQUFNLElBQUk7RUFDckM7RUFDQTtFQUNBO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsa0JBQWtCLFFBQVE7Q0FDbEMsT0FBTyxPQUFPLFdBQVcsSUFBSSxPQUFPLEtBQUs7QUFDMUM7Ozs7QUF5Q0EsSUFBTSxhQXhDaUMsZ0NBQWdCO0NBQ3RELE1BQU07Q0FDTixjQUFjLEVBQUUsTUFBTSxFQUFFO0NBQ3hCLE9BQU87RUFDTixJQUFJO0dBQ0gsTUFBTSxDQUFDLFFBQVEsTUFBTTtHQUNyQixVQUFVO0VBQ1g7RUFDQSxTQUFTO0VBQ1QsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1Isa0JBQWtCO0dBQ2pCLE1BQU07R0FDTixTQUFTO0VBQ1Y7RUFDQSxnQkFBZ0I7Q0FDakI7Q0FDQTtDQUNBLE1BQU0sT0FBTyxFQUFFLFNBQVM7RUFDdkIsTUFBTSxPQUFPLFNBQVMsUUFBUSxLQUFLLENBQUM7RUFDcEMsTUFBTSxFQUFFLFlBQVksT0FBTyxTQUFTO0VBQ3BDLE1BQU0sVUFBVSxnQkFBZ0I7SUFDOUIsYUFBYSxNQUFNLGFBQWEsUUFBUSxpQkFBaUIsb0JBQW9CLElBQUksS0FBSztJQUN0RixhQUFhLE1BQU0sa0JBQWtCLFFBQVEsc0JBQXNCLDBCQUEwQixJQUFJLEtBQUs7RUFDeEcsRUFBRTtFQUNGLGFBQWE7R0FDWixNQUFNLFdBQVcsTUFBTSxXQUFXLGtCQUFrQixNQUFNLFFBQVEsSUFBSSxDQUFDO0dBQ3ZFLE9BQU8sTUFBTSxTQUFTLFdBQVcsRUFBRSxLQUFLO0lBQ3ZDLGdCQUFnQixLQUFLLGdCQUFnQixNQUFNLG1CQUFtQjtJQUM5RCxNQUFNLEtBQUs7SUFDWCxTQUFTLEtBQUs7SUFDZCxPQUFPLFFBQVE7R0FDaEIsR0FBRyxRQUFRO0VBQ1o7Q0FDRDtBQUNELENBSWdDO0FBQ2hDLFNBQVMsV0FBVyxHQUFHO0NBQ3RCLElBQUksRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxVQUFVO0NBQ3RELElBQUksRUFBRSxrQkFBa0I7Q0FDeEIsSUFBSSxFQUFFLFdBQVcsS0FBSyxLQUFLLEVBQUUsV0FBVyxHQUFHO0NBQzNDLElBQUksRUFBRSxpQkFBaUIsRUFBRSxjQUFjLGNBQWM7RUFDcEQsTUFBTSxTQUFTLEVBQUUsY0FBYyxhQUFhLFFBQVE7RUFDcEQsSUFBSSxjQUFjLEtBQUssTUFBTSxHQUFHO0NBQ2pDO0NBQ0EsSUFBSSxFQUFFLGdCQUFnQixFQUFFLGVBQWU7Q0FDdkMsT0FBTztBQUNSO0FBQ0EsU0FBUyxlQUFlLE9BQU8sT0FBTztDQUNyQyxLQUFLLE1BQU0sT0FBTyxPQUFPO0VBQ3hCLE1BQU0sYUFBYSxNQUFNO0VBQ3pCLE1BQU0sYUFBYSxNQUFNO0VBQ3pCLElBQUksT0FBTyxlQUFlLFVBQ3JCO09BQUEsZUFBZSxZQUFZLE9BQU87RUFBQSxPQUNoQyxJQUFJLENBQUMsUUFBUSxVQUFVLEtBQUssV0FBVyxXQUFXLFdBQVcsVUFBVSxXQUFXLE1BQU0sT0FBTyxNQUFNLE1BQU0sUUFBUSxNQUFNLFdBQVcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLE9BQU87Q0FDbEs7Q0FDQSxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxnQkFBZ0IsUUFBUTtDQUNoQyxPQUFPLFNBQVMsT0FBTyxVQUFVLE9BQU8sUUFBUSxPQUFPLE9BQU8sT0FBTztBQUN0RTs7Ozs7OztBQU9BLElBQU0sZ0JBQWdCLFdBQVcsYUFBYSxpQkFBaUIsYUFBYSxPQUFPLFlBQVksZUFBZSxPQUFPLGNBQWM7QUFJbkksSUFBTSxpQkFBaUMsZ0NBQWdCO0NBQ3RELE1BQU07Q0FDTixjQUFjO0NBQ2QsT0FBTztFQUNOLE1BQU07R0FDTCxNQUFNO0dBQ04sU0FBUztFQUNWO0VBQ0EsT0FBTztDQUNSO0NBQ0EsY0FBYyxFQUFFLE1BQU0sRUFBRTtDQUN4QixNQUFNLE9BQU8sRUFBRSxPQUFPLFNBQVM7RUFDOUIsb0JBQTZEO0VBQzdELE1BQU0sZ0JBQWdCLE9BQU8scUJBQXFCO0VBQ2xELE1BQU0saUJBQWlCLGVBQWUsTUFBTSxTQUFTLGNBQWMsS0FBSztFQUN4RSxNQUFNLGdCQUFnQixPQUFPLGNBQWMsQ0FBQztFQUM1QyxNQUFNLFFBQVEsZUFBZTtHQUM1QixJQUFJLGVBQWUsTUFBTSxhQUFhO0dBQ3RDLE1BQU0sRUFBRSxZQUFZLGVBQWU7R0FDbkMsSUFBSTtHQUNKLFFBQVEsZUFBZSxRQUFRLGtCQUFrQixDQUFDLGFBQWEsWUFBWTtHQUMzRSxPQUFPO0VBQ1IsQ0FBQztFQUNELE1BQU0sa0JBQWtCLGVBQWUsZUFBZSxNQUFNLFFBQVEsTUFBTSxNQUFNO0VBQ2hGLFFBQVEsY0FBYyxlQUFlLE1BQU0sUUFBUSxDQUFDLENBQUM7RUFDckQsUUFBUSxpQkFBaUIsZUFBZTtFQUN4QyxRQUFRLHVCQUF1QixjQUFjO0VBQzdDLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLFlBQVk7R0FDWCxRQUFRO0dBQ1IsZ0JBQWdCO0dBQ2hCLE1BQU07RUFDUCxJQUFJLENBQUMsVUFBVSxJQUFJLE9BQU8sQ0FBQyxhQUFhLE1BQU0sYUFBYTtHQUMxRCxJQUFJLElBQUk7SUFDUCxHQUFHLFVBQVUsUUFBUTtJQUNyQixJQUFJLFFBQVEsU0FBUyxNQUFNLFlBQVksYUFBYSxhQUFhO0tBQ2hFLElBQUksQ0FBQyxHQUFHLFlBQVksTUFBTSxHQUFHLGNBQWMsS0FBSztLQUNoRCxJQUFJLENBQUMsR0FBRyxhQUFhLE1BQU0sR0FBRyxlQUFlLEtBQUs7SUFDbkQ7R0FDRDtHQUNBLElBQUksWUFBWSxPQUFPLENBQUMsUUFBUSxDQUFDLGtCQUFrQixJQUFJLElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLGVBQWUsU0FBUyxDQUFDLEVBQUEsQ0FBRyxTQUFTLGFBQWEsU0FBUyxRQUFRLENBQUM7RUFDeEosR0FBRyxFQUFFLE9BQU8sT0FBTyxDQUFDO0VBQ3BCLGFBQWE7R0FDWixNQUFNLFFBQVEsZUFBZTtHQUM3QixNQUFNLGNBQWMsTUFBTTtHQUMxQixNQUFNLGVBQWUsZ0JBQWdCO0dBQ3JDLE1BQU0sZ0JBQWdCLGdCQUFnQixhQUFhLFdBQVc7R0FDOUQsSUFBSSxDQUFDLGVBQWUsT0FBTyxjQUFjLE1BQU0sU0FBUztJQUN2RCxXQUFXO0lBQ1g7R0FDRCxDQUFDO0dBQ0QsTUFBTSxtQkFBbUIsYUFBYSxNQUFNO0dBQzVDLE1BQU0sYUFBYSxtQkFBbUIscUJBQXFCLE9BQU8sTUFBTSxTQUFTLE9BQU8scUJBQXFCLGFBQWEsaUJBQWlCLEtBQUssSUFBSSxtQkFBbUI7R0FDdkssTUFBTSxvQkFBb0IsVUFBVTtJQUNuQyxJQUFJLE1BQU0sVUFBVSxhQUFhLGFBQWEsVUFBVSxlQUFlO0dBQ3hFO0dBQ0EsTUFBTSxZQUFZLEVBQUUsZUFBZSxPQUFPLENBQUMsR0FBRyxZQUFZLE9BQU87SUFDaEU7SUFDQSxLQUFLO0dBQ04sQ0FBQyxDQUFDO0dBQ0YsSUFBd0UsYUFBYSxVQUFVLEtBQUs7SUFDbkcsTUFBTSxPQUFPO0tBQ1osT0FBTyxNQUFNO0tBQ2IsTUFBTSxhQUFhO0tBQ25CLE1BQU0sYUFBYTtLQUNuQixNQUFNLGFBQWE7SUFDcEI7SUFDQSxDQUFDLFFBQVEsVUFBVSxHQUFHLElBQUksVUFBVSxJQUFJLEtBQUssTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLEVBQUEsQ0FBRyxTQUFTLGFBQWE7S0FDbEcsU0FBUyxpQkFBaUI7SUFDM0IsQ0FBQztHQUNGO0dBQ0EsT0FBTyxjQUFjLE1BQU0sU0FBUztJQUNuQyxXQUFXO0lBQ1g7R0FDRCxDQUFDLEtBQUs7RUFDUDtDQUNEO0FBQ0QsQ0FBQztBQUNELFNBQVMsY0FBYyxNQUFNLE1BQU07Q0FDbEMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixNQUFNLGNBQWMsS0FBSyxJQUFJO0NBQzdCLE9BQU8sWUFBWSxXQUFXLElBQUksWUFBWSxLQUFLO0FBQ3BEOzs7O0FBSUEsSUFBTSxhQUFhO0FBQ25CLFNBQVMsc0JBQXNCO0NBQzlCLE1BQU0sV0FBVyxtQkFBbUI7Q0FDcEMsTUFBTSxhQUFhLFNBQVMsVUFBVSxTQUFTLE9BQU8sS0FBSztDQUMzRCxNQUFNLG9CQUFvQixTQUFTLFVBQVUsU0FBUyxPQUFPLFdBQVcsU0FBUyxPQUFPLFFBQVE7Q0FDaEcsSUFBSSxlQUFlLGVBQWUsZUFBZSxXQUFXLFNBQVMsWUFBWSxNQUFNLE9BQU8sc0JBQXNCLFlBQVksa0JBQWtCLFNBQVMsY0FBYztFQUN4SyxNQUFNLE9BQU8sZUFBZSxjQUFjLGVBQWU7RUFDekQsT0FBTzs7OztLQUlKLEtBQUssNENBQTRDLEtBQUssa0JBQWtCO0NBQzVFO0FBQ0Q7Ozs7OztBQVNBLFNBQVMsYUFBYSxTQUFTO0NBQzlCLE1BQU0sVUFBVSxvQkFBb0IsUUFBUSxRQUFRLE9BQU87Q0FDM0QsTUFBTSxlQUFlLFFBQVEsY0FBYztDQUMzQyxNQUFNLG1CQUFtQixRQUFRLGtCQUFrQjtDQUNuRCxNQUFNLGdCQUFnQixRQUFRO0NBQzlCLElBQTZDLENBQUMsZUFBZSxNQUFNLElBQUksTUFBTSxvSUFBb0k7Q0FDak4sTUFBTSxlQUFlLGFBQWE7Q0FDbEMsTUFBTSxzQkFBc0IsYUFBYTtDQUN6QyxNQUFNLGNBQWMsYUFBYTtDQUNqQyxNQUFNLGVBQWUsV0FBVyx5QkFBeUI7Q0FDekQsSUFBSSxrQkFBa0I7Q0FDdEIsSUFBSSxhQUFhLFFBQVEsa0JBQWtCLHVCQUF1QixTQUFTLFFBQVEsb0JBQW9CO0NBQ3ZHLE1BQU0sa0JBQWtCLGNBQWMsS0FBSyxPQUFPLGVBQWUsS0FBSyxVQUFVO0NBQ2hGLE1BQU0sZUFBZSxjQUFjLEtBQUssTUFBTSxXQUFXO0NBQ3pELE1BQU0sZUFBZSxjQUFjLEtBQUssTUFBTSxNQUFNO0NBQ3BELFNBQVMsU0FBUyxlQUFlLE9BQU87RUFDdkMsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJLFlBQVksYUFBYSxHQUFHO0dBQy9CLFNBQVMsUUFBUSxpQkFBaUIsYUFBYTtHQUMvQyxJQUE2QyxDQUFDLFFBQVEsT0FBTyxpQkFBaUIsT0FBTyxhQUFhLEVBQUUsc0NBQXNDLEtBQUs7R0FDL0ksU0FBUztFQUNWLE9BQU8sU0FBUztFQUNoQixPQUFPLFFBQVEsU0FBUyxRQUFRLE1BQU07Q0FDdkM7Q0FDQSxTQUFTLFlBQVksTUFBTTtFQUMxQixNQUFNLGdCQUFnQixRQUFRLGlCQUFpQixJQUFJO0VBQ25ELElBQUksZUFBZSxRQUFRLFlBQVksYUFBYTtPQUNKLE9BQU8scUNBQXFDLE9BQU8sSUFBSSxFQUFFLEVBQUU7Q0FDNUc7Q0FDQSxTQUFTLFlBQVk7RUFDcEIsT0FBTyxRQUFRLFVBQVUsQ0FBQyxDQUFDLEtBQUssaUJBQWlCLGFBQWEsTUFBTTtDQUNyRTtDQUNBLFNBQVMsU0FBUyxNQUFNO0VBQ3ZCLE9BQU8sQ0FBQyxDQUFDLFFBQVEsaUJBQWlCLElBQUk7Q0FDdkM7Q0FDQSxTQUFTLFFBQVEsYUFBYSxpQkFBaUI7RUFDOUMsa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLG1CQUFtQixhQUFhLEtBQUs7RUFDbEUsSUFBSSxPQUFPLGdCQUFnQixVQUFVO0dBQ3BDLE1BQU0scUJBQXFCLFNBQVMsY0FBYyxhQUFhLGdCQUFnQixJQUFJO0dBQ25GLE1BQU0saUJBQWlCLFFBQVEsUUFBUSxFQUFFLE1BQU0sbUJBQW1CLEtBQUssR0FBRyxlQUFlO0dBQ3pGLE1BQU0sU0FBUyxjQUFjLFdBQVcsbUJBQW1CLFFBQVE7R0FFbEUsSUFBSSxPQUFPLFdBQVcsSUFBSSxHQUFHLE9BQU8sYUFBYSxZQUFZLGlCQUFpQixPQUFPLDJEQUEyRDtRQUMzSSxJQUFJLENBQUMsZUFBZSxRQUFRLFFBQVEsT0FBTywwQ0FBMEMsWUFBWSxFQUFFO0dBRXpHLE9BQU8sT0FBTyxvQkFBb0IsZ0JBQWdCO0lBQ2pELFFBQVEsYUFBYSxlQUFlLE1BQU07SUFDMUMsTUFBTSxPQUFPLG1CQUFtQixJQUFJO0lBQ3BDLGdCQUFnQixLQUFLO0lBQ3JCLE1BQU07R0FDUCxDQUFDO0VBQ0Y7RUFDQSxJQUE2QyxDQUFDLGdCQUFnQixXQUFXLEdBQUc7R0FDM0UsT0FBTywrRkFBK0YsV0FBVztHQUNqSCxPQUFPLFFBQVEsQ0FBQyxDQUFDO0VBQ2xCO0VBQ0EsSUFBSTtFQUNKLElBQUksWUFBWSxRQUFRLE1BQU07R0FDN0IsSUFBNkMsWUFBWSxlQUFlLEVBQUUsVUFBVSxnQkFBZ0IsT0FBTyxLQUFLLFlBQVksTUFBTSxDQUFDLENBQUMsUUFBUSxPQUFPLFNBQVMsWUFBWSxLQUFLLCtGQUErRjtHQUM1USxrQkFBa0IsT0FBTyxDQUFDLEdBQUcsYUFBYSxFQUFFLE1BQU0sU0FBUyxjQUFjLFlBQVksTUFBTSxnQkFBZ0IsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0VBQ3hILE9BQU87R0FDTixNQUFNLGVBQWUsT0FBTyxDQUFDLEdBQUcsWUFBWSxNQUFNO0dBQ2xELEtBQUssTUFBTSxPQUFPLGNBQWMsSUFBSSxhQUFhLFFBQVEsTUFBTSxPQUFPLGFBQWE7R0FDbkYsa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGFBQWEsRUFBRSxRQUFRLGFBQWEsWUFBWSxFQUFFLENBQUM7R0FDaEYsZ0JBQWdCLFNBQVMsYUFBYSxnQkFBZ0IsTUFBTTtFQUM3RDtFQUNBLE1BQU0sZUFBZSxRQUFRLFFBQVEsaUJBQWlCLGVBQWU7RUFDckUsTUFBTSxPQUFPLFlBQVksUUFBUTtFQUNqQyxJQUE2QyxRQUFRLENBQUMsS0FBSyxXQUFXLEdBQUcsR0FBRyxPQUFPLG1FQUFtRSxLQUFLLFdBQVcsS0FBSyxHQUFHO0VBQzlLLGFBQWEsU0FBUyxnQkFBZ0IsYUFBYSxhQUFhLE1BQU0sQ0FBQztFQUN2RSxNQUFNLFdBQVcsYUFBYSxrQkFBa0IsT0FBTyxDQUFDLEdBQUcsYUFBYTtHQUN2RSxNQUFNLFdBQVcsSUFBSTtHQUNyQixNQUFNLGFBQWE7RUFDcEIsQ0FBQyxDQUFDO0VBQ0YsTUFBTSxPQUFPLGNBQWMsV0FBVyxRQUFRO0VBRTdDLElBQUksS0FBSyxXQUFXLElBQUksR0FBRyxPQUFPLGFBQWEsWUFBWSxpQkFBaUIsS0FBSywyREFBMkQ7T0FDdkksSUFBSSxDQUFDLGFBQWEsUUFBUSxRQUFRLE9BQU8sMENBQTBDLFlBQVksUUFBUSxPQUFPLFlBQVksT0FBTyxZQUFZLEVBQUU7RUFFckosT0FBTyxPQUFPO0dBQ2I7R0FDQTtHQUNBLE9BQU8scUJBQXFCLGlCQUFpQixlQUFlLFlBQVksS0FBSyxJQUFJLFlBQVksU0FBUyxDQUFDO0VBQ3hHLEdBQUcsY0FBYztHQUNoQixnQkFBZ0IsS0FBSztHQUNyQjtFQUNELENBQUM7Q0FDRjtDQUNBLFNBQVMsaUJBQWlCLElBQUk7RUFDN0IsT0FBTyxPQUFPLE9BQU8sV0FBVyxTQUFTLGNBQWMsSUFBSSxhQUFhLE1BQU0sSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUU7Q0FDcEc7Q0FDQSxTQUFTLHdCQUF3QixJQUFJLE1BQU07RUFDMUMsSUFBSSxvQkFBb0IsSUFBSSxPQUFPLGtCQUFrQixXQUFXLHNCQUFzQjtHQUNyRjtHQUNBO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsU0FBUyxLQUFLLElBQUk7RUFDakIsT0FBTyxpQkFBaUIsRUFBRTtDQUMzQjtDQUNBLFNBQVMsUUFBUSxJQUFJO0VBQ3BCLE9BQU8sS0FBSyxPQUFPLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0NBQzVEO0NBQ0EsU0FBUyxxQkFBcUIsSUFBSSxNQUFNO0VBQ3ZDLE1BQU0sY0FBYyxHQUFHLFFBQVEsR0FBRyxRQUFRLFNBQVM7RUFDbkQsSUFBSSxlQUFlLFlBQVksVUFBVTtHQUN4QyxNQUFNLEVBQUUsYUFBYTtHQUNyQixJQUFJLG9CQUFvQixPQUFPLGFBQWEsYUFBYSxTQUFTLElBQUksSUFBSSxJQUFJO0dBQzlFLElBQUksT0FBTyxzQkFBc0IsVUFBVTtJQUMxQyxvQkFBb0Isa0JBQWtCLFNBQVMsR0FBRyxLQUFLLGtCQUFrQixTQUFTLEdBQUcsSUFBSSxvQkFBb0IsaUJBQWlCLGlCQUFpQixJQUFJLEVBQUUsTUFBTSxrQkFBa0I7SUFDN0ssa0JBQWtCLFNBQVMsQ0FBQztHQUM3QjtHQUNBLElBQTZDLGtCQUFrQixRQUFRLFFBQVEsRUFBRSxVQUFVLG9CQUFvQjtJQUM5RyxPQUFPLDRCQUE0QixLQUFLLFVBQVUsbUJBQW1CLE1BQU0sQ0FBQyxFQUFFLHlCQUF5QixHQUFHLFNBQVMsMEVBQTBFO0lBQzdMLE1BQU0sSUFBSSxNQUFNLGtCQUFrQjtHQUNuQztHQUNBLE9BQU8sT0FBTztJQUNiLE9BQU8sR0FBRztJQUNWLE1BQU0sR0FBRztJQUNULFFBQVEsa0JBQWtCLFFBQVEsT0FBTyxDQUFDLElBQUksR0FBRztHQUNsRCxHQUFHLGlCQUFpQjtFQUNyQjtDQUNEO0NBQ0EsU0FBUyxpQkFBaUIsSUFBSSxnQkFBZ0I7RUFDN0MsTUFBTSxpQkFBaUIsa0JBQWtCLFFBQVEsRUFBRTtFQUNuRCxNQUFNLE9BQU8sYUFBYTtFQUMxQixNQUFNLE9BQU8sR0FBRztFQUNoQixNQUFNLFFBQVEsR0FBRztFQUNqQixNQUFNLFlBQVksR0FBRyxZQUFZO0VBQ2pDLE1BQU0saUJBQWlCLHFCQUFxQixnQkFBZ0IsSUFBSTtFQUNoRSxJQUFJLGdCQUFnQixPQUFPLGlCQUFpQixPQUFPLGlCQUFpQixjQUFjLEdBQUc7R0FDcEYsT0FBTyxPQUFPLG1CQUFtQixXQUFXLE9BQU8sQ0FBQyxHQUFHLE1BQU0sZUFBZSxLQUFLLElBQUk7R0FDckY7R0FDQSxTQUFTO0VBQ1YsQ0FBQyxHQUFHLGtCQUFrQixjQUFjO0VBQ3BDLE1BQU0sYUFBYTtFQUNuQixXQUFXLGlCQUFpQjtFQUM1QixJQUFJO0VBQ0osSUFBSSxDQUFDLFNBQVMsb0JBQW9CLGtCQUFrQixNQUFNLGNBQWMsR0FBRztHQUMxRSxVQUFVLGtCQUFrQixXQUFXLHVCQUF1QjtJQUM3RCxJQUFJO0lBQ0o7R0FDRCxDQUFDO0dBQ0QsYUFBYSxNQUFNLE1BQU0sTUFBTSxLQUFLO0VBQ3JDO0VBQ0EsUUFBUSxVQUFVLFFBQVEsUUFBUSxPQUFPLElBQUksU0FBUyxZQUFZLElBQUksRUFBQSxDQUFHLE9BQU8sVUFBVSxvQkFBb0IsS0FBSyxJQUFJLG9CQUFvQixPQUFPLFdBQVcseUJBQXlCLElBQUksUUFBUSxZQUFZLEtBQUssSUFBSSxhQUFhLE9BQU8sWUFBWSxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sY0FBYztHQUNqUixJQUFJLFdBQ0M7UUFBQSxvQkFBb0IsV0FBVyxXQUFXLHlCQUF5QixHQUFHO0tBQ3pFLElBQTZDLG9CQUFvQixrQkFBa0IsUUFBUSxVQUFVLEVBQUUsR0FBRyxVQUFVLEtBQUssbUJBQW1CLGVBQWUsU0FBUyxlQUFlLFNBQVMsZUFBZSxTQUFTLElBQUksS0FBSyxJQUFJO01BQ2hPLE9BQU8sbUZBQW1GLEtBQUssU0FBUyxRQUFRLFdBQVcsU0FBUyx3UEFBd1A7TUFDNVgsT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sdUNBQXVDLENBQUM7S0FDekY7S0FDQSxPQUFPLGlCQUFpQixPQUFPLEVBQUUsU0FBUyxVQUFVLEdBQUcsaUJBQWlCLFVBQVUsRUFBRSxHQUFHO01BQ3RGLE9BQU8sT0FBTyxVQUFVLE9BQU8sV0FBVyxPQUFPLENBQUMsR0FBRyxNQUFNLFVBQVUsR0FBRyxLQUFLLElBQUk7TUFDakY7S0FDRCxDQUFDLEdBQUcsa0JBQWtCLFVBQVU7SUFDakM7VUFDTSxZQUFZLG1CQUFtQixZQUFZLE1BQU0sTUFBTSxXQUFXLElBQUk7R0FDN0UsaUJBQWlCLFlBQVksTUFBTSxTQUFTO0dBQzVDLE9BQU87RUFDUixDQUFDO0NBQ0Y7Ozs7OztDQU1BLFNBQVMsaUNBQWlDLElBQUksTUFBTTtFQUNuRCxNQUFNLFFBQVEsd0JBQXdCLElBQUksSUFBSTtFQUM5QyxPQUFPLFFBQVEsUUFBUSxPQUFPLEtBQUssSUFBSSxRQUFRLFFBQVE7Q0FDeEQ7Q0FDQSxTQUFTLGVBQWUsSUFBSTtFQUMzQixNQUFNLE1BQU0sY0FBYyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztFQUMxQyxPQUFPLE9BQU8sT0FBTyxJQUFJLG1CQUFtQixhQUFhLElBQUksZUFBZSxFQUFFLElBQUksR0FBRztDQUN0RjtDQUNBLFNBQVMsU0FBUyxJQUFJLE1BQU07RUFDM0IsSUFBSTtFQUNKLE1BQU0sQ0FBQyxnQkFBZ0IsaUJBQWlCLG1CQUFtQix1QkFBdUIsSUFBSSxJQUFJO0VBQzFGLFNBQVMsd0JBQXdCLGVBQWUsUUFBUSxHQUFHLG9CQUFvQixJQUFJLElBQUk7RUFDdkYsS0FBSyxNQUFNLFVBQVUsZ0JBQWdCLE9BQU8sWUFBWSxTQUFTLFVBQVU7R0FDMUUsT0FBTyxLQUFLLGlCQUFpQixPQUFPLElBQUksSUFBSSxDQUFDO0VBQzlDLENBQUM7RUFDRCxNQUFNLDBCQUEwQixpQ0FBaUMsS0FBSyxNQUFNLElBQUksSUFBSTtFQUNwRixPQUFPLEtBQUssdUJBQXVCO0VBQ25DLE9BQU8sY0FBYyxNQUFNLENBQUMsQ0FBQyxXQUFXO0dBQ3ZDLFNBQVMsQ0FBQztHQUNWLEtBQUssTUFBTSxTQUFTLGFBQWEsS0FBSyxHQUFHLE9BQU8sS0FBSyxpQkFBaUIsT0FBTyxJQUFJLElBQUksQ0FBQztHQUN0RixPQUFPLEtBQUssdUJBQXVCO0dBQ25DLE9BQU8sY0FBYyxNQUFNO0VBQzVCLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDYixTQUFTLHdCQUF3QixpQkFBaUIscUJBQXFCLElBQUksSUFBSTtHQUMvRSxLQUFLLE1BQU0sVUFBVSxpQkFBaUIsT0FBTyxhQUFhLFNBQVMsVUFBVTtJQUM1RSxPQUFPLEtBQUssaUJBQWlCLE9BQU8sSUFBSSxJQUFJLENBQUM7R0FDOUMsQ0FBQztHQUNELE9BQU8sS0FBSyx1QkFBdUI7R0FDbkMsT0FBTyxjQUFjLE1BQU07RUFDNUIsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLFNBQVMsQ0FBQztHQUNWLEtBQUssTUFBTSxVQUFVLGlCQUFpQixJQUFJLE9BQU8sYUFBYSxJQUFJLFFBQVEsT0FBTyxXQUFXLEdBQUcsS0FBSyxNQUFNLGVBQWUsT0FBTyxhQUFhLE9BQU8sS0FBSyxpQkFBaUIsYUFBYSxJQUFJLElBQUksQ0FBQztRQUMzTCxPQUFPLEtBQUssaUJBQWlCLE9BQU8sYUFBYSxJQUFJLElBQUksQ0FBQztHQUMvRCxPQUFPLEtBQUssdUJBQXVCO0dBQ25DLE9BQU8sY0FBYyxNQUFNO0VBQzVCLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDYixHQUFHLFFBQVEsU0FBUyxXQUFXLE9BQU8saUJBQWlCLENBQUMsQ0FBQztHQUN6RCxTQUFTLHdCQUF3QixpQkFBaUIsb0JBQW9CLElBQUksTUFBTSxjQUFjO0dBQzlGLE9BQU8sS0FBSyx1QkFBdUI7R0FDbkMsT0FBTyxjQUFjLE1BQU07RUFDNUIsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLFNBQVMsQ0FBQztHQUNWLEtBQUssTUFBTSxTQUFTLG9CQUFvQixLQUFLLEdBQUcsT0FBTyxLQUFLLGlCQUFpQixPQUFPLElBQUksSUFBSSxDQUFDO0dBQzdGLE9BQU8sS0FBSyx1QkFBdUI7R0FDbkMsT0FBTyxjQUFjLE1BQU07RUFDNUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRLG9CQUFvQixLQUFLLFdBQVcsb0JBQW9CLElBQUksTUFBTSxRQUFRLE9BQU8sR0FBRyxDQUFDO0NBQ3hHO0NBQ0EsU0FBUyxpQkFBaUIsSUFBSSxNQUFNLFNBQVM7RUFDNUMsWUFBWSxLQUFLLENBQUMsQ0FBQyxTQUFTLFVBQVUscUJBQXFCLE1BQU0sSUFBSSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0NBQ3JGOzs7Ozs7Q0FNQSxTQUFTLG1CQUFtQixZQUFZLE1BQU0sUUFBUSxXQUFXLE1BQU07RUFDdEUsTUFBTSxRQUFRLHdCQUF3QixZQUFZLElBQUk7RUFDdEQsSUFBSSxPQUFPLE9BQU87RUFDbEIsTUFBTSxvQkFBb0IsU0FBUztFQUNuQyxNQUFNLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxRQUFRO0VBQ3hDLElBQUksUUFBUSxJQUFJLGFBQWEsbUJBQW1CLGNBQWMsUUFBUSxXQUFXLFVBQVUsT0FBTyxFQUFFLFFBQVEscUJBQXFCLFNBQVMsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDO09BQzFKLGNBQWMsS0FBSyxXQUFXLFVBQVUsSUFBSTtFQUNqRCxhQUFhLFFBQVE7RUFDckIsYUFBYSxZQUFZLE1BQU0sUUFBUSxpQkFBaUI7RUFDeEQsWUFBWTtDQUNiO0NBQ0EsSUFBSTtDQUNKLFNBQVMsaUJBQWlCO0VBQ3pCLElBQUksdUJBQXVCO0VBQzNCLHdCQUF3QixjQUFjLFFBQVEsSUFBSSxPQUFPLFNBQVM7R0FDakUsSUFBSSxDQUFDLE9BQU8sV0FBVztHQUN2QixNQUFNLGFBQWEsUUFBUSxFQUFFO0dBQzdCLE1BQU0saUJBQWlCLHFCQUFxQixZQUFZLE9BQU8sYUFBYSxLQUFLO0dBQ2pGLElBQUksZ0JBQWdCO0lBQ25CLGlCQUFpQixPQUFPLGdCQUFnQjtLQUN2QyxTQUFTO0tBQ1QsT0FBTztJQUNSLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxNQUFNLElBQUk7SUFDMUI7R0FDRDtHQUNBLGtCQUFrQjtHQUNsQixNQUFNLE9BQU8sYUFBYTtHQUMxQixJQUFJLFdBQVcsbUJBQW1CLGFBQWEsS0FBSyxVQUFVLEtBQUssS0FBSyxHQUFHLHNCQUFzQixDQUFDO0dBQ2xHLFNBQVMsWUFBWSxJQUFJLENBQUMsQ0FBQyxPQUFPLFVBQVU7SUFDM0MsSUFBSSxvQkFBb0IsT0FBTyxXQUFXLHFCQUFxQixXQUFXLG9CQUFvQixHQUFHLE9BQU87SUFDeEcsSUFBSSxvQkFBb0IsT0FBTyxXQUFXLHlCQUF5QixHQUFHO0tBQ3JFLGlCQUFpQixPQUFPLGlCQUFpQixNQUFNLEVBQUUsR0FBRyxFQUFFLE9BQU8sS0FBSyxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsTUFBTSxZQUFZO01BQ25HLElBQUksb0JBQW9CLFNBQVMsV0FBVyxxQkFBcUIsV0FBVyxxQkFBcUIsS0FBSyxDQUFDLEtBQUssU0FBUyxLQUFLLFNBQVMsZUFBZSxLQUFLLGNBQWMsR0FBRyxJQUFJLEtBQUs7S0FDbEwsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0tBQ2IsT0FBTyxRQUFRLE9BQU87SUFDdkI7SUFDQSxJQUFJLEtBQUssT0FBTyxjQUFjLEdBQUcsQ0FBQyxLQUFLLE9BQU8sS0FBSztJQUNuRCxPQUFPLGFBQWEsT0FBTyxZQUFZLElBQUk7R0FDNUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxZQUFZO0lBQ3BCLFVBQVUsV0FBVyxtQkFBbUIsWUFBWSxNQUFNLEtBQUs7SUFDL0QsSUFBSSxTQUFTO0tBQ1osSUFBSSxLQUFLLFNBQVMsQ0FBQyxvQkFBb0IsU0FBUyxXQUFXLG9CQUFvQixHQUFHLGNBQWMsR0FBRyxDQUFDLEtBQUssT0FBTyxLQUFLO1VBQ2hILElBQUksS0FBSyxTQUFTLGVBQWUsT0FBTyxvQkFBb0IsU0FBUyxXQUFXLHFCQUFxQixXQUFXLHFCQUFxQixHQUFHLGNBQWMsR0FBRyxJQUFJLEtBQUs7SUFDeEs7SUFDQSxpQkFBaUIsWUFBWSxNQUFNLE9BQU87R0FDM0MsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0VBQ2QsQ0FBQztDQUNGO0NBQ0EsSUFBSSxnQkFBZ0IsYUFBYTtDQUNqQyxJQUFJLGlCQUFpQixhQUFhO0NBQ2xDLElBQUk7Ozs7Ozs7OztDQVNKLFNBQVMsYUFBYSxPQUFPLElBQUksTUFBTTtFQUN0QyxZQUFZLEtBQUs7RUFDakIsTUFBTSxPQUFPLGVBQWUsS0FBSztFQUNqQyxJQUFJLEtBQUssUUFBUSxLQUFLLFNBQVMsWUFBWSxRQUFRLE9BQU8sSUFBSSxJQUFJLENBQUM7T0FDOUQ7R0FDdUMsT0FBTyx5Q0FBeUM7R0FDM0YsUUFBUSxNQUFNLEtBQUs7RUFDcEI7RUFDQSxPQUFPLFFBQVEsT0FBTyxLQUFLO0NBQzVCO0NBQ0EsU0FBUyxVQUFVO0VBQ2xCLElBQUksU0FBUyxhQUFhLFVBQVUsMkJBQTJCLE9BQU8sUUFBUSxRQUFRO0VBQ3RGLE9BQU8sSUFBSSxTQUFTLFdBQVcsV0FBVztHQUN6QyxjQUFjLElBQUksQ0FBQyxXQUFXLE1BQU0sQ0FBQztFQUN0QyxDQUFDO0NBQ0Y7Q0FDQSxTQUFTLFlBQVksS0FBSztFQUN6QixJQUFJLENBQUMsT0FBTztHQUNYLFFBQVEsQ0FBQztHQUNULGVBQWU7R0FDZixjQUFjLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxXQUFXLFlBQVksTUFBTSxPQUFPLEdBQUcsSUFBSSxVQUFVLENBQUM7R0FDckYsY0FBYyxNQUFNO0VBQ3JCO0VBQ0EsT0FBTztDQUNSO0NBQ0EsU0FBUyxhQUFhLElBQUksTUFBTSxRQUFRLG1CQUFtQjtFQUMxRCxNQUFNLEVBQUUsbUJBQW1CO0VBQzNCLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLE9BQU8sUUFBUSxRQUFRO0VBQzFELE1BQU0saUJBQWlCLENBQUMsVUFBVSx1QkFBdUIsYUFBYSxHQUFHLFVBQVUsQ0FBQyxDQUFDLE1BQU0scUJBQXFCLENBQUMsV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNLFVBQVU7RUFDckssT0FBTyxTQUFTLENBQUMsQ0FBQyxXQUFXLGVBQWUsSUFBSSxNQUFNLGNBQWMsQ0FBQyxDQUFDLENBQUMsTUFBTSxhQUFhLFlBQVksaUJBQWlCLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRLGFBQWEsS0FBSyxJQUFJLElBQUksQ0FBQztDQUM3SztDQUNBLE1BQU0sTUFBTSxVQUFVLGNBQWMsR0FBRyxLQUFLO0NBQzVDLElBQUk7Q0FDSixNQUFNLGdDQUFnQyxJQUFJLElBQUk7Q0FDOUMsTUFBTSxTQUFTO0VBQ2Q7RUFDQSxXQUFXO0VBQ1g7RUFDQTtFQUNBLGFBQWEsUUFBUTtFQUNyQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLFlBQVksR0FBRyxFQUFFO0VBQ2pCLGVBQWUsR0FBRyxDQUFDO0VBQ25CLFlBQVksYUFBYTtFQUN6QixlQUFlLG9CQUFvQjtFQUNuQyxXQUFXLFlBQVk7RUFDdkIsU0FBUyxlQUFlO0VBQ3hCO0VBQ0EsUUFBUSxLQUFLO0dBQ1osSUFBSSxVQUFVLGNBQWMsVUFBVTtHQUN0QyxJQUFJLFVBQVUsY0FBYyxVQUFVO0dBQ3RDLElBQUksT0FBTyxpQkFBaUIsVUFBVTtHQUN0QyxPQUFPLGVBQWUsSUFBSSxPQUFPLGtCQUFrQixVQUFVO0lBQzVELFlBQVk7SUFDWixXQUFXLE1BQU0sWUFBWTtHQUM5QixDQUFDO0dBQ0QsSUFBSSxhQUFhLENBQUMsV0FBVyxhQUFhLFVBQVUsMkJBQTJCO0lBQzlFLFVBQVU7SUFDVixLQUFLLGNBQWMsUUFBUSxDQUFDLENBQUMsT0FBTyxRQUFRO0tBQ0EsT0FBTyw4Q0FBOEMsR0FBRztJQUNwRyxDQUFDO0dBQ0Y7R0FDQSxNQUFNLGdCQUFnQixDQUFDO0dBQ3ZCLEtBQUssTUFBTSxPQUFPLDJCQUEyQixPQUFPLGVBQWUsZUFBZSxLQUFLO0lBQ3RGLFdBQVcsYUFBYSxNQUFNO0lBQzlCLFlBQVk7R0FDYixDQUFDO0dBQ0QsSUFBSSxRQUFRLFdBQVcsTUFBTTtHQUM3QixJQUFJLFFBQVEsa0JBQWtCLGdCQUFnQixhQUFhLENBQUM7R0FDNUQsSUFBSSxRQUFRLHVCQUF1QixZQUFZO0dBQy9DLE1BQU0sYUFBYSxJQUFJO0dBQ3ZCLGNBQWMsSUFBSSxHQUFHO0dBQ3JCLElBQUksVUFBVSxXQUFXO0lBQ3hCLGNBQWMsT0FBTyxHQUFHO0lBQ3hCLElBQUksY0FBYyxPQUFPLEdBQUc7S0FDM0Isa0JBQWtCO0tBQ2xCLHlCQUF5QixzQkFBc0I7S0FDL0Msd0JBQXdCO0tBQ3hCLGFBQWEsUUFBUTtLQUNyQixVQUFVO0tBQ1YsUUFBUTtJQUNUO0lBQ0EsV0FBVztHQUNaO0dBQ0EsSUFBd0UsV0FBVyxZQUFZLEtBQUssUUFBUSxPQUFPO0VBQ3BIO0NBQ0Q7Q0FDQSxTQUFTLGNBQWMsUUFBUTtFQUM5QixPQUFPLE9BQU8sUUFBUSxTQUFTLFVBQVUsUUFBUSxXQUFXLGVBQWUsS0FBSyxDQUFDLEdBQUcsUUFBUSxRQUFRLENBQUM7Q0FDdEc7Q0FDQSxPQUFPO0FBQ1I7Ozs7O0FBUUEsU0FBUyxZQUFZO0NBQ3BCLE9BQU8sT0FBTyxTQUFTO0FBQ3hCOzs7OztBQUtBLFNBQVMsU0FBUyxPQUFPO0NBQ3hCLE9BQU8sT0FBTyxnQkFBZ0I7QUFDL0IiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNl19