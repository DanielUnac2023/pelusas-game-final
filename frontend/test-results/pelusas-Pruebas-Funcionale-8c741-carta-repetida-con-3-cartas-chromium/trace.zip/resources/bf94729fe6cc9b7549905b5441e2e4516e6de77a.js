import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/History.vue");const _sfc_main = {  }
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=ecda106e"

const _hoisted_1 = { class: "min-h-screen bg-slate-950 text-white p-6 flex flex-col items-center justify-center" }
const _hoisted_2 = { class: "text-slate-400 text-sm mb-6" }

function _sfc_render(_ctx, _cache) {
  const _component_router_link = _resolveComponent("router-link")

  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _cache[1] || (_cache[1] = _createElementVNode("h1", { class: "text-3xl font-black text-amber-400 mb-2" }, "TABLERO DE JUEGO", -1 /* CACHED */)),
    _createElementVNode("p", _hoisted_2, "Partida ID: " + _toDisplayString(_ctx.$route.params.id), 1 /* TEXT */),
    _createVNode(_component_router_link, {
      to: "/",
      class: "px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs hover:bg-slate-700 transition-colors"
    }, {
      default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
        _createTextVNode(" ← Volver a Configuración ", -1 /* CACHED */)
      ]))]),
      _: 1 /* STABLE */
    })
  ]))
}



_sfc_main.__hmrId = "89ccdf85"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/danie/Downloads/pelusas-game/frontend/src/views/History.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvZGFuaWUvRG93bmxvYWRzL3BlbHVzYXMtZ2FtZS9mcm9udGVuZC9zcmMvdmlld3MvSGlzdG9yeS52dWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGlzdG9yeS52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gIDxkaXYgY2xhc3M9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTUwIHRleHQtd2hpdGUgcC02IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICA8aDEgY2xhc3M9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtYW1iZXItNDAwIG1iLTJcIj5UQUJMRVJPIERFIEpVRUdPPC9oMT5cclxuICAgIDxwIGNsYXNzPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBtYi02XCI+UGFydGlkYSBJRDoge3sgJHJvdXRlLnBhcmFtcy5pZCB9fTwvcD5cclxuICAgIDxyb3V0ZXItbGluayB0bz1cIi9cIiBjbGFzcz1cInB4LTQgcHktMiBiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIGhvdmVyOmJnLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICDihpAgVm9sdmVyIGEgQ29uZmlndXJhY2nDs25cclxuICAgIDwvcm91dGVyLWxpbms+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+Il0sIm1hcHBpbmdzIjoiOzs7cUJBQ08sS0FBSyxFQUFDLG9GQUFvRjtxQkFFMUYsS0FBSyxFQUFDLDZCQUE2Qjs7Ozs7d0JBRnhDLG9CQU1NLE9BTk4sVUFNTTs4QkFMSixvQkFBeUUsUUFBckUsS0FBSyxFQUFDLHlDQUF5QyxJQUFDLGtCQUFnQjtJQUNwRSxvQkFBNkUsS0FBN0UsVUFBNkUsRUFBdEMsY0FBWSxvQkFBRyxXQUFNLENBQUMsTUFBTSxDQUFDLEVBQUU7SUFDdEUsYUFFYztNQUZELEVBQUUsRUFBQyxHQUFHO01BQUMsS0FBSyxFQUFDLHdHQUF3Rzs7d0JBQUMsQ0FFbkk7eUJBRm1JLDRCQUVuSSIsImlnbm9yZUxpc3QiOltdfQ==