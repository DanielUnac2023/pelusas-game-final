import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/Board.vue");import { ref, onMounted, computed } from "/node_modules/.vite/deps/vue.js?v=0b5deebc"
import { useRoute, useRouter } from "/node_modules/.vite/deps/vue-router.js?v=0b5deebc"
import { GameAPI } from "/src/services/api.js"


const _sfc_main = {
  __name: 'Board',
  setup(__props, { expose: __expose }) {
  __expose();

const route = useRoute()
const router = useRouter()

const partidaId = route.params.id
const gameState = ref(null)
const cargando = ref(true)
const errorMensaje = ref('')

// Cargar estado inicial de la partida desde Spring Boot
const cargarPartida = async () => {
  try {
    cargando.value = true
    errorMensaje.value = ''
    gameState.value = await GameAPI.obtenerPartida(partidaId)
  } catch (err) {
    errorMensaje.value = 'Error al obtener el estado de la partida desde el backend.'
    console.error(err)
  } finally {
    cargando.value = false
  }
}

// Ejecutar acciones del juego (Sacar, Guardar, Plantarse)
const ejecutarAccion = async (tipoAccion, parametro = null) => {
  try {
    if (tipoAccion === 'sacar') {
      gameState.value = await GameAPI.sacarCarta(partidaId)
    } else if (tipoAccion === 'guardar') {
      gameState.value = await GameAPI.guardarPelusas(partidaId)
    } else if (tipoAccion === 'plantarse') {
      gameState.value = await GameAPI.plantarse(partidaId)
    } else if (tipoAccion === 'robar') {
      gameState.value = await GameAPI.robarCartas(partidaId, parametro)
    }
  } catch (err) {
    console.error(`Error ejecutando acción ${tipoAccion}:`, err)
  }
}

// Saber si la partida terminó
const esFinalizada = computed(() => {
  return gameState.value && gameState.value.estadoPartida === 'FINALIZADA'
})

onMounted(() => {
  cargarPartida()
})

const __returned__ = { route, router, partidaId, gameState, cargando, errorMensaje, cargarPartida, ejecutarAccion, esFinalizada, ref, onMounted, computed, get useRoute() { return useRoute }, get useRouter() { return useRouter }, get GameAPI() { return GameAPI } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString, Fragment as _Fragment, renderList as _renderList, normalizeClass as _normalizeClass } from "/node_modules/.vite/deps/vue.js?v=0b5deebc"

const _hoisted_1 = { class: "min-h-screen bg-slate-950 text-slate-100 font-sans p-6" }
const _hoisted_2 = {
  key: 0,
  class: "flex flex-col items-center justify-center min-h-[60vh]"
}
const _hoisted_3 = { class: "max-w-md mx-auto my-10 bg-red-900/50 border border-red-500 p-6 rounded-2xl text-center" }
const _hoisted_4 = { class: "text-red-200 font-bold mb-4" }
const _hoisted_5 = { class: "flex flex-col gap-3 w-full" }
const _hoisted_6 = { class: "bg-slate-900 p-8 rounded-2xl border border-slate-800 flex justify-between items-center shadow-lg" }
const _hoisted_7 = { class: "text-xs font-bold text-slate-500 uppercase" }
const _hoisted_8 = {
  class: "text-xl font-black text-amber-400",
  "data-testid": "turn-owner"
}
const _hoisted_9 = { class: "bg-slate-800 px-5 py-2 rounded-xl border border-slate-700 text-right" }
const _hoisted_10 = { class: "text-lg font-black text-emerald-400" }
const _hoisted_11 = { class: "bg-slate-900/60 border border-amber-500/20 p-4 rounded-xl text-center text-sm font-semibold text-amber-200" }
const _hoisted_12 = {
  key: 0,
  class: "bg-slate-900 p-6 rounded-2xl border border-slate-800 flex flex-wrap gap-4 justify-center"
}
const _hoisted_13 = { class: "bg-emerald-900/40 border border-emerald-500 p-6 rounded-2xl text-center space-y-3" }
const _hoisted_14 = { class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3" }
const _hoisted_15 = { class: "flex justify-between items-center mb-3" }
const _hoisted_16 = { class: "font-bold text-slate-200" }
const _hoisted_17 = { class: "bg-amber-500/10 text-amber-400 text-xs px-2.5 py-1 rounded-lg font-black border border-amber-500/20" }
const _hoisted_18 = { class: "space-y-1" }
const _hoisted_19 = { class: "flex flex-wrap gap-2 min-h-[40px] items-center" }
const _hoisted_20 = {
  key: 0,
  class: "text-xs italic text-slate-600"
}

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("main", _hoisted_1, [
    _createCommentVNode(" Pantalla de Carga "),
    ($setup.cargando)
      ? (_openBlock(), _createElementBlock("div", _hoisted_2, [...(_cache[6] || (_cache[6] = [
          _createElementVNode("div", { class: "text-amber-400 font-bold text-xl animate-pulse" }, "Cargando tablero...", -1 /* CACHED */)
        ]))]))
      : ($setup.errorMensaje)
        ? (_openBlock(), _createElementBlock(_Fragment, { key: 1 }, [
            _createCommentVNode(" Error de Conexión "),
            _createElementVNode("div", _hoisted_3, [
              _createElementVNode("p", _hoisted_4, _toDisplayString($setup.errorMensaje), 1 /* TEXT */),
              _createElementVNode("button", {
                onClick: _cache[0] || (_cache[0] = $event => ($setup.router.push('/'))),
                class: "bg-slate-800 hover:bg-slate-700 text-white font-bold px-4 py-2 rounded-xl text-xs"
              }, " Volver al Inicio ")
            ])
          ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */))
        : ($setup.gameState)
          ? (_openBlock(), _createElementBlock(_Fragment, { key: 2 }, [
              _createCommentVNode(" Tablero de Juego Activo "),
              _createElementVNode("div", _hoisted_5, [
                _createCommentVNode(" Encabezado de la Mesa "),
                _createElementVNode("header", _hoisted_6, [
                  _createElementVNode("div", null, [
                    _createElementVNode("span", _hoisted_7, "Partida #" + _toDisplayString($setup.gameState.idPartida), 1 /* TEXT */),
                    _createElementVNode("h1", _hoisted_8, " Turno actual: " + _toDisplayString($setup.gameState.nombreJugadorActual), 1 /* TEXT */)
                  ]),
                  _createCommentVNode(" Info del Mazo "),
                  _createElementVNode("div", _hoisted_9, [
                    _cache[7] || (_cache[7] = _createElementVNode("span", { class: "text-xs text-slate-400 block font-bold" }, "Mazo Restante", -1 /* CACHED */)),
                    _createElementVNode("span", _hoisted_10, _toDisplayString($setup.gameState.cartasRestantesMazo) + " cartas", 1 /* TEXT */)
                  ])
                ]),
                _createCommentVNode(" Panel de Alertas / Eventos del Backend "),
                _createElementVNode("div", _hoisted_11, " 📢 " + _toDisplayString($setup.gameState.mensajeEvento), 1 /* TEXT */),
                _createCommentVNode(" Panel de Controles de Acción (Para el Jugador Actual) "),
                (!$setup.esFinalizada)
                  ? (_openBlock(), _createElementBlock("div", _hoisted_12, [
                      _createElementVNode("button", {
                        onClick: _cache[1] || (_cache[1] = $event => ($setup.ejecutarAccion('guardar'))),
                        "data-testid": "btn-guardar",
                        class: "bg-emerald-600 hover:bg-emerald-500 font-bold px-6 py-3 rounded-xl transition cursor-pointer text-sm"
                      }, " 📥 Guardar Pelusas "),
                      _createElementVNode("button", {
                        onClick: _cache[2] || (_cache[2] = $event => ($setup.ejecutarAccion('sacar'))),
                        "data-testid": "btn-sacar-carta",
                        class: "bg-amber-400 hover:bg-amber-300 text-slate-950 font-black px-8 py-3 rounded-xl transition cursor-pointer text-sm uppercase shadow-lg shadow-amber-400/10"
                      }, " 🃏 Sacar Carta "),
                      _createElementVNode("button", {
                        onClick: _cache[3] || (_cache[3] = $event => ($setup.ejecutarAccion('plantarse'))),
                        "data-testid": "btn-plantarse",
                        class: "bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-6 py-3 rounded-xl border border-slate-700 transition cursor-pointer text-sm"
                      }, " 🛑 Plantarse "),
                      _createElementVNode("button", {
                        onClick: _cache[4] || (_cache[4] = $event => ($setup.ejecutarAccion('robar'))),
                        "data-testid": "btn-robar",
                        class: "bg-rose-600 hover:bg-rose-500 font-bold px-6 py-3 rounded-xl transition cursor-pointer text-sm"
                      }, " 🫳 Robar Pelusas ")
                    ]))
                  : (_openBlock(), _createElementBlock(_Fragment, { key: 1 }, [
                      _createCommentVNode(" Mensaje si la partida ha finalizado "),
                      _createElementVNode("div", _hoisted_13, [
                        _cache[8] || (_cache[8] = _createElementVNode("h2", { class: "text-2xl font-black text-emerald-300" }, "🎉 ¡Partida Finalizada!", -1 /* CACHED */)),
                        _cache[9] || (_cache[9] = _createElementVNode("p", { class: "text-slate-300 text-sm" }, "Se agotó el mazo. Revisa el conteo final de puntos abajo.", -1 /* CACHED */)),
                        _createElementVNode("button", {
                          onClick: _cache[5] || (_cache[5] = $event => ($setup.router.push('/'))),
                          class: "bg-emerald-500 text-slate-950 font-bold px-6 py-2 rounded-xl text-xs uppercase"
                        }, " Nueva Partida ")
                      ])
                    ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */)),
                _createCommentVNode(" Renderizado de las Mesas de Todos los Jugadores (2 a 6) "),
                _createElementVNode("section", _hoisted_14, [
                  (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.gameState.jugadores, (jugador) => {
                    return (_openBlock(), _createElementBlock("div", {
                      key: jugador.id,
                      class: _normalizeClass(["bg-slate-900 p-6 rounded-2xl border transition-all", jugador.nombre === $setup.gameState.nombreJugadorActual ? 'border-amber-400/60 ring-1 ring-amber-400/30' : 'border-slate-800'])
                    }, [
                      _createCommentVNode(" Nombre y Puntuación Acumulada "),
                      _createElementVNode("div", _hoisted_15, [
                        _createElementVNode("span", _hoisted_16, _toDisplayString(jugador.nombre), 1 /* TEXT */),
                        _createElementVNode("span", _hoisted_17, _toDisplayString(jugador.puntosTotales) + " Pts ", 1 /* TEXT */)
                      ]),
                      _createCommentVNode(" Cartas expuestas en mesa de este jugador (Cartas Delante) "),
                      _createElementVNode("div", _hoisted_18, [
                        _cache[10] || (_cache[10] = _createElementVNode("span", { class: "text-xs text-slate-500 font-bold uppercase" }, "Cartas en mesa:", -1 /* CACHED */)),
                        _createElementVNode("div", _hoisted_19, [
                          (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(jugador.cartasDelante, (carta, idx) => {
                            return (_openBlock(), _createElementBlock("span", {
                              key: idx,
                              "data-testid": "carta-item",
                              class: "bg-indigo-600 text-white font-black w-8 h-10 rounded-lg flex items-center justify-center text-base shadow"
                            }, _toDisplayString(carta.valor), 1 /* TEXT */))
                          }), 128 /* KEYED_FRAGMENT */)),
                          (!jugador.cartasDelante || jugador.cartasDelante.length === 0)
                            ? (_openBlock(), _createElementBlock("span", _hoisted_20, " Sin cartas "))
                            : _createCommentVNode("v-if", true)
                        ])
                      ])
                    ], 2 /* CLASS */))
                  }), 128 /* KEYED_FRAGMENT */))
                ])
              ])
            ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */))
          : _createCommentVNode("v-if", true)
  ]))
}



_sfc_main.__hmrId = "4fe9a3c7"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/duvan/OneDrive/Documentos/U/S-7/CALIDAD SOFTWARE/pelusas-game-final/frontend/src/views/Board.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQm9hcmQudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IHJlZiwgb25Nb3VudGVkLCBjb21wdXRlZCB9IGZyb20gJ3Z1ZSdcclxuaW1wb3J0IHsgdXNlUm91dGUsIHVzZVJvdXRlciB9IGZyb20gJ3Z1ZS1yb3V0ZXInXHJcbmltcG9ydCB7IEdhbWVBUEkgfSBmcm9tICcuLi9zZXJ2aWNlcy9hcGkuanMnXHJcblxyXG5jb25zdCByb3V0ZSA9IHVzZVJvdXRlKClcclxuY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcclxuXHJcbmNvbnN0IHBhcnRpZGFJZCA9IHJvdXRlLnBhcmFtcy5pZFxyXG5jb25zdCBnYW1lU3RhdGUgPSByZWYobnVsbClcclxuY29uc3QgY2FyZ2FuZG8gPSByZWYodHJ1ZSlcclxuY29uc3QgZXJyb3JNZW5zYWplID0gcmVmKCcnKVxyXG5cclxuLy8gQ2FyZ2FyIGVzdGFkbyBpbmljaWFsIGRlIGxhIHBhcnRpZGEgZGVzZGUgU3ByaW5nIEJvb3RcclxuY29uc3QgY2FyZ2FyUGFydGlkYSA9IGFzeW5jICgpID0+IHtcclxuICB0cnkge1xyXG4gICAgY2FyZ2FuZG8udmFsdWUgPSB0cnVlXHJcbiAgICBlcnJvck1lbnNhamUudmFsdWUgPSAnJ1xyXG4gICAgZ2FtZVN0YXRlLnZhbHVlID0gYXdhaXQgR2FtZUFQSS5vYnRlbmVyUGFydGlkYShwYXJ0aWRhSWQpXHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBlcnJvck1lbnNhamUudmFsdWUgPSAnRXJyb3IgYWwgb2J0ZW5lciBlbCBlc3RhZG8gZGUgbGEgcGFydGlkYSBkZXNkZSBlbCBiYWNrZW5kLidcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxyXG4gIH0gZmluYWxseSB7XHJcbiAgICBjYXJnYW5kby52YWx1ZSA9IGZhbHNlXHJcbiAgfVxyXG59XHJcblxyXG4vLyBFamVjdXRhciBhY2Npb25lcyBkZWwganVlZ28gKFNhY2FyLCBHdWFyZGFyLCBQbGFudGFyc2UpXHJcbmNvbnN0IGVqZWN1dGFyQWNjaW9uID0gYXN5bmMgKHRpcG9BY2Npb24sIHBhcmFtZXRybyA9IG51bGwpID0+IHtcclxuICB0cnkge1xyXG4gICAgaWYgKHRpcG9BY2Npb24gPT09ICdzYWNhcicpIHtcclxuICAgICAgZ2FtZVN0YXRlLnZhbHVlID0gYXdhaXQgR2FtZUFQSS5zYWNhckNhcnRhKHBhcnRpZGFJZClcclxuICAgIH0gZWxzZSBpZiAodGlwb0FjY2lvbiA9PT0gJ2d1YXJkYXInKSB7XHJcbiAgICAgIGdhbWVTdGF0ZS52YWx1ZSA9IGF3YWl0IEdhbWVBUEkuZ3VhcmRhclBlbHVzYXMocGFydGlkYUlkKVxyXG4gICAgfSBlbHNlIGlmICh0aXBvQWNjaW9uID09PSAncGxhbnRhcnNlJykge1xyXG4gICAgICBnYW1lU3RhdGUudmFsdWUgPSBhd2FpdCBHYW1lQVBJLnBsYW50YXJzZShwYXJ0aWRhSWQpXHJcbiAgICB9IGVsc2UgaWYgKHRpcG9BY2Npb24gPT09ICdyb2JhcicpIHtcclxuICAgICAgZ2FtZVN0YXRlLnZhbHVlID0gYXdhaXQgR2FtZUFQSS5yb2JhckNhcnRhcyhwYXJ0aWRhSWQsIHBhcmFtZXRybylcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGVqZWN1dGFuZG8gYWNjacOzbiAke3RpcG9BY2Npb259OmAsIGVycilcclxuICB9XHJcbn1cclxuXHJcbi8vIFNhYmVyIHNpIGxhIHBhcnRpZGEgdGVybWluw7NcclxuY29uc3QgZXNGaW5hbGl6YWRhID0gY29tcHV0ZWQoKCkgPT4ge1xyXG4gIHJldHVybiBnYW1lU3RhdGUudmFsdWUgJiYgZ2FtZVN0YXRlLnZhbHVlLmVzdGFkb1BhcnRpZGEgPT09ICdGSU5BTElaQURBJ1xyXG59KVxyXG5cclxub25Nb3VudGVkKCgpID0+IHtcclxuICBjYXJnYXJQYXJ0aWRhKClcclxufSlcclxuPC9zY3JpcHQ+XHJcblxyXG48dGVtcGxhdGU+XHJcbiAgPG1haW4gY2xhc3M9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtMTAwIGZvbnQtc2FucyBwLTZcIj5cclxuICAgIFxyXG4gICAgPCEtLSBQYW50YWxsYSBkZSBDYXJnYSAtLT5cclxuICAgIDxkaXYgdi1pZj1cImNhcmdhbmRvXCIgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1bNjB2aF1cIj5cclxuICAgICAgPGRpdiBjbGFzcz1cInRleHQtYW1iZXItNDAwIGZvbnQtYm9sZCB0ZXh0LXhsIGFuaW1hdGUtcHVsc2VcIj5DYXJnYW5kbyB0YWJsZXJvLi4uPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIEVycm9yIGRlIENvbmV4acOzbiAtLT5cclxuICAgIDxkaXYgdi1lbHNlLWlmPVwiZXJyb3JNZW5zYWplXCIgY2xhc3M9XCJtYXgtdy1tZCBteC1hdXRvIG15LTEwIGJnLXJlZC05MDAvNTAgYm9yZGVyIGJvcmRlci1yZWQtNTAwIHAtNiByb3VuZGVkLTJ4bCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICA8cCBjbGFzcz1cInRleHQtcmVkLTIwMCBmb250LWJvbGQgbWItNFwiPnt7IGVycm9yTWVuc2FqZSB9fTwvcD5cclxuICAgICAgPGJ1dHRvbiBAY2xpY2s9XCJyb3V0ZXIucHVzaCgnLycpXCIgY2xhc3M9XCJiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB4LTQgcHktMiByb3VuZGVkLXhsIHRleHQteHNcIj5cclxuICAgICAgICBWb2x2ZXIgYWwgSW5pY2lvXHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBUYWJsZXJvIGRlIEp1ZWdvIEFjdGl2byAtLT5cclxuICAgIDxkaXYgdi1lbHNlLWlmPVwiZ2FtZVN0YXRlXCIgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGdhcC0zIHctZnVsbFwiPlxyXG4gICAgICBcclxuICAgICAgPCEtLSBFbmNhYmV6YWRvIGRlIGxhIE1lc2EgLS0+XHJcbiAgICAgIDxoZWFkZXIgY2xhc3M9XCJiZy1zbGF0ZS05MDAgcC04IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBzaGFkb3ctbGdcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5QYXJ0aWRhICN7eyBnYW1lU3RhdGUuaWRQYXJ0aWRhIH19PC9zcGFuPlxyXG4gICAgICAgICAgPGgxIGNsYXNzPVwidGV4dC14bCBmb250LWJsYWNrIHRleHQtYW1iZXItNDAwXCIgZGF0YS10ZXN0aWQ9XCJ0dXJuLW93bmVyXCI+XHJcbiAgICAgICAgICAgIFR1cm5vIGFjdHVhbDoge3sgZ2FtZVN0YXRlLm5vbWJyZUp1Z2Fkb3JBY3R1YWwgfX1cclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDwhLS0gSW5mbyBkZWwgTWF6byAtLT5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiYmctc2xhdGUtODAwIHB4LTUgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LWJvbGRcIj5NYXpvIFJlc3RhbnRlPC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTQwMFwiPnt7IGdhbWVTdGF0ZS5jYXJ0YXNSZXN0YW50ZXNNYXpvIH19IGNhcnRhczwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICA8IS0tIFBhbmVsIGRlIEFsZXJ0YXMgLyBFdmVudG9zIGRlbCBCYWNrZW5kIC0tPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwIHAtNCByb3VuZGVkLXhsIHRleHQtY2VudGVyIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWFtYmVyLTIwMFwiPlxyXG4gICAgICAgIPCfk6Ige3sgZ2FtZVN0YXRlLm1lbnNhamVFdmVudG8gfX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8IS0tIFBhbmVsIGRlIENvbnRyb2xlcyBkZSBBY2Npw7NuIChQYXJhIGVsIEp1Z2Fkb3IgQWN0dWFsKSAtLT5cclxuICAgICAgPGRpdiB2LWlmPVwiIWVzRmluYWxpemFkYVwiIGNsYXNzPVwiYmctc2xhdGUtOTAwIHAtNiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtd3JhcCBnYXAtNCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICBAY2xpY2s9XCJlamVjdXRhckFjY2lvbignZ3VhcmRhcicpXCJcclxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYnRuLWd1YXJkYXJcIlxyXG4gICAgICAgICAgY2xhc3M9XCJiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCBmb250LWJvbGQgcHgtNiBweS0zIHJvdW5kZWQteGwgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciB0ZXh0LXNtXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICDwn5OlIEd1YXJkYXIgUGVsdXNhc1xyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgQGNsaWNrPVwiZWplY3V0YXJBY2Npb24oJ3NhY2FyJylcIlxyXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJidG4tc2FjYXItY2FydGFcIlxyXG4gICAgICAgICAgY2xhc3M9XCJiZy1hbWJlci00MDAgaG92ZXI6YmctYW1iZXItMzAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcHgtOCBweS0zIHJvdW5kZWQteGwgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciB0ZXh0LXNtIHVwcGVyY2FzZSBzaGFkb3ctbGcgc2hhZG93LWFtYmVyLTQwMC8xMFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAg8J+DjyBTYWNhciBDYXJ0YVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgQGNsaWNrPVwiZWplY3V0YXJBY2Npb24oJ3BsYW50YXJzZScpXCJcclxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYnRuLXBsYW50YXJzZVwiXHJcbiAgICAgICAgICBjbGFzcz1cImJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHB4LTYgcHktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgdGV4dC1zbVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAg8J+bkSBQbGFudGFyc2VcclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgQGNsaWNrPVwiZWplY3V0YXJBY2Npb24oJ3JvYmFyJylcIlxyXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJidG4tcm9iYXJcIlxyXG4gICAgICAgICAgY2xhc3M9XCJiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTUwMCBmb250LWJvbGQgcHgtNiBweS0zIHJvdW5kZWQteGwgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciB0ZXh0LXNtXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICDwn6uzIFJvYmFyIFBlbHVzYXNcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8IS0tIE1lbnNhamUgc2kgbGEgcGFydGlkYSBoYSBmaW5hbGl6YWRvIC0tPlxyXG4gICAgICA8ZGl2IHYtZWxzZSBjbGFzcz1cImJnLWVtZXJhbGQtOTAwLzQwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAgcC02IHJvdW5kZWQtMnhsIHRleHQtY2VudGVyIHNwYWNlLXktM1wiPlxyXG4gICAgICAgIDxoMiBjbGFzcz1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTMwMFwiPvCfjokgwqFQYXJ0aWRhIEZpbmFsaXphZGEhPC9oMj5cclxuICAgICAgICA8cCBjbGFzcz1cInRleHQtc2xhdGUtMzAwIHRleHQtc21cIj5TZSBhZ290w7MgZWwgbWF6by4gUmV2aXNhIGVsIGNvbnRlbyBmaW5hbCBkZSBwdW50b3MgYWJham8uPC9wPlxyXG4gICAgICAgIDxidXR0b24gQGNsaWNrPVwicm91dGVyLnB1c2goJy8nKVwiIGNsYXNzPVwiYmctZW1lcmFsZC01MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHB4LTYgcHktMiByb3VuZGVkLXhsIHRleHQteHMgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICBOdWV2YSBQYXJ0aWRhXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPCEtLSBSZW5kZXJpemFkbyBkZSBsYXMgTWVzYXMgZGUgVG9kb3MgbG9zIEp1Z2Fkb3JlcyAoMiBhIDYpIC0tPlxyXG4gICAgICA8c2VjdGlvbiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTNcIj5cclxuICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgdi1mb3I9XCJqdWdhZG9yIGluIGdhbWVTdGF0ZS5qdWdhZG9yZXNcIiBcclxuICAgICAgICAgIDprZXk9XCJqdWdhZG9yLmlkXCJcclxuICAgICAgICAgIGNsYXNzPVwiYmctc2xhdGUtOTAwIHAtNiByb3VuZGVkLTJ4bCBib3JkZXIgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgOmNsYXNzPVwianVnYWRvci5ub21icmUgPT09IGdhbWVTdGF0ZS5ub21icmVKdWdhZG9yQWN0dWFsID8gJ2JvcmRlci1hbWJlci00MDAvNjAgcmluZy0xIHJpbmctYW1iZXItNDAwLzMwJyA6ICdib3JkZXItc2xhdGUtODAwJ1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPCEtLSBOb21icmUgeSBQdW50dWFjacOzbiBBY3VtdWxhZGEgLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTNcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj57eyBqdWdhZG9yLm5vbWJyZSB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiZy1hbWJlci01MDAvMTAgdGV4dC1hbWJlci00MDAgdGV4dC14cyBweC0yLjUgcHktMSByb3VuZGVkLWxnIGZvbnQtYmxhY2sgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMjBcIj5cclxuICAgICAgICAgICAgICB7eyBqdWdhZG9yLnB1bnRvc1RvdGFsZXMgfX0gUHRzXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDwhLS0gQ2FydGFzIGV4cHVlc3RhcyBlbiBtZXNhIGRlIGVzdGUganVnYWRvciAoQ2FydGFzIERlbGFudGUpIC0tPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHVwcGVyY2FzZVwiPkNhcnRhcyBlbiBtZXNhOjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC13cmFwIGdhcC0yIG1pbi1oLVs0MHB4XSBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBcclxuICAgICAgICAgICAgICAgIHYtZm9yPVwiKGNhcnRhLCBpZHgpIGluIGp1Z2Fkb3IuY2FydGFzRGVsYW50ZVwiIFxyXG4gICAgICAgICAgICAgICAgOmtleT1cImlkeFwiXHJcbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImNhcnRhLWl0ZW1cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJiZy1pbmRpZ28tNjAwIHRleHQtd2hpdGUgZm9udC1ibGFjayB3LTggaC0xMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYmFzZSBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt7IGNhcnRhLnZhbG9yIH19XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIHYtaWY9XCIhanVnYWRvci5jYXJ0YXNEZWxhbnRlIHx8IGp1Z2Fkb3IuY2FydGFzRGVsYW50ZS5sZW5ndGggPT09IDBcIiBjbGFzcz1cInRleHQteHMgaXRhbGljIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICBTaW4gY2FydGFzXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgPC9tYWluPlxyXG48L3RlbXBsYXRlPiJdLCJtYXBwaW5ncyI6IkFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUM7Ozs7OztBQUpjO0FBS2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUI7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRSxDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDOzs7Ozs7Ozs7O3FCQUlNLEtBQUssRUFBQyx3REFBd0Q7OztFQUc3QyxLQUFLLEVBQUMsd0RBQXdEOztxQkFLckQsS0FBSyxFQUFDLHdGQUF3RjtxQkFDdkgsS0FBSyxFQUFDLDZCQUE2QjtxQkFPYixLQUFLLEVBQUMsNEJBQTRCO3FCQUduRCxLQUFLLEVBQUMsa0dBQWtHO3FCQUV0RyxLQUFLLEVBQUMsNENBQTRDOztFQUNwRCxLQUFLLEVBQUMsbUNBQW1DO0VBQUMsYUFBVyxFQUFDLFlBQVk7O3FCQU1uRSxLQUFLLEVBQUMsc0VBQXNFO3NCQUV6RSxLQUFLLEVBQUMscUNBQXFDO3NCQUtoRCxLQUFLLEVBQUMsNEdBQTRHOzs7RUFLN0YsS0FBSyxFQUFDLDBGQUEwRjs7c0JBb0M5RyxLQUFLLEVBQUMsbUZBQW1GO3NCQVM1RixLQUFLLEVBQUMsc0RBQXNEO3NCQVE1RCxLQUFLLEVBQUMsd0NBQXdDO3NCQUMzQyxLQUFLLEVBQUMsMEJBQTBCO3NCQUNoQyxLQUFLLEVBQUMscUdBQXFHO3NCQU05RyxLQUFLLEVBQUMsV0FBVztzQkFFZixLQUFLLEVBQUMsZ0RBQWdEOzs7RUFTaUIsS0FBSyxFQUFDLCtCQUErQjs7Ozt3QkFoSDNILG9CQXlITyxRQXpIUCxVQXlITztJQXZITCwwQ0FBMEI7S0FDZixlQUFRO3VCQUFuQixvQkFFTSxPQUZOLFVBRU07VUFESixvQkFBcUYsU0FBaEYsS0FBSyxFQUFDLGdEQUFnRCxJQUFDLHFCQUFtQjs7U0FJakUsbUJBQVk7eUJBQTVCLG9CQUtNO1lBTk4sMENBQTBCO1lBQzFCLG9CQUtNLE9BTE4sVUFLTTtjQUpKLG9CQUE2RCxLQUE3RCxVQUE2RCxtQkFBbkIsbUJBQVk7Y0FDdEQsb0JBRVM7Z0JBRkEsT0FBSyx1Q0FBRSxhQUFNLENBQUMsSUFBSTtnQkFBTyxLQUFLLEVBQUMsbUZBQW1GO2lCQUFDLG9CQUU1SDs7O1dBSWMsZ0JBQVM7MkJBQXpCLG9CQXdHTTtjQXpHTixnREFBZ0M7Y0FDaEMsb0JBd0dNLE9BeEdOLFVBd0dNO2dCQXRHSiw4Q0FBOEI7Z0JBQzlCLG9CQWFTLFVBYlQsVUFhUztrQkFaUCxvQkFLTTtvQkFKSixvQkFBa0csUUFBbEcsVUFBa0csRUFBekMsV0FBUyxvQkFBRyxnQkFBUyxDQUFDLFNBQVM7b0JBQ3hGLG9CQUVLLE1BRkwsVUFFSyxFQUZrRSxpQkFDdkQsb0JBQUcsZ0JBQVMsQ0FBQyxtQkFBbUI7O2tCQUlsRCxzQ0FBc0I7a0JBQ3RCLG9CQUdNLE9BSE4sVUFHTTs4Q0FGSixvQkFBeUUsVUFBbkUsS0FBSyxFQUFDLHdDQUF3QyxJQUFDLGVBQWE7b0JBQ2xFLG9CQUFtRyxRQUFuRyxXQUFtRyxtQkFBOUMsZ0JBQVMsQ0FBQyxtQkFBbUIsSUFBRyxTQUFPOzs7Z0JBSWhHLCtEQUErQztnQkFDL0Msb0JBRU0sT0FGTixXQUVNLEVBRmtILE1BQ25ILG9CQUFHLGdCQUFTLENBQUMsYUFBYTtnQkFHL0IsOEVBQThEO2tCQUNsRCxtQkFBWTttQ0FBeEIsb0JBaUNNLE9BakNOLFdBaUNNO3NCQS9CSixvQkFNUzt3QkFMTixPQUFLLHVDQUFFLHFCQUFjO3dCQUN0QixhQUFXLEVBQUMsYUFBYTt3QkFDekIsS0FBSyxFQUFDLHNHQUFzRzt5QkFDN0csc0JBRUQ7c0JBRUEsb0JBTVM7d0JBTE4sT0FBSyx1Q0FBRSxxQkFBYzt3QkFDdEIsYUFBVyxFQUFDLGlCQUFpQjt3QkFDN0IsS0FBSyxFQUFDLDBKQUEwSjt5QkFDakssa0JBRUQ7c0JBRUEsb0JBTVM7d0JBTE4sT0FBSyx1Q0FBRSxxQkFBYzt3QkFDdEIsYUFBVyxFQUFDLGVBQWU7d0JBQzNCLEtBQUssRUFBQyx5SUFBeUk7eUJBQ2hKLGdCQUVEO3NCQUVBLG9CQU1TO3dCQUxOLE9BQUssdUNBQUUscUJBQWM7d0JBQ3RCLGFBQVcsRUFBQyxXQUFXO3dCQUN2QixLQUFLLEVBQUMsZ0dBQWdHO3lCQUN2RyxvQkFFRDs7bUNBSUYsb0JBTU07c0JBUE4sNERBQTRDO3NCQUM1QyxvQkFNTSxPQU5OLFdBTU07a0RBTEosb0JBQTZFLFFBQXpFLEtBQUssRUFBQyxzQ0FBc0MsSUFBQyx5QkFBdUI7a0RBQ3hFLG9CQUErRixPQUE1RixLQUFLLEVBQUMsd0JBQXdCLElBQUMsMkRBQXlEO3dCQUMzRixvQkFFUzswQkFGQSxPQUFLLHVDQUFFLGFBQU0sQ0FBQyxJQUFJOzBCQUFPLEtBQUssRUFBQyxnRkFBZ0Y7MkJBQUMsaUJBRXpIOzs7Z0JBR0YsZ0ZBQWdFO2dCQUNoRSxvQkFpQ1UsV0FqQ1YsV0FpQ1U7cUNBaENSLG9CQStCTSw2QkE5QmMsZ0JBQVMsQ0FBQyxTQUFTLEdBQTlCLE9BQU87MENBRGhCLG9CQStCTTtzQkE3QkgsR0FBRyxFQUFFLE9BQU8sQ0FBQyxFQUFFO3NCQUNoQixLQUFLLG1CQUFDLG9EQUFvRCxFQUNsRCxPQUFPLENBQUMsTUFBTSxLQUFLLGdCQUFTLENBQUMsbUJBQW1COztzQkFFeEQsc0RBQXNDO3NCQUN0QyxvQkFLTSxPQUxOLFdBS007d0JBSkosb0JBQWtFLFFBQWxFLFdBQWtFLG1CQUF4QixPQUFPLENBQUMsTUFBTTt3QkFDeEQsb0JBRU8sUUFGUCxXQUVPLG1CQURGLE9BQU8sQ0FBQyxhQUFhLElBQUcsT0FDN0I7O3NCQUdGLGtGQUFrRTtzQkFDbEUsb0JBZU0sT0FmTixXQWVNO29EQWRKLG9CQUErRSxVQUF6RSxLQUFLLEVBQUMsNENBQTRDLElBQUMsaUJBQWU7d0JBQ3hFLG9CQVlNLE9BWk4sV0FZTTs2Q0FYSixvQkFPTyw2QkFOa0IsT0FBTyxDQUFDLGFBQWEsR0FBcEMsS0FBSyxFQUFFLEdBQUc7a0RBRHBCLG9CQU9POzhCQUxKLEdBQUcsRUFBRSxHQUFHOzhCQUNULGFBQVcsRUFBQyxZQUFZOzhCQUN4QixLQUFLLEVBQUMsMkdBQTJHO2dEQUU5RyxLQUFLLENBQUMsS0FBSzs7NEJBRUgsT0FBTyxDQUFDLGFBQWEsSUFBSSxPQUFPLENBQUMsYUFBYSxDQUFDLE1BQU07NkNBQWxFLG9CQUVPLFFBRlAsV0FFTyxFQUZ5RyxjQUVoSCIsImlnbm9yZUxpc3QiOltdfQ==