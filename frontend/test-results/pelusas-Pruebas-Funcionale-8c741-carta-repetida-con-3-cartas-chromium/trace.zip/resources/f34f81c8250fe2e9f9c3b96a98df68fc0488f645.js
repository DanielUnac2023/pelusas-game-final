import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");const _sfc_main = {  }
import { resolveComponent as _resolveComponent, openBlock as _openBlock, createBlock as _createBlock } from "/node_modules/.vite/deps/vue.js?v=0b5deebc"

function _sfc_render(_ctx, _cache) {
  const _component_router_view = _resolveComponent("router-view")

  return (_openBlock(), _createBlock(_component_router_view))
}



_sfc_main.__hmrId = "7a7a37b1"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/duvan/OneDrive/Documentos/U/S-7/CALIDAD SOFTWARE/pelusas-game-final/frontend/src/App.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvZHV2YW4vT25lRHJpdmUvRG9jdW1lbnRvcy9VL1MtNy9DQUxJREFEIFNPRlRXQVJFL3BlbHVzYXMtZ2FtZS1maW5hbC9mcm9udGVuZC9zcmMvQXBwLnZ1ZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cclxuICA8cm91dGVyLXZpZXcgLz5cclxuPC90ZW1wbGF0ZT5cclxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7d0JBQ0UsYUFBZSIsImlnbm9yZUxpc3QiOltdfQ==