import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/History.vue");
const _sfc_main = {
  name: 'History',
  data() {
    return {
      historico: [],
      loading: true,
      error: null
    };
  },
  mounted() {
    this.obtenerHistorial();
  },
  methods: {
    async obtenerHistorial() {
      try {
        const response = await fetch('http://localhost:8080/api/partidas/historico');
        if (!response.ok) throw new Error('Error al conectar con la API de histórico');
        this.historico = await response.json();
      } catch (err) {
        this.error = 'No se pudo cargar el historial. Asegúrate de que el backend esté corriendo.';
        console.error(err);
      } finally {
        this.loading = false;
      }
    },
    formatearFecha(fechaStr) {
      if (!fechaStr) return 'N/A';
      const fecha = new Date(fechaStr);
      return fecha.toLocaleString();
    }
  }
};

import { createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString, Fragment as _Fragment, renderList as _renderList, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode } from "/node_modules/.vite/deps/vue.js?v=0b5deebc"

const _hoisted_1 = { class: "min-h-screen bg-[#0a0f1d] text-slate-100 flex flex-col items-center p-4 sm:p-6 font-sans" }
const _hoisted_2 = { class: "w-full max-w-4xl bg-[#111a2e] border border-slate-700/60 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-sm mt-4 sm:mt-8" }
const _hoisted_3 = {
  key: 0,
  class: "flex flex-col items-center justify-center py-12 text-slate-400 gap-3"
}
const _hoisted_4 = { class: "bg-red-500/10 border border-red-500/30 text-red-400 p-4 rounded-xl text-center text-sm my-6" }
const _hoisted_5 = { class: "overflow-x-auto rounded-xl border border-slate-700/50 bg-[#0d1424]" }
const _hoisted_6 = { class: "w-full text-left text-sm border-collapse" }
const _hoisted_7 = { class: "divide-y divide-slate-800" }
const _hoisted_8 = { class: "py-3.5 px-4 font-mono text-slate-400 text-center font-bold" }
const _hoisted_9 = { class: "py-3.5 px-4 text-slate-300 whitespace-nowrap" }
const _hoisted_10 = { class: "py-3.5 px-4 font-semibold text-amber-400 flex items-center gap-1.5 whitespace-nowrap" }
const _hoisted_11 = { class: "py-3.5 px-4 text-center whitespace-nowrap" }
const _hoisted_12 = { class: "inline-block bg-amber-500/10 text-amber-300 font-bold px-2.5 py-1 rounded-md border border-amber-500/20" }
const _hoisted_13 = { class: "py-3.5 px-4 text-slate-300 text-xs sm:text-sm" }
const _hoisted_14 = { class: "mt-8 flex justify-center" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_router_link = _resolveComponent("router-link")

  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createCommentVNode(" Contenedor Principal acorde al diseño del Setup "),
    _createElementVNode("div", _hoisted_2, [
      _createCommentVNode(" Encabezado con badge y título estilizado "),
      _cache[5] || (_cache[5] = _createElementVNode("div", { class: "text-center mb-8" }, [
        _createElementVNode("span", { class: "inline-block px-3 py-1 text-xs font-semibold tracking-wider text-amber-400 uppercase bg-amber-500/10 border border-amber-500/30 rounded-full mb-3" }, " Estadísticas & Resultados "),
        _createElementVNode("h1", { class: "text-3xl sm:text-4xl font-extrabold tracking-tight text-white flex items-center justify-center gap-2" }, [
          _createElementVNode("span", null, "🏆"),
          _createTextVNode(" Historial de Partidas ")
        ]),
        _createElementVNode("p", { class: "text-slate-400 text-sm mt-1" }, "Registro permanente de partidas finalizadas en Pelusas")
      ], -1 /* CACHED */)),
      _createCommentVNode(" Estado: Cargando "),
      ($data.loading)
        ? (_openBlock(), _createElementBlock("div", _hoisted_3, [...(_cache[0] || (_cache[0] = [
            _createElementVNode("div", { class: "w-8 h-8 border-4 border-amber-400 border-t-transparent rounded-full animate-spin" }, null, -1 /* CACHED */),
            _createElementVNode("p", { class: "text-sm font-medium" }, "Cargando historial...", -1 /* CACHED */)
          ]))]))
        : ($data.error)
          ? (_openBlock(), _createElementBlock(_Fragment, { key: 1 }, [
              _createCommentVNode(" Estado: Error "),
              _createElementVNode("div", _hoisted_4, " ⚠️ " + _toDisplayString($data.error), 1 /* TEXT */)
            ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */))
          : ($data.historico.length > 0)
            ? (_openBlock(), _createElementBlock(_Fragment, { key: 2 }, [
                _createCommentVNode(" Tabla de Partidas "),
                _createElementVNode("div", _hoisted_5, [
                  _createElementVNode("table", _hoisted_6, [
                    _cache[2] || (_cache[2] = _createElementVNode("thead", null, [
                      _createElementVNode("tr", { class: "bg-[#162238] border-b border-slate-700/70 text-slate-300 uppercase text-xs tracking-wider" }, [
                        _createElementVNode("th", { class: "py-3.5 px-4 font-semibold text-center w-24" }, "ID"),
                        _createElementVNode("th", { class: "py-3.5 px-4 font-semibold" }, "Fecha / Hora"),
                        _createElementVNode("th", { class: "py-3.5 px-4 font-semibold" }, "Ganador"),
                        _createElementVNode("th", { class: "py-3.5 px-4 font-semibold text-center" }, "Puntaje"),
                        _createElementVNode("th", { class: "py-3.5 px-4 font-semibold" }, "Resumen de Jugadores")
                      ])
                    ], -1 /* CACHED */)),
                    _createElementVNode("tbody", _hoisted_7, [
                      (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($data.historico, (item) => {
                        return (_openBlock(), _createElementBlock("tr", {
                          key: item.id || item.partidaId,
                          class: "hover:bg-slate-800/50 transition-colors"
                        }, [
                          _createElementVNode("td", _hoisted_8, " #" + _toDisplayString(item.partidaId), 1 /* TEXT */),
                          _createElementVNode("td", _hoisted_9, _toDisplayString($options.formatearFecha(item.fechaFin)), 1 /* TEXT */),
                          _createElementVNode("td", _hoisted_10, [
                            _cache[1] || (_cache[1] = _createElementVNode("span", null, "🥇", -1 /* CACHED */)),
                            _createTextVNode(" " + _toDisplayString(item.ganadorNombre), 1 /* TEXT */)
                          ]),
                          _createElementVNode("td", _hoisted_11, [
                            _createElementVNode("span", _hoisted_12, _toDisplayString(item.ganadorPuntaje) + " pts ", 1 /* TEXT */)
                          ]),
                          _createElementVNode("td", _hoisted_13, _toDisplayString(item.resumenJugadores), 1 /* TEXT */)
                        ]))
                      }), 128 /* KEYED_FRAGMENT */))
                    ])
                  ])
                ])
              ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */))
            : (_openBlock(), _createElementBlock(_Fragment, { key: 3 }, [
                _createCommentVNode(" Estado: Sin partidas "),
                _cache[3] || (_cache[3] = _createElementVNode("div", { class: "text-center py-12 text-slate-500 bg-[#0d1424] rounded-xl border border-slate-800" }, [
                  _createElementVNode("p", { class: "text-base font-medium" }, "No hay partidas registradas en el historial."),
                  _createElementVNode("p", { class: "text-xs text-slate-600 mt-1" }, "Completa una partida para ver los resultados aquí.")
                ], -1 /* CACHED */))
              ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */)),
      _createCommentVNode(" Botón para volver al Inicio / Setup "),
      _createElementVNode("div", _hoisted_14, [
        _createVNode(_component_router_link, {
          to: "/",
          class: "w-full sm:w-auto px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-xl border border-slate-700 transition-all text-center flex items-center justify-center gap-2 shadow-lg"
        }, {
          default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
            _createElementVNode("span", null, "←", -1 /* CACHED */),
            _createTextVNode(" Volver a Configurar Partida ", -1 /* CACHED */)
          ]))]),
          _: 1 /* STABLE */
        })
      ])
    ])
  ]))
}



_sfc_main.__hmrId = "89ccdf85"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/duvan/OneDrive/Documentos/U/S-7/CALIDAD SOFTWARE/pelusas-game-final/frontend/src/views/History.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvZHV2YW4vT25lRHJpdmUvRG9jdW1lbnRvcy9VL1MtNy9DQUxJREFEIFNPRlRXQVJFL3BlbHVzYXMtZ2FtZS1maW5hbC9mcm9udGVuZC9zcmMvdmlld3MvSGlzdG9yeS52dWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGlzdG9yeS52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gIDxkaXYgY2xhc3M9XCJtaW4taC1zY3JlZW4gYmctWyMwYTBmMWRdIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHAtNCBzbTpwLTYgZm9udC1zYW5zXCI+XHJcbiAgICBcclxuICAgIDwhLS0gQ29udGVuZWRvciBQcmluY2lwYWwgYWNvcmRlIGFsIGRpc2XDsW8gZGVsIFNldHVwIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cInctZnVsbCBtYXgtdy00eGwgYmctWyMxMTFhMmVdIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzYwIHJvdW5kZWQtMnhsIHAtNiBzbTpwLTggc2hhZG93LTJ4bCBiYWNrZHJvcC1ibHVyLXNtIG10LTQgc206bXQtOFwiPlxyXG4gICAgICBcclxuICAgICAgPCEtLSBFbmNhYmV6YWRvIGNvbiBiYWRnZSB5IHTDrXR1bG8gZXN0aWxpemFkbyAtLT5cclxuICAgICAgPGRpdiBjbGFzcz1cInRleHQtY2VudGVyIG1iLThcIj5cclxuICAgICAgICA8c3BhbiBjbGFzcz1cImlubGluZS1ibG9jayBweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNDAwIHVwcGVyY2FzZSBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC1mdWxsIG1iLTNcIj5cclxuICAgICAgICAgIEVzdGFkw61zdGljYXMgJiBSZXN1bHRhZG9zXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDxoMSBjbGFzcz1cInRleHQtM3hsIHNtOnRleHQtNHhsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgIDxzcGFuPvCfj4Y8L3NwYW4+IEhpc3RvcmlhbCBkZSBQYXJ0aWRhc1xyXG4gICAgICAgIDwvaDE+XHJcbiAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG10LTFcIj5SZWdpc3RybyBwZXJtYW5lbnRlIGRlIHBhcnRpZGFzIGZpbmFsaXphZGFzIGVuIFBlbHVzYXM8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPCEtLSBFc3RhZG86IENhcmdhbmRvIC0tPlxyXG4gICAgICA8ZGl2IHYtaWY9XCJsb2FkaW5nXCIgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0xMiB0ZXh0LXNsYXRlLTQwMCBnYXAtM1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJ3LTggaC04IGJvcmRlci00IGJvcmRlci1hbWJlci00MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpblwiPjwvZGl2PlxyXG4gICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPkNhcmdhbmRvIGhpc3RvcmlhbC4uLjwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8IS0tIEVzdGFkbzogRXJyb3IgLS0+XHJcbiAgICAgIDxkaXYgdi1lbHNlLWlmPVwiZXJyb3JcIiBjbGFzcz1cImJnLXJlZC01MDAvMTAgYm9yZGVyIGJvcmRlci1yZWQtNTAwLzMwIHRleHQtcmVkLTQwMCBwLTQgcm91bmRlZC14bCB0ZXh0LWNlbnRlciB0ZXh0LXNtIG15LTZcIj5cclxuICAgICAgICDimqDvuI8ge3sgZXJyb3IgfX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8IS0tIFRhYmxhIGRlIFBhcnRpZGFzIC0tPlxyXG4gICAgICA8ZGl2IHYtZWxzZS1pZj1cImhpc3Rvcmljby5sZW5ndGggPiAwXCIgY2xhc3M9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMC81MCBiZy1bIzBkMTQyNF1cIj5cclxuICAgICAgICA8dGFibGUgY2xhc3M9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQtc20gYm9yZGVyLWNvbGxhcHNlXCI+XHJcbiAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgIDx0ciBjbGFzcz1cImJnLVsjMTYyMjM4XSBib3JkZXItYiBib3JkZXItc2xhdGUtNzAwLzcwIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0ZXh0LXhzIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzPVwicHktMy41IHB4LTQgZm9udC1zZW1pYm9sZCB0ZXh0LWNlbnRlciB3LTI0XCI+SUQ8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzcz1cInB5LTMuNSBweC00IGZvbnQtc2VtaWJvbGRcIj5GZWNoYSAvIEhvcmE8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzcz1cInB5LTMuNSBweC00IGZvbnQtc2VtaWJvbGRcIj5HYW5hZG9yPC90aD5cclxuICAgICAgICAgICAgICA8dGggY2xhc3M9XCJweS0zLjUgcHgtNCBmb250LXNlbWlib2xkIHRleHQtY2VudGVyXCI+UHVudGFqZTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzPVwicHktMy41IHB4LTQgZm9udC1zZW1pYm9sZFwiPlJlc3VtZW4gZGUgSnVnYWRvcmVzPC90aD5cclxuICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICA8dGJvZHkgY2xhc3M9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgIDx0ciBcclxuICAgICAgICAgICAgICB2LWZvcj1cIml0ZW0gaW4gaGlzdG9yaWNvXCIgXHJcbiAgICAgICAgICAgICAgOmtleT1cIml0ZW0uaWQgfHwgaXRlbS5wYXJ0aWRhSWRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzPVwiaG92ZXI6Ymctc2xhdGUtODAwLzUwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInB5LTMuNSBweC00IGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTQwMCB0ZXh0LWNlbnRlciBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICN7eyBpdGVtLnBhcnRpZGFJZCB9fVxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkIGNsYXNzPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS0zMDAgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgIHt7IGZvcm1hdGVhckZlY2hhKGl0ZW0uZmVjaGFGaW4pIH19XHJcbiAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJweS0zLjUgcHgtNCBmb250LXNlbWlib2xkIHRleHQtYW1iZXItNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPvCfpYc8L3NwYW4+IHt7IGl0ZW0uZ2FuYWRvck5vbWJyZSB9fVxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkIGNsYXNzPVwicHktMy41IHB4LTQgdGV4dC1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5saW5lLWJsb2NrIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTMwMCBmb250LWJvbGQgcHgtMi41IHB5LTEgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7eyBpdGVtLmdhbmFkb3JQdW50YWplIH19IHB0c1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkIGNsYXNzPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS0zMDAgdGV4dC14cyBzbTp0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICB7eyBpdGVtLnJlc3VtZW5KdWdhZG9yZXMgfX1cclxuICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICA8L3RhYmxlPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDwhLS0gRXN0YWRvOiBTaW4gcGFydGlkYXMgLS0+XHJcbiAgICAgIDxkaXYgdi1lbHNlIGNsYXNzPVwidGV4dC1jZW50ZXIgcHktMTIgdGV4dC1zbGF0ZS01MDAgYmctWyMwZDE0MjRdIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICA8cCBjbGFzcz1cInRleHQtYmFzZSBmb250LW1lZGl1bVwiPk5vIGhheSBwYXJ0aWRhcyByZWdpc3RyYWRhcyBlbiBlbCBoaXN0b3JpYWwuPC9wPlxyXG4gICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBtdC0xXCI+Q29tcGxldGEgdW5hIHBhcnRpZGEgcGFyYSB2ZXIgbG9zIHJlc3VsdGFkb3MgYXF1w60uPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDwhLS0gQm90w7NuIHBhcmEgdm9sdmVyIGFsIEluaWNpbyAvIFNldHVwIC0tPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwibXQtOCBmbGV4IGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgPHJvdXRlci1saW5rIFxyXG4gICAgICAgICAgdG89XCIvXCIgXHJcbiAgICAgICAgICBjbGFzcz1cInctZnVsbCBzbTp3LWF1dG8gcHgtNiBweS0zIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCB0ZXh0LWNlbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBzaGFkb3ctbGdcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxzcGFuPuKGkDwvc3Bhbj4gVm9sdmVyIGEgQ29uZmlndXJhciBQYXJ0aWRhXHJcbiAgICAgICAgPC9yb3V0ZXItbGluaz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0PlxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgbmFtZTogJ0hpc3RvcnknLFxyXG4gIGRhdGEoKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBoaXN0b3JpY286IFtdLFxyXG4gICAgICBsb2FkaW5nOiB0cnVlLFxyXG4gICAgICBlcnJvcjogbnVsbFxyXG4gICAgfTtcclxuICB9LFxyXG4gIG1vdW50ZWQoKSB7XHJcbiAgICB0aGlzLm9idGVuZXJIaXN0b3JpYWwoKTtcclxuICB9LFxyXG4gIG1ldGhvZHM6IHtcclxuICAgIGFzeW5jIG9idGVuZXJIaXN0b3JpYWwoKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDo4MDgwL2FwaS9wYXJ0aWRhcy9oaXN0b3JpY28nKTtcclxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIGFsIGNvbmVjdGFyIGNvbiBsYSBBUEkgZGUgaGlzdMOzcmljbycpO1xyXG4gICAgICAgIHRoaXMuaGlzdG9yaWNvID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICB0aGlzLmVycm9yID0gJ05vIHNlIHB1ZG8gY2FyZ2FyIGVsIGhpc3RvcmlhbC4gQXNlZ8O6cmF0ZSBkZSBxdWUgZWwgYmFja2VuZCBlc3TDqSBjb3JyaWVuZG8uJztcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBmb3JtYXRlYXJGZWNoYShmZWNoYVN0cikge1xyXG4gICAgICBpZiAoIWZlY2hhU3RyKSByZXR1cm4gJ04vQSc7XHJcbiAgICAgIGNvbnN0IGZlY2hhID0gbmV3IERhdGUoZmVjaGFTdHIpO1xyXG4gICAgICByZXR1cm4gZmVjaGEudG9Mb2NhbGVTdHJpbmcoKTtcclxuICAgIH1cclxuICB9XHJcbn07XHJcbjwvc2NyaXB0PiJdLCJtYXBwaW5ncyI6IjtBQXlGQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0VBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7SUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtNQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO01BQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNaLENBQUM7RUFDSCxDQUFDO0VBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7SUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDekIsQ0FBQztFQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtJQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtNQUN2QixDQUFDLENBQUMsRUFBRTtRQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQ3hDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDcEIsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDdEI7SUFDRixDQUFDO0lBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFDdkIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9CO0VBQ0Y7QUFDRixDQUFDOzs7O3FCQXZITSxLQUFLLEVBQUMsMEZBQTBGO3FCQUc5RixLQUFLLEVBQUMsMEhBQTBIOzs7RUFjL0csS0FBSyxFQUFDLHNFQUFzRTs7cUJBTXpFLEtBQUssRUFBQyw2RkFBNkY7cUJBS3BGLEtBQUssRUFBQyxvRUFBb0U7cUJBQ3ZHLEtBQUssRUFBQywwQ0FBMEM7cUJBVTlDLEtBQUssRUFBQywyQkFBMkI7cUJBTWhDLEtBQUssRUFBQyw0REFBNEQ7cUJBR2xFLEtBQUssRUFBQyw4Q0FBOEM7c0JBR3BELEtBQUssRUFBQyxzRkFBc0Y7c0JBRzVGLEtBQUssRUFBQywyQ0FBMkM7c0JBQzdDLEtBQUssRUFBQyx5R0FBeUc7c0JBSW5ILEtBQUssRUFBQywrQ0FBK0M7c0JBZTVELEtBQUssRUFBQywwQkFBMEI7Ozs7O3dCQTFFekMsb0JBb0ZNLE9BcEZOLFVBb0ZNO0lBbEZKLHdFQUF3RDtJQUN4RCxvQkFnRk0sT0FoRk4sVUFnRk07TUE5RUosaUVBQWlEO2dDQUNqRCxvQkFRTSxTQVJELEtBQUssRUFBQyxrQkFBa0I7UUFDM0Isb0JBRU8sVUFGRCxLQUFLLEVBQUMsbUpBQW1KLElBQUMsNkJBRWhLO1FBQ0Esb0JBRUssUUFGRCxLQUFLLEVBQUMsc0dBQXNHO1VBQzlHLG9CQUFlLGNBQVQsSUFBRTsyQkFBTyx5QkFDakI7O1FBQ0Esb0JBQWlHLE9BQTlGLEtBQUssRUFBQyw2QkFBNkIsSUFBQyx3REFBc0Q7O01BRy9GLHlDQUF5QjtPQUNkLGFBQU87eUJBQWxCLG9CQUdNLE9BSE4sVUFHTTtZQUZKLG9CQUFvRyxTQUEvRixLQUFLLEVBQUMsa0ZBQWtGO1lBQzdGLG9CQUF3RCxPQUFyRCxLQUFLLEVBQUMscUJBQXFCLElBQUMsdUJBQXFCOztXQUl0QyxXQUFLOzJCQUFyQixvQkFFTTtjQUhOLHNDQUFzQjtjQUN0QixvQkFFTSxPQUZOLFVBRU0sRUFGcUgsTUFDdEgsb0JBQUcsV0FBSzs7YUFJRyxlQUFTLENBQUMsTUFBTTs2QkFBaEMsb0JBcUNNO2dCQXRDTiwwQ0FBMEI7Z0JBQzFCLG9CQXFDTSxPQXJDTixVQXFDTTtrQkFwQ0osb0JBbUNRLFNBbkNSLFVBbUNROzhDQWxDTixvQkFRUTtzQkFQTixvQkFNSyxRQU5ELEtBQUssRUFBQywyRkFBMkY7d0JBQ25HLG9CQUE4RCxRQUExRCxLQUFLLEVBQUMsNENBQTRDLElBQUMsSUFBRTt3QkFDekQsb0JBQXVELFFBQW5ELEtBQUssRUFBQywyQkFBMkIsSUFBQyxjQUFZO3dCQUNsRCxvQkFBa0QsUUFBOUMsS0FBSyxFQUFDLDJCQUEyQixJQUFDLFNBQU87d0JBQzdDLG9CQUE4RCxRQUExRCxLQUFLLEVBQUMsdUNBQXVDLElBQUMsU0FBTzt3QkFDekQsb0JBQStELFFBQTNELEtBQUssRUFBQywyQkFBMkIsSUFBQyxzQkFBb0I7OztvQkFHOUQsb0JBd0JRLFNBeEJSLFVBd0JRO3lDQXZCTixvQkFzQkssNkJBckJZLGVBQVMsR0FBakIsSUFBSTs4Q0FEYixvQkFzQks7MEJBcEJGLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFBRSxJQUFJLElBQUksQ0FBQyxTQUFTOzBCQUMvQixLQUFLLEVBQUMseUNBQXlDOzswQkFFL0Msb0JBRUssTUFGTCxVQUVLLEVBRmtFLElBQ3BFLG9CQUFHLElBQUksQ0FBQyxTQUFTOzBCQUVwQixvQkFFSyxNQUZMLFVBRUssbUJBREEsdUJBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUTswQkFFakMsb0JBRUssTUFGTCxXQUVLO3NEQURILG9CQUFlLGNBQVQsSUFBRTs2Q0FBTyxHQUFDLG9CQUFHLElBQUksQ0FBQyxhQUFhOzswQkFFdkMsb0JBSUssTUFKTCxXQUlLOzRCQUhILG9CQUVPLFFBRlAsV0FFTyxtQkFERixJQUFJLENBQUMsY0FBYyxJQUFHLE9BQzNCOzswQkFFRixvQkFFSyxNQUZMLFdBRUssbUJBREEsSUFBSSxDQUFDLGdCQUFnQjs7Ozs7Ozs2QkFRbEMsb0JBR007Z0JBSk4sNkNBQTZCOzBDQUM3QixvQkFHTSxTQUhNLEtBQUssRUFBQyxrRkFBa0Y7a0JBQ2xHLG9CQUFpRixPQUE5RSxLQUFLLEVBQUMsdUJBQXVCLElBQUMsOENBQTRDO2tCQUM3RSxvQkFBNkYsT0FBMUYsS0FBSyxFQUFDLDZCQUE2QixJQUFDLG9EQUFrRDs7O01BRzNGLDREQUE0QztNQUM1QyxvQkFPTSxPQVBOLFdBT007UUFOSixhQUtjO1VBSlosRUFBRSxFQUFDLEdBQUc7VUFDTixLQUFLLEVBQUMsc01BQXNNOzs0QkFFNU0sQ0FBYztZQUFkLG9CQUFjLGNBQVIsR0FBQzs2QkFBTywrQkFDaEIiLCJpZ25vcmVMaXN0IjpbXX0=